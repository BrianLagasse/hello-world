﻿// IMPORTANT! ALL COMMENTS BELOW SHOULD BE REMOVED BEFORE MOVING CODE INTO PRODUCTION.

/*************************************************************************************
 *
 * File: AepBase.js
 *
 * Description: This file may be used to reduce the amount of JavaScript code required 
 *				to complete a given task while working with the REST API. The code was 
 *				originally authored by Andrew Connell and made available for viewing 
 *				on his blog at:
 *				http://www.andrewconnell.com/blog/simplifying-sharepoint-2013-rest-api
 *				The code was rewritten to use the Revealing Module design pattern and
 *				also to work with SharePoint 2010.
 *
 * Author: Eric Hudson
 *
 * Created: 4/4/2015
 *
 * Version: 1.0.0.1
 *
 * Version History
 *
 *		Version 1.0.0.0: 
 *
 *			Initial release
 *
 *		Version 1.0.0.1:
 *
 *			1. Modified the UrlValue variable to make use of the getWebRelativeUrl value.
 *			2. Modified the example functions to make use of the new AEP.Utility.Error.setFailure call.
 * 			3. Renamed the getRequest function to getItemRequest so that the naming convention was inline with the other functions.
 *			4. Modified the newItemRequest and updateItemRequest functions to take care of data serialization.
 *			5. Moved the AEP.Utility.getRestListUrl() function call into the AEPBase file to reduce the amount of code to write.
 *			6. Modified the example calls to meet team standards and to reflect AepBase.js changes.
 *
 *
 *************************************************************************************/
 /*************************************************************************************
 *
 * USAGE (Note - The example calls below can be tested by creating a list named TestList.)
 *
 * getSiteRelativeUrl
 *
 		var siteUrl = AEP.Utility.getSiteRelativeUrl;
 *
 * getWebRelativeUrl 
 *
 		var webUrl = AEP.Utility.getWebRelativeUrl;
 *
 * getRestListUrl 
 *
  		var query = AEP.Utility.getRestListUrl() + "NameOfList()";
 *
 *
 * getRequest 
 *
 * These are some of the available parameters for the getRequest function below.
 *
 * Great resource: http://platinumdogs.me/2013/03/14/sharepoint-adventures-with-the-rest-api-part-1/
 *
 * - Remember... Everything in JavaScript is case sensitive.
 *
 *		Select: "?$select=Id,Title,Published"
 *		Filter: "&$filter=Published eq true"
 *		Order By: "&$orderby=Title
 *		Lookup Columns: ?$select=MyLookup,Title,Id&$expand=MyLookup
 *		Skip & Top: $select=Id,Title&$orderby=Created&$inlinecount=allpages&skip=2&$top=2
 *
 *
   		var AEP = AEP || {};
 		AEP.Utility = AEP.Utility || {};
 		AEP.$ = jQuery.noConflict();

		AEP.GetData = (function() {
		    "use strict";
		    var load = function() {
		        var _query = "TestList()?$select=Id,Title";
		        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function(data) {
		            var _results = data.d.results,
		                _receivedData = [];
		            AEP.$.each(_results, function(i, item) {
		                _receivedData.push("Id: " + [_results[i].Id, "Title: " + _results[i].Title]);
		            });
		            alert(_receivedData);
		        }).fail(function(err) {
		            AEP.Utility.Error.setFailure(err);
		        });
		    };
		    return {
		        load: load
		    };
		}());
 * 		
 * 		HOW TO Call: AEP.GetData.load();
 *
 *
 * newItemRequest 
 *
   		var AEP = AEP || {};
 		AEP.Utility = AEP.Utility || {};
 		AEP.$ = jQuery.noConflict();

		AEP.NewItem = (function() {
		    "use strict";
		    var save = function() {
		        var _endpoint = "TestList()",
		            _exampleData = {};
		        _exampleData.Title = "OOO Item";
		        AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _exampleData)).success(function() {
		            alert("Success");
		        }).fail(function(err) {
		            AEP.Utility.Error.setFailure(err);
		        });
		    };
		    return {
		        save: save
		    };
		}());
 * 		
 * 		HOW TO Call: AEP.NewItem.save();
 *
 *
 * updateItemRequest 
 *
   		var AEP = AEP || {};
 		AEP.Utility = AEP.Utility || {};
 		AEP.$ = jQuery.noConflict();

		AEP.UpdateData = (function(Id) {
		    "use strict";
		    var update = function(Id) {
		        var _endpoint = "TestList(" + Id + ")",
		            _exampleData = {};
		        _exampleData.Title = "4 - Updated Item 12";
		        AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _exampleData)).success(function() {
		            alert("Success");
		        }).fail(function(err) {
		            AEP.Utility.Error.setFailure(err);
		        });
		    };
		    return {
		        update: update
		    };
		}());
 * 		
 * 		HOW TO Call: AEP.UpdateData.update(1);
 *
 *
 * deleteItemRequest
 *
  		var AEP = AEP || {};
 		AEP.Utility = AEP.Utility || {};
 		AEP.$ = jQuery.noConflict();

		AEP.DeleteData = (function(Id) {
		    "use strict";
		    var deleteData = function(Id) {
		        var _endpoint = "TestList(" + Id + ")";
		        AEP.$.ajax(AEP.Utility.deleteItemRequest(_endpoint)).success(function() {
		            alert("Success");
		        }).fail(function(err) {
		            AEP.Utility.Error.setFailure(err);
		        });
		    };
		    return {
		        deleteData: deleteData
		    };
		}());
 * 		
 * 		HOW TO Call: AEP.DeleteData.deleteData(2);
 *
 *************************************************************************************/
  

var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};

AEP.Utility = (function() {
    "use strict";
    var _baseRequest = {
            type: "",
            url: ""
        },
        getSiteRelativeUrl = _spPageContextInfo.siteServerRelativeUrl,
        getWebRelativeUrl = _spPageContextInfo.webServerRelativeUrl,
        getRestListUrl = function() {
            var UrlValue = getWebRelativeUrl;
            if (UrlValue.length > 0) {
                if (UrlValue[UrlValue.length - 1] != '/') UrlValue += '/';
            }
            UrlValue += "_vti_bin/listdata.svc/";
            return UrlValue;
        },
        getItemRequest = function(endpoint) {
            var request = _baseRequest;
            request.type = "GET";
            request.url = AEP.Utility.getRestListUrl() + endpoint;
            request.headers = {
                ACCEPT: "application/json;odata=verbose"
            };
            return request;
        },
        newItemRequest = function(endpoint, data) {
            var request = _baseRequest,
                payload = Sys.Serialization.JavaScriptSerializer.serialize(data);
            request.type = "POST";
            request.url = AEP.Utility.getRestListUrl() + endpoint;
            request.contentType = "application/json;odata=verbose";
            request.headers = {
                ACCEPT: "application/json;odata=verbose"//,
                //"X-RequestDigest": $("#__REQUESTDIGEST").val()
            };
            request.data = payload;
            return request;
        },
        updateItemRequest = function(endpoint, data) {
            var request = _baseRequest,
                payload = Sys.Serialization.JavaScriptSerializer.serialize(data);
            request.data = payload;
            request.type = "POST";
            request.url = AEP.Utility.getRestListUrl() + endpoint;
            request.contentType = "application/json;odata=verbose";
            request.headers = {
                "ACCEPT": "application/json;odata=verbose",
                //"X-RequestDigest": $("#__REQUESTDIGEST").val(),
                "X-HTTP-Method": "MERGE",
                "If-Match": "*"
            };
            return request;
        },
        deleteItemRequest = function(endpoint) {
            var request = _baseRequest;
            request.type = "DELETE";
            request.url = AEP.Utility.getRestListUrl() + endpoint;
            request.headers = {
                "ACCEPT": "application/json;odata=verbose",
                //"X-RequestDigest": $("#__REQUESTDIGEST").val(),
                "If-Match": "*"
            };
            request.contentType = "application/json;odata=verbose";
            return request;
        };
    return {
        getSiteRelativeUrl: getSiteRelativeUrl,
        getWebRelativeUrl: getWebRelativeUrl,
        getRestListUrl: getRestListUrl,
        getItemRequest: getItemRequest,
        newItemRequest: newItemRequest,
        updateItemRequest: updateItemRequest,
        deleteItemRequest: deleteItemRequest
    };
}()); 



/* 
	jQuery Issue/Explanation
	
	Background information and problem.
   	http://blah.winsmarts.com/2013-5-SharePoint_2013_-_JavaScript_-and-amp;_jQuery_big_booboo_to_watch_out_for.aspx
   	http://www.concurrency.com/blog/jquery-support-in-sharepoint-2013/

   	Here's the solution.
   	Create an AEP object that will be the container for all associated objects.

		var AEP = AEP || {};

   	Follow jQuery's recommendation for removing the "$" alias as a coding concern.
   	Source: https://api.jquery.com/jquery.noconflict/

		AEP.$ = jQuery.noConflict();

   	So now instead of...

		$( "div p" ).hide();

   	You simply add the parent object to keep everything under a single scoping umbrella.

		AEP.$( "div p" ).hide();
*/
