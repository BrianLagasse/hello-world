// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$(".tabs").tabs();
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userLoginName = "",
    userNameId = 0;

AEP.$(function () {

    ExecuteOrDelayUntilScriptLoaded(AEP.editor.init, "sp.js");

});

AEP.editor = (function () {
    "use strict";

     var init =  function() {
		getUserInformation();
	 },

	 getUserInformation = function () {
        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var currentUser = web.get_currentUser();
        context.load(web, 'EffectiveBasePermissions');
        currentUser.retrieve();
        context.load(web);
        context.executeQueryAsync(
           function () { //On success function
               var userObject = web.get_currentUser();
               var email = userObject.get_email();
               var id = userObject.get_id();

               userLogin = userObject.get_loginName();
               var _loginParts = userObject.get_loginName().split("|");

               if (_loginParts[2] != null && (typeof _loginParts[2] != "undefined")) {
                   userLogin = _loginParts[2];
               }
               else {  // No edipi information
                   userLogin = _loginParts[0];
               }

               var userName = userObject.get_title();
               var userEmail = userObject.get_email();

				AEP.init.loadRoleGroups();
				AEP.init.loadTagExperts();
				AEP.editor.getData.loadSeniorPaperList();
				AEP.editor.getData.loadReviewerList();

                AEP.journalUtil.checkNewUser(userLogin, userName, userEmail);

           },
          function () { //On fail function
              alert('Error: ' + args.get_message() + '\n' + args.get_stackTrace());
          }
       );
    };

     return {
     	init : init
    };
}());

AEP.editor.ui = (function () {
    "use strict";

     var assignPaperReviewers =  function(pID, rowNumber) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

    	var _query = "PaperDetails()?$select=PaperName,PaperNumber,PaperVersionNumber,TagA,TagB,TagC,TagD,TagE,Reviewer1,Reviewer2,Reviewer3,Reviewer4,Reviewer5&$expand=TagA,TagB,TagC,TagD,TagE&$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _paperName = "",
            	_paperNo = "",
            	_paperVersionNo = "",
            	_reviewer1Edipi = "",
            	_reviewer2Edipi = "",
            	_reviewer3Edipi = "",
            	_reviewer4Edipi = "",
            	_reviewer5Edipi = "",
	           	_tagA = "",
            	_tagB = "",
            	_tagC = "",
            	_tagD = "",
            	_tagE = "",
				_tags = "";

            if (_results[0].PaperName != null) {
                _paperName = _results[0].PaperName;
            }
            else {
            	_paperName = "";
            }

            if (_results[0].PaperNumber != null) {
                _paperNo = _results[0].PaperNumber ;
            }
            else {
            	_paperNo = "";
            }

            if (_results[0].PaperVersionNumber != null) {
                _paperVersionNo = _results[0].PaperVersionNumber;
            }
            else {
            	_paperVersionNo = "";
            }

            if (_results[0].Reviewer1 != null) {
                _reviewer1Edipi = _results[0].Reviewer1;
            }
            else {
            	_reviewer1Edipi = "";
            }

            if (_results[0].Reviewer2 != null) {
                _reviewer2Edipi = _results[0].Reviewer2;
            }
            else {
            	_reviewer2Edipi = "";
            }

            if (_results[0].Reviewer3 != null) {
                _reviewer3Edipi = _results[0].Reviewer3;
            }
            else {
            	_reviewer3Edipi = "";
            }

            if (_results[0].Reviewer4 != null) {
                _reviewer4Edipi = _results[0].Reviewer4;
            }
            else {
            	_reviewer4Edipi = "";
            }

            if (_results[0].Reviewer5 != null) {
                _reviewer5Edipi = _results[0].Reviewer5;
            }
            else {
            	_reviewer5Edipi = "";
            }

            if ((_results[0].TagA != null) && (typeof _results[0].TagA.Title!= null)) {
                _tagA = _results[0].TagA.Title;
                _tags += _results[0].TagA.Title;
            }

            if ((_results[0].TagB != null) && (typeof _results[0].TagB.Title!= null)) {
                _tagB = _results[0].TagB.Title;
                _tags += "<br>" + _results[0].TagB.Title;
            }

            if ((_results[0].TagC != null) && (typeof _results[0].TagC.Title!= null)) {
                _tagC = _results[0].TagC.Title;
                _tags += "<br>" + _results[0].TagC.Title;
            }

            if ((_results[0].TagD != null) && (typeof _results[0].TagD.Title!= null)) {
                _tagD = _results[0].TagD.Title;
                _tags += "<br>" + _results[0].TagD.Title;
            }

            if ((_results[0].TagE != null) && (typeof _results[0].TagE.Title!= null)) {
                _tagE = _results[0].TagE.Title;
                _tags += "<br>" + _results[0].TagE.Title;
            }

	        var _dialogBody = "<div id='dialogAssignBody'><b>Assign Paper</b><br><br>";

	        _dialogBody += ("<table cellspacing='2' cellpadding='2'><tr><td><b>Paper Short Name: </b></td><td>" + _paperName + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + _paperNo + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Tags: </b></td><td>" + _tags + "</td></tr>");

	     /*   _dialogBody += ("<tr><td><label><b>Senior Editor: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlSrEditor'>");

	        AEP.$.each(srEditors, function (i, item) {
	            var _fullName = srEditors[i][0],
	            	_listId = srEditors[i][1];

		        _dialogBody += ("<option value=" + _listId + ">" + _fullName + "</option>");
			});

        	_dialogBody += ("</select></td></tr>"); */

			var _reviewerList = [];

	        AEP.$.each(reviewers, function (k, item) {
	            var _fullName = reviewers[k][0],
	            	_listId = reviewers[k][1],
	            	_edipi = reviewers[k][2],
	            	_smeReviewer = false;

				if (_tagA != "") {

			        AEP.$.each(tagExperts, function (l, item) {
			        	if (tagExperts[l][0] === _tagA) {
							if (tagExperts[l][2] === _edipi) {
		        				_smeReviewer = true;
							}
						}
					});
				}

				if ((!_smeReviewer) && (_tagB != "")) {

			        AEP.$.each(tagExperts, function (m, item) {
			        	if (tagExperts[m][0] === _tagB) {
							if (tagExperts[m][2] === _edipi) {
		        				_smeReviewer = true;
							}
						}
					});
				}

				if ((!_smeReviewer) && (_tagC != "")) {

			        AEP.$.each(tagExperts, function (n, item) {
			        	if (tagExperts[n][0] === _tagC) {
							if (tagExperts[n][2] === _edipi) {
		        				_smeReviewer = true;
							}
						}
					});
				}

				if ((!_smeReviewer) && (_tagD != "")) {

			        AEP.$.each(tagExperts, function (p, item) {
			        	if (tagExperts[p][0] === _tagD) {
							if (tagExperts[p][2] === _edipi) {
		        				_smeReviewer = true;
							}
						}
					});
				}

				if ((!_smeReviewer) && (_tagE != "")) {

			        AEP.$.each(tagExperts, function (q, item) {
			        	if (tagExperts[q][0] === _tagE) {
							if (tagExperts[q][2] === _edipi) {
		        				_smeReviewer = true;
							}
						}
					});
				}

				if (_smeReviewer) {
					_fullName += " *";
				}
 			    _reviewerList.push([_edipi, _fullName]);

			});

	        _dialogBody += ("<tr><td><b>Reviewer 1: </b></td><td>");
	        _dialogBody += ("<select id='ddlReviewer1'>");
	        _dialogBody += ("<option value=''> -- Choose -- </option>");
	        //_dialogBody += ("<select id='ddlReviewers' size='10' multiple>");

	        AEP.$.each(_reviewerList, function (k, item) {
		        _dialogBody += "<option ";
				if (_reviewerList[k][0] === _reviewer1Edipi) {
		        	_dialogBody += "selected='selected' ";
				}
		        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
			});

        	_dialogBody += ("</select></td></tr>");

	        _dialogBody += ("<tr><td><label><b>Reviewer 2: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlReviewer2'>");
	        _dialogBody += ("<option value=''> -- Choose -- </option>");

	        AEP.$.each(_reviewerList, function (k, item) {
		        _dialogBody += "<option ";
				if (_reviewerList[k][0] === _reviewer2Edipi) {
		        	_dialogBody += "selected='selected' ";
				}
		        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
			});

        	_dialogBody += ("</select></td></tr>");

	        _dialogBody += ("<tr><td><label><b>Reviewer 3: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlReviewer3'>");
	        _dialogBody += ("<option value=''> -- Choose -- </option>");

	        AEP.$.each(_reviewerList, function (k, item) {
		        _dialogBody += "<option ";
				if (_reviewerList[k][0] === _reviewer3Edipi) {
		        	_dialogBody += "selected='selected' ";
				}
		        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
			});

        	_dialogBody += ("</select></td></tr>");

	        _dialogBody += ("<tr><td><label><b>Reviewer 4: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlReviewer4'>");
	        _dialogBody += ("<option value=''> -- Choose -- </option>");

	        AEP.$.each(_reviewerList, function (k, item) {
		        _dialogBody += "<option ";
				if (_reviewerList[k][0] === _reviewer4Edipi) {
		        	_dialogBody += "selected='selected' ";
				}
		        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
			});

        	_dialogBody += ("</select></td></tr>");

	        _dialogBody += ("<tr><td><label><b>Reviewer 5: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlReviewer5'>");
	        _dialogBody += ("<option value=''> -- Choose -- </option>");

	        AEP.$.each(_reviewerList, function (k, item) {
		        _dialogBody += "<option ";
				if (_reviewerList[k][0] === _reviewer5Edipi) {
		        	_dialogBody += "selected='selected' ";
				}
		        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
			});

        	_dialogBody += ("</select></td></tr>");

	        _dialogBody += "</table></div>";

	        if (document.getElementById('dialogAssignBody')) {
	            var elem = document.getElementById('dialogAssignBody');
	            elem.parentNode.removeChild(elem);
	        }

	        AEP.$("#dialog-assign").dialog({
	            modal: true,
	            draggable: false,
	            resizable: false,
	            show: 'blind',
	            hide: 'blind',
	            height: 500,
	            width: 525,
	            open: function () {
	                AEP.$("#dialog-assign").append(_dialogBody );
	            },
	            buttons: [
				    {
				        text: "Assign",
				        click: function () {

		        			var _endpoint = "PaperDetails(" + pID + ")",
			                _paperData = {};

							var _reviewerNotSelected = true;

							var e = document.getElementById("ddlReviewer1");
							var _reviewer1Edipi = e.options[e.selectedIndex].value;
							var _reviewer1

							if (e.options[e.selectedIndex].index != 0) {
								_reviewerNotSelected = false;
							}

							e = document.getElementById("ddlReviewer2");
							var _reviewer2Edipi = e.options[e.selectedIndex].value;

							if (e.options[e.selectedIndex].index != 0) {
								_reviewerNotSelected = false;
							}

							e = document.getElementById("ddlReviewer3");
							var _reviewer3Edipi = e.options[e.selectedIndex].value;

							if (e.options[e.selectedIndex].index != 0) {
								_reviewerNotSelected = false;
							}

							e = document.getElementById("ddlReviewer4");
							var _reviewer4Edipi = e.options[e.selectedIndex].value;

							if (e.options[e.selectedIndex].index != 0) {
								_reviewerNotSelected = false;
							}

							e = document.getElementById("ddlReviewer5");
							var _reviewer5Edipi = e.options[e.selectedIndex].value;

							if (e.options[e.selectedIndex].index != 0) {
								_reviewerNotSelected = false;
							}

							if (_reviewerNotSelected) {
								alert("Please select a Reviewer.");
							} else {

								if (_reviewer1Edipi != "") {
				                	_paperData.Reviewer1 = _reviewer1Edipi;
				                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer1Edipi);
				                }
								if (_reviewer2Edipi != "") {
				                	_paperData.Reviewer2 = _reviewer2Edipi;
				                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer2Edipi);
				                }
								if (_reviewer3Edipi != "") {
				                	_paperData.Reviewer3 = _reviewer3Edipi;
				                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer3Edipi);
				                }
								if (_reviewer4Edipi != "") {
				                	_paperData.Reviewer4 = _reviewer4Edipi;
				                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer4Edipi);
				                }
								if (_reviewer5Edipi != "") {
				                	_paperData.Reviewer5 = _reviewer5Edipi;
				                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer5Edipi);
				                }

								_paperData.Status = "SME Review";

				                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

									var _paperTable = AEP.$('#aPaperGrid').DataTable();
									_paperTable.cell(rowNumber,6).data("SME Review");
									_paperTable.cell(rowNumber,8).data("SME Review");

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });

					            AEP.$("#dialog-assign").dialog("close");
							}
				        }
				    },
				    {
				        text: "Cancel",
				        click: function () {
				            AEP.$("#dialog-assign").dialog("close");

				        }
				    }
	            ]
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	 },

	concurApproval = function (pID, paperNo, paperVersionNo, rowNumber) {

        var _dialogBody = "<div id='dialogBody'><b>Concur Approval?</b><br><br>";

        _dialogBody += "Are you sure you want to concur with the Approval of Paper Number " + paperNo + "?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 500,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();

						_paperTable.cell(rowNumber,6).data("Final Approved");
						_paperTable.cell(rowNumber,8).data("Final Approved");

						AEP.journalUtil.writeLog("Senior Editor Approved Final Paper", pID, userLogin, userLoginName);

	        			var _endpoint = "PaperDetails(" + pID + ")",
		                _paperData = {};

						_paperData.Status = "Final Approved";
			            _paperData.FinalApprovedDate = today;

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    };

     return {
      	assignPaperReviewers : assignPaperReviewers,
      	concurApproval : concurApproval,
     };
}());


AEP.editor.getData = (function () {
    "use strict";

    var loadSeniorPaperList = function () {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$select=PaperName,PaperNumber,AbstractSecurityNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,Id";
        _query += "&$filter=((SeniorEditor eq '" + userLogin + "'))";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_absSecNo = "",
            	_paperSecNo = "",
            	_paperName = "",
            	_paperNumber = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
            	_finalApprovedDate = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            if ((_results[i].AbstractSecurityNumber != null) && (typeof _results[i].AbstractSecurityNumber != "undefined")) {
	                _absSecNo = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_absSecNo = "";
	            }

	            if ((_results[i].PaperSecurityNumber != null) && (typeof _results[i].PaperSecurityNumber != "undefined")) {
	                _paperSecNo = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_paperSecNo = "";
	            }

	            if ((_results[i].PaperNumber != null) && (typeof _results[i].PaperNumber != "undefined")) {
	                _paperNumber = _results[i].PaperNumber;
	            }
	            else {
	            	_paperNumber = "";
	            }

	            if ((_results[i].PaperName != null) && (typeof _results[i].PaperName != "undefined")) {
	                _paperName = _results[i].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _paperNumber, _absSecNo, _paperSecNo, _submittedDate, _finalApprovedDate, _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

            var _paperTable = AEP.$('#paperGrid').DataTable({
                "dom": 'lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
                "order": [[9, "desc"]],
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,6,8] },
		        	{ "width": "350px", "targets": 8 },
		        	{ "targets": [7,9,10],
	        		  "visible": false
	        		},
		        	{ "targets": 8,
		        	  "render": function(data, type, row) {
			        	var _rowButtons = "";

			        	switch (data) {
			       	  		case ("Paper Submitted"):
			       	  		case ("Associate Editor Assignment"):
			       	  		case ("Associate Editor Declined Review"):
			       	  		case ("Associate Editor Accepted Review"):
			       	  		case ("Awaiting Associate Editor Acceptance"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Approve Paper" class="btn-approve" title="Approve Paper"></button>Approve</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Revising"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
     	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Request Changes" class="btn-changes" title="Request Changes"></button>Changes</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
   	  					 	break;
			       	  		case ("SME Review"):
			       	  		case ("Associate Editor Review of SME Feedback"):
			       	  		case ("Associate Editor Review"):
			       	  		case ("Rebuttal Under Associate Editor Review"):
			       	  		case ("Style Editor Review (Preliminary Approval)"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Reviews" class="btn-review" title="Reviews"></button>Reviews</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Approve Paper" class="btn-approve" title="Approve Paper"></button>Approve</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
     	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Request Changes" class="btn-changes" title="Request Changes"></button>Changes</div>'
	   	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Final Approved"):
			       	  		case ("Rejected"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
	   	  					 	break;
			       	  		case ("Senior Editor Final Review"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Concur Approval" class="btn-concur" title="Concur Approval"></button>Concur</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
   	  					 	break;

							default:
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'

							}
				        return _rowButtons;
		        	  	}
			      	}
		        ]
            });

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-view', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewPaper(data[7], "SREDT");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-assign', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.assignPaperEditor(data[7], rowNumber);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-review', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewReviews(data[7], "SREDT");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-changes', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.requestChanges(data[7], data[1], data[10], rowNumber, "SREDT");
        	});

		    AEP.$('#paperGrid  tbody').on( 'click', '.btn-approve', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.approvePaper(data[7], data[1], data[10], rowNumber, "SREDT");
        	});

		    AEP.$('#paperGrid  tbody').on( 'click', '.btn-reject', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.rejectPaper(data[7], data[1], data[10], rowNumber, "SREDT");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-concur', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.editor.ui.concurApproval(data[7], data[1], data[10], rowNumber);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-files', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.displayFiles(data[7], data[1], "SREDT");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-message', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewMessages(data[7], "SREDT", userLoginName);
        	});

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },

	loadReviewerList = function () {

        var _query = "UserInfo()?$select=FullName,Edipi,Email,ReviewerAlias,Id&$expand=Reviewer&$filter=Reviewer/Value eq 'Yes'";
		var _reviewerList = [];

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_edipi = "",
            	_alias = "",
            	_email = "";

            AEP.$.each(_results, function (i, item) {

	            if (_results[i].Edipi != null) {
	                _edipi = _results[i].Edipi;
	            }
	            else {
	            	_edipi = "";
	            }

	            if (_results[i].Email != null) {
	                _email = _results[i].Email;
	            }
	            else {
	            	_email = "";
	            }

	            if (_results[i].ReviewerAlias!= null) {
	                _alias = _results[i].ReviewerAlias;
	            }
	            else {
	            	_alias = "";
	            }

			    _reviewerList.push([_results[i].FullName, _alias, _email]);

            });

            var _reviewerTable = AEP.$('#reviewerGrid').DataTable({
                "dom": 'lfrTCRtip',
                "bDestroy": true,
                "aaData": _reviewerList ,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
                "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2] }
				]
            });

        }).fail(function (err) {
            AEP.Utility.Error.setFailure(err);
        });
	};

    return {
        loadSeniorPaperList : loadSeniorPaperList,
        loadReviewerList : loadReviewerList
    };
}());
