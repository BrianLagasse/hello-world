// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userName = "",
    myAuthorAlias = "",
    myAssocEditorAlias = "",
    mySrEditorAlias = "",
    myStyleEditorAlias = "StyleEditor",
    myReviewerAlias = "",
    today = new Date(),
    authors = [],
    srEditors = [],
    assocEditors = [],
    reviewers = [],
    tagExperts = [];

AEP.init = (function () {
    "use strict";
    var loadRoleGroups = function () {

        var _query = "UserInfo()?$select=FullName,Edipi,SrEditor,Email,SrEditorAlias,AssocEditor,AssocEditorAlias,Reviewer,ReviewerAlias,Author,AuthorAlias,Id&$expand=Author,SrEditor,AssocEditor,Reviewer&$orderby=FullName&$filter=Active/Value eq 'Yes'";
        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_edipi = "",
            	_alias = "",
            	_email = "",
            	_authorFlg = "",
            	_srEditorFlg = "",
            	_assocEditorFlg = "",
            	_reviewerFlg = "";

            AEP.$.each(_results, function (i, item) {

	            if (_results[i].Edipi != null) {
	                _edipi = _results[i].Edipi;
	            }
	            else {
	            	_edipi = "";
	            }

	            if (_results[i].Email != null) {
	                _email = _results[i].Email;
	            }
	            else {
	            	_email = "";
	            }

	            if (_results[i].Author != null) {
	                _authorFlg = _results[i].Author.Value;
	            }
	            else {
	            	_authorFlg = "";
	            }

	            if (_results[i].AuthorAlias != null) {
	                _alias = _results[i].AuthorAlias;
	            }
	            else {
	            	_alias = "";
	            }

            	if (_authorFlg === "Yes") {
            		if (_edipi === userLogin) {
            			myAuthorAlias = _alias;
            		}
			    	authors.push([_results[i].FullName, _results[i].Id, _edipi, _alias, _email]);
			    }

	            if (_results[i].SrEditor != null) {
	                _srEditorFlg = _results[i].SrEditor.Value;
	            }
	            else {
	            	_srEditorFlg = "";
	            }

	            if (_results[i].SrEditorAlias!= null) {
	                _alias = _results[i].SrEditorAlias;
	            }
	            else {
	            	_alias = "";
	            }

            	if (_srEditorFlg === "Yes") {
            		if (_edipi === userLogin) {
            			mySrEditorAlias = _alias;
            		}
			    	srEditors.push([_results[i].FullName, _results[i].Id, _edipi, _alias, _email]);
			    }

	            if (_results[i].AssocEditor != null) {
	                _assocEditorFlg = _results[i].AssocEditor.Value;
	            }
	            else {
	            	_assocEditorFlg = "";
	            }

	            if (_results[i].AssocEditorAlias!= null) {
	                _alias = _results[i].AssocEditorAlias;
	            }
	            else {
	            	_alias = "";
	            }

            	if (_assocEditorFlg === "Yes") {
            		if (_edipi === userLogin) {
            			myAssocEditorAlias = _alias;
            		}
			    	assocEditors.push([_results[i].FullName, _results[i].Id, _edipi, _alias, _email]);
			    	reviewers.push([_results[i].FullName, _results[i].Id, _edipi, _alias, _email]);
			    }

	            if (_results[i].Reviewer != null) {
	                _reviewerFlg = _results[i].Reviewer.Value;
	            }
	            else {
	            	_reviewerFlg = "";
	            }

	            if (_results[i].ReviewerAlias!= null) {
	                _alias = _results[i].ReviewerAlias;
	            }
	            else {
	            	_alias = "";
	            }

            	if (_reviewerFlg === "Yes") {
            		if (_edipi === userLogin) {
            			myReviewerAlias = _alias;
            		}
            		if (_assocEditorFlg != "Yes") {  // Avoid adding them twice to the Reviewers array
				    	reviewers.push([_results[i].FullName, _results[i].Id, _edipi, _alias, _email]);
			    	}
			    }

            });

        }).fail(function (err) {
            AEP.Utility.Error.setFailure(err);
        });
    },

    loadTagExperts = function () {

        var _query = "PaperTags()?$select=Title,SubjectMatterExperts,Id&$expand=SubjectMatterExperts";
        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            _edipi = "";

            AEP.$.each(_results, function (i, item) {

                AEP.$.each(_results[i].SubjectMatterExperts.results, function (l, item) {

	 	            if (_results[i].SubjectMatterExperts.results[l].Edipi != null)  {
		                _edipi = _results[i].SubjectMatterExperts.results[l].Edipi;
		            }
		            else {
		            	_edipi = "";
		            }

 			    	tagExperts.push([_results[i].Title, _results[i].SubjectMatterExperts.results[l].Id, _edipi]);
                });

            });

        }).fail(function (err) {
            AEP.Utility.Error.setFailure(err);
        });
    };


    return {
        loadRoleGroups : loadRoleGroups,
        loadTagExperts : loadTagExperts
    };

}());


AEP.journalUtil = (function () {
    "use strict";

    var context = null,
        web = null;

    var displayFiles = function (pId, paperTitle, userRole) {

		var _folderName = pId;
        var _context = new SP.ClientContext.get_current();
        var _web = _context.get_web();
        var _journalFileLib = _web.get_lists().getByTitle("JournalPapers");
        var _serverUrl = _web.get_serverRelativeUrl();
	    var _url = "";
		var _folderUrl = "JournalPapers/" + _folderName;
        var _fileFolder = _web.getFolderByServerRelativeUrl(_folderUrl);
        _context.load(_fileFolder);
        _context.load(_web);

		if ( userRole === "REVWR") {
			_url = "..//JournalPapers/Forms/SortedView.aspx?RootFolder=" + _serverUrl + "/JournalPapers/" + _folderName;
		} else {
			_url = "..//JournalPapers/Forms/SortedView.aspx?RootFolder=" + _serverUrl + "/JournalPapers/" + _folderName;
		}

		//_url = "..//JournalPapers/Forms/AllItems.aspx?RootFolder=" + _serverUrl + "/JournalPapers/" + _folderName;

        _context.executeQueryAsync(
           function () { //On success function
                var _folderObject = _web.getFolderByServerRelativeUrl(_folderUrl);
			    var _folderName = _folderObject.get_name();

			    var options = {
			        url: _url,
			        title: /*"Files for " + paperTitle + */ "  IMPORTANT: When uploading a new version of a document, please ensure that the file name contains the version number. Uploading a document with a file name that already exists in this folder will overwrite your previous version.",
			        width: 1400,
			        height: 500
			    };

			    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);
			   // SP.UI.UIUtility.setInnerText(parent.document.getElementById("dialogTitleSpan"), "IMPORTANT: When uploading a new version of a document, please ensure that the file name contains the version number. Uploading a document with a file name that already exists in this folder will overwrite your previous version.");

           },
          function (sender, args) { //On fail function
              alert('File folder not found');
          }
       );
    },

	getListItemAttachments = function(listTitle,itemId,success,error) {
	   var ctx = SP.ClientContext.get_current();
	   var list = ctx.get_web().get_lists().getByTitle(listTitle);
	   var item = list.getItemById(itemId);
	   ctx.load(item);
	   ctx.executeQueryAsync(
	      function() {
	          var hasAttachments = item.get_fieldValues()['Attachments'];
	          if(hasAttachments){
	              getAttachmentFiles(item,success,error);
	          }
	          else
	            success([]);
	      },
	      error);
	},

	getAttachmentFiles = function(listItem,success,error) {
	    var ctx = listItem.get_context();
	    var attachmentFolderUrl = String.format('{0}/Attachments/{1}',listItem.get_fieldValues()['FileDirRef'],listItem.get_fieldValues()['ID']);
	    var folder = ctx.get_web().getFolderByServerRelativeUrl(attachmentFolderUrl);
	    var files = folder.get_files();
	    ctx.load(files);
	    ctx.executeQueryAsync(
	       function () {
	          var attachments = [];
	          for (var i = 0; file = files.get_item(i) ; i++)
	          {
	              attachments.push({url: file.get_serverRelativeUrl(), name: file.get_name()});
	          }
	          success(attachments);
	    },
	    error);
	},

	uploadDialog = function(listTitle,itemId) {
	   var ctx = SP.ClientContext.get_current();
	   var list = ctx.get_web().get_lists().getByTitle(listTitle);
	   var id = String(list.get_id());
	   this.url = '/_layouts/Upload.aspx?List={' + id.toUpperCase() + '}&RootFolder=' + folder;

	    optionProcedure = {
	        width: 800,
	        height: 500,
	        url: this.url,
	        title: 'Upload doc'
	    };

	    SP.UI.ModalDialog.showModalDialog(optionProcedure);
	},

    checkNewUser = function (userLogin, userName, email) {

        var _query = "UserInfo()?$select=Id,FullName,Edipi&$filter=Edipi eq '" + userLogin + "'";
        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;

            if (_results.length === 0) {  // User record not found

                userLoginName = userName;

                var _endpoint = "UserInfo()",
                     _userData = {};

                _userData.Title = userLogin;
                _userData.Edipi = userLogin;
                _userData.FullName = userName;
                _userData.AuthorAlias = userName;
                _userData.Email = email;

                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _userData)).success(function () {

                    AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data2) {
                        var _results2 = data2.d.results;
                        userNameId = _results2[0].Id;

                    }).fail(function (err) {
                        AEP.Utility.Error.setFailure(err);
                    });
                }).fail(function (err) {
                    AEP.Utility.Error.setFailure(err);
                });
            }
            else {
                userNameId = _results[0].Id;
                userLoginName = _results[0].FullName;
            }

        }).fail(function (err) {
            AEP.Utility.Error.setFailure(err);
        });
     },

	 viewMessages = function(pID, userRole, userAlias) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _paperName = "",
            	_paperNo = "",
				_abstract = "",
                _attachFilename = "",
                _attachLocation = "",
				_webUrl = AEP.Utility.getWebRelativeUrl;

			_paperName = _results[0].PaperName;

            if ((_results[0].PaperNumber != null) && (typeof _results[0].PaperNumber != "undefined")) {
                _paperNo = _results[0].PaperNumber ;
            }
            else {
            	_paperNo = "";
            }

	        var _dialogBody = "<div id='dialogBody'><b>Messages</b><br><br>";

	        _dialogBody += ("<table cellpadding='2'><tr><td colspan='3'><b>Paper Short Name: </b>" + _paperName + "</td></tr>");
	        _dialogBody += ("<tr><td colspan='3'><b>Paper Number: </b>" + _paperNo + "</td></tr>");
	        _dialogBody += ("<tr><td colspan='3'><b>Messages: </b></td></tr>");

	        _query = "Messages()?$select=Title,MessageDetail,Sender,RecipientEdipi,SenderEdipi,Paper,Modified,Id,Attachments&$expand=Paper,Attachments&$orderby=Modified desc ";

			if (userRole === "STYLE") {
				_query += "&$filter= ( (SenderEdipi eq 'StyleEditor') or (RecipientEdipi eq 'StyleEditor'))  and (Paper/Id eq " + pID + ")";
 			} else {
				_query += "&$filter= ( (SenderEdipi eq '" + userLogin + "') or (RecipientEdipi eq '" + userLogin + "'))  and (Paper/Id eq " + pID + ")";
			}

	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            _results = data.d.results;
				var _msgTitle = "",
	            	_msgDetail = "",
	            	_msgSender = "",
	            	_msgRecieveEdipi = "",
	            	_msgSenderEdipi = "",
					_msgDate = "",
					_msgId = 0,
					_attachCount = 0;

				if (_results.length === 0) {
	        		_dialogBody += ("<tr><td colspan='3'>No Messages</td></tr>");

				} else {
		            AEP.$.each(_results, function (i, item) {

						_msgTitle = _results[i].Title;
						_msgId = _results[i].Id;

			            if ((_results[i].MessageDetail != null) && (typeof _results[i].MessageDetail != "undefined")) {
			                _msgDetail = _results[i].MessageDetail;
			            }
			            else {
			            	_msgDetail = "";
			            }

			            if ((_results[i].Sender != null) && (typeof _results[i].Sender != "undefined")) {
			                _msgSender = _results[i].Sender;
			            }
			            else {
			            	_msgSender = "";
			            }

			            if ((_results[i].RecipientEdipi != null) && (typeof _results[i].RecipientEdipi != "undefined")) {
			                _msgRecieveEdipi = _results[i].RecipientEdipi;
			            }
			            else {
			            	_msgRecieveEdipi = "";
			            }

		            	_modifiedDate = moment.utc(_results[i].Modified).format('MM/DD/YYYY h:mm A');

						/*getListItemAttachments("MessagesCenter", _msgId,
						    function(attachmentFiles){
						       console.log(attachmentFiles);
						    },
						    function(sendera,args){
						       alert("attachment error");
						    }); */

	        			_dialogBody += ("<tr><td colspan='3'>___________________________________________________________________________</td></tr>");
		        		_dialogBody += ("<tr><td colspan='3'><b>Subject: " + _msgTitle + "</b></td></tr>");
		        		_dialogBody += ("<tr><td colspan='3'><b>From:  " + _msgSender + "</b></td></tr>");
		        		_dialogBody += ("<tr><td colspan='2'><b>Sent: " + _modifiedDate + "</b></td>");
		        		if ((_msgRecieveEdipi === userLogin) || (userRole === "STYLE")) {
		        			_dialogBody += ("<td align='right'><input type='button' name='msgReply' title='Reply' value='Reply' onclick='AEP.journalUtil.replyMessage(\"" + _msgId + "\",\"" + userAlias + "\",\"" + userRole + "\")'/></td></tr>");
		        		} else {
		        			_dialogBody += ("<td></td></tr>");
		        		}
		        		_dialogBody += ("<tr><td colspan='3'><textarea readonly cols='80' rows='5'>" + _msgDetail + "</textarea></td></tr>");

                       	_attachCount = _results[i].Attachments.results.length;

						if (_attachCount > 0) {
		        			_dialogBody += ("<tr><td colspan='3'><table><tr><td><b>Attachments:<b></td>");

                           	AEP.$.each(_results[i].Attachments.results, function (l, item) {
                                _attachFilename = _results[i].Attachments.results[l].Name;
                                _attachLocation = (_webUrl + "/Lists/Messages/Attachments/" + _msgId + "/" + _attachFilename);
                                if (l === 0) {
  		        					_dialogBody += ("<td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
  		        				} else {
  		        					_dialogBody += ("<tr><td></td><td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
  		        				}
                            });
                            _dialogBody += "</table></td></tr>";
						}
		            });
				}

		        _dialogBody += "</table></div>";

		        if (document.getElementById('dialogBody')) {
		            var elem = document.getElementById('dialogBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-message").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 500,
		            width: 700,
		            open: function () {
		                AEP.$("#dialog-message").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "New Message",
					        click: function () {
								AEP.journalUtil.newMessage(pID, _paperName, _paperNo, userLogin, userRole, userAlias);
					            AEP.$("#dialog-message").dialog("close");
					        }
					    },
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-message").dialog("close");
					        }
					    }
		            ]
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

    newMessage =  function(pID, paperName, paperNo, sender, userRole, userAlias) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$select=AuthorEdipi,AssociateEditor,SeniorEditor,StyleEditor,";
        	_query += "Reviewer1,Reviewer2,Reviewer3,Reviewer4,Reviewer5,Id&$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _author = "",
				_seniorEditor = "",
				_styleEditor = "",
				_assocEditor = "",
				_reviewer1 = "",
				_reviewer2 = "",
				_reviewer3 = "",
				_reviewer4 = "",
				_reviewer5 = "",
				_recipientRole = "";

            if ((_results[0].AuthorEdipi != null)) {
                _author = _results[0].AuthorEdipi;
            }
            else {
            	_author = "";
            }

            if ((_results[0].AssociateEditor != null)) {
                _assocEditor = _results[0].AssociateEditor;
            }
            else {
            	_assocEditor = "";
            }

            if ((_results[0].SeniorEditor != null)) {
                _seniorEditor = _results[0].SeniorEditor;
            }
            else {
            	_seniorEditor = "";
            }

           	_styleEditor = "StyleEditor";

            if ((_results[0].Reviewer1 != null)) {
                _reviewer1 = _results[0].Reviewer1;
            }
            else {
            	_reviewer1 = "";
            }

            if ((_results[0].Reviewer2 != null)) {
                _reviewer2 = _results[0].Reviewer2;
            }
            else {
            	_reviewer2 = "";
            }

            if ((_results[0].Reviewer3 != null)) {
                _reviewer3 = _results[0].Reviewer3;
            }
            else {
            	_reviewer3 = "";
            }

            if ((_results[0].Reviewer4 != null)) {
                _reviewer4 = _results[0].Reviewer4;
            }
            else {
            	_reviewer4 = "";
            }

            if ((_results[0].Reviewer5 != null)) {
                _reviewer5 = _results[0].Reviewer5;
            }
            else {
            	_reviewer5 = "";
            }

	        var _dialogBody = "<div id='newDialogBody'><b>New Message</b><br><br>";

	        _dialogBody += ("<table cellpadding='2'><tr><td><b>Paper Short Name: </b></td><td>" + paperName + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + paperNo + "</td></tr>");
	        _dialogBody += ("<tr><td><label><b>Subject: </b></label></td><td><input type='text' id='newSubject' style='width: 300px;'/></td></tr>");

	    	_dialogBody += ("<tr><td><b>Recipient: </b></td>");

	    	if ((userRole != "AUTHR") && (userRole != "REVWR")) {
		    	_dialogBody += ("<td><input type='radio' name='recipient' value='AUTHR" + _author + "' checked />Author</td></tr>");
		    	if (userRole != "SREDT") {
			    	_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='SREDT" + _seniorEditor + "' />Senior Editor</td></tr>");
			    }
		    } else {
		    	_dialogBody += ("<td><input type='radio' name='recipient' value='SREDT" + _seniorEditor + "' checked/>Senior Editor</td></tr>");
		    }

	    	if ((userRole != "ASSOC") && (_assocEditor != "")) {
	    		_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='ASSOC" + _assocEditor + "' />Associate Editor</td></tr>");
	    	}

	    	if ((userRole != "STYLE") && (userRole != "REVWR")) {
	    		_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='STYLE" + _styleEditor + "' />Style Editor</td></tr>");
	    	}

	    	if ((userRole === "SREDT") || (userRole === "ASSOC")) {
	    		if (_reviewer1 != "") {
			    	_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='REVWR" + _reviewer1 + "' />Reviewer 1</td></tr>");
			    }
	    		if (_reviewer2 != "") {
		    		_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='REVWR" + _reviewer2 + "' />Reviewer 2</td></tr>");
			    }
	    		if (_reviewer3 != "") {
		    		_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='REVWR" + _reviewer3 + "' />Reviewer 3</td></tr>");
			    }
	    		if (_reviewer4 != "") {
		    		_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='REVWR" + _reviewer4 + "' />Reviewer 4</td></tr>");
			    }
	    		if (_reviewer5 != "") {
		    		_dialogBody += ("<tr><td></td><td><input type='radio' name='recipient' value='REVWR" + _reviewer5 + "' />Reviewer 5</td></tr>");
			    }
	    	}
	   		_dialogBody += ("<tr><td></td><td></td></tr>");

	    	_dialogBody += ("<tr><td valign='top'><b>Message Detail: </b></td><td><textarea id='newMessage' cols='60' rows='15' /></td></tr>");

	        _dialogBody += "</table></div>";

	        if (document.getElementById('newDialogBody')) {
	            var elem = document.getElementById('newDialogBody');
	            elem.parentNode.removeChild(elem);
	        }

	        AEP.$("#dialog-new-message").dialog({
	            modal: true,
	            draggable: false,
	            resizable: false,
	            show: 'blind',
	            hide: 'blind',
	            height: 500,
	            width: 600,
	            open: function () {
	                AEP.$("#dialog-new-message").append(_dialogBody );
	            },
	            buttons: [
				    {
				        text: "Send with Attachments",
				        click: function () {

							var _subject = "",
				            	_msgDetail = "",
				            	_recipientRoleEdipi = "";
				            	_recipientEdipi = "";

			                var _messageData = {};
		        			_endpoint = "Messages()";

							var e = document.getElementById("newSubject");
							_subject = e.value;

							e = document.getElementById("newMessage");
							_msgDetail = e.value;

							if ((_subject === "") || (_msgDetail === "")) {
							  alert("Message Subject and Detail are required.");
							} else {

								_recipientRoleEdipi = AEP.$("input:radio[name='recipient']:checked").val();
								_recipientRole = _recipientRoleEdipi.substring(0,5);
								_recipientEdipi = _recipientRoleEdipi.substring(5);

				                _messageData.Title = _subject;
				                _messageData.Sender = userAlias;
				                _messageData.SenderRole = userRole;
				                _messageData.SenderEdipi = sender;
				                _messageData.RecipientEdipi = _recipientEdipi;
				                _messageData.RecipientRole = _recipientRole;
				                _messageData.PaperId = pID;
				                _messageData.HasAttachmentsValue = "Yes";
				                _messageData.MessageDetail = _msgDetail;

						        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

				                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _messageData)).success(function () {

							        AEP.$("#dialog-new-message").dialog("close");

							        var _query = "Messages()?$select=Paper,Id&$expand=Paper&$orderby=Id desc&$filter=PaperId eq " + pID + "";

							        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
							            _results = data.d.results;

							            var _listId = _results[0].Id;

									    var options = {
									        url: "../Lists/Messages/MessageAttachments.aspx?ID="+_listId,
									        title: "Message Attachments",
									        width: 650,
									        height: 500
										    };

									    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);

							        }).fail(function (err) {
							            AEP.$.unblockUI();
							            AEP.Utility.Error.setFailure(err);
							        });

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });
				        	}
				        }
				    },
				    {
				        text: "Send without Attachments",
				        click: function () {

							var _subject = "",
				            	_msgDetail = "",
				            	_recipientEdipi = "";

			                var _messageData = {};
		        			_endpoint = "Messages()";

							var e = document.getElementById("newSubject");
							_subject = e.value;

							e = document.getElementById("newMessage");
							_msgDetail = e.value;

							if ((_subject === "") || (_msgDetail === "")) {
							  alert("Message Subject and Detail are required.");
							} else {

								_recipientRoleEdipi = AEP.$("input:radio[name='recipient']:checked").val();
								_recipientRole = _recipientRoleEdipi.substring(0,5);
								_recipientEdipi = _recipientRoleEdipi.substring(5);

				                _messageData.Title = _subject;
				                _messageData.Sender = userAlias;
				                _messageData.SenderEdipi = sender;
				                _messageData.SenderRole = userRole;
				                _messageData.RecipientEdipi = _recipientEdipi;
				                _messageData.RecipientRole = _recipientRole;
				                _messageData.PaperId = pID;
				                _messageData.HasAttachmentsValue = "No";
				                _messageData.MessageDetail = _msgDetail;

				                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _messageData)).success(function () {

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });

					            AEP.$("#dialog-new-message").dialog("close");
					    	}
				        }
				    },
				    {
				        text: "Cancel",
				        click: function () {
				            AEP.$("#dialog-new-message").dialog("close");
				        }
				    }
	            ]
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	 },

    replyMessage =  function(pID, userAlias, userRole) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "Messages()?$select=Paper,Title,MessageDetail,Sender,SenderEdipi,SenderRole,RecipientEdipi,";
        	_query += "Id&$expand=Paper&$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _subject = "",
            	_paperName = "",
            	_paperNumber = "",
            	_msgDetail = "",
            	_newMsgDetail = "",
            	_sender = "",
            	_senderEdipi = "",
            	_senderRole = "",
            	_receipientEdipi = "",
            	_tempEdipi = "",
            	_endpoint = "";

			_subject = _results[0].Title;

            if ((_results[0].Sender != null) && (typeof _results[0].Sender != "undefined")) {
                _sender = _results[0].Sender;
            }
            else {
            	_sender = "";
            }

            if ((_results[0].SenderEdipi != null) && (typeof _results[0].SenderEdipi != "undefined")) {
                _senderEdipi = _results[0].SenderEdipi;
            }
            else {
            	_senderEdipi = "";
            }

            if ((_results[0].SenderRole!= null) && (typeof _results[0].SenderRole!= "undefined")) {
                _senderRole = _results[0].SenderRole;
            }
            else {
            	_senderRole = "";
            }

            if ((_results[0].RecipientEdipi != null) && (typeof _results[0].RecipientEdipi != "undefined")) {
                _receipientEdipi = _results[0].RecipientEdipi;
            }
            else {
            	_receipientEdipi = "";
            }

            if ((_results[0].Paper != null) && (typeof _results[0].Paper != "undefined")) {
                _paperName = _results[0].Paper.PaperName;
	            if ((_results[0].Paper.PaperNumber != null) && (typeof _results[0].Paper.PaperNumber != "undefined")) {
	                _paperNumber = _results[0].Paper.PaperNumber;
	            }
	            else {
	            	_paperNumber = "";
	            }
            }
            else {
            	_paperName = "";
	           	_paperNumber = "";
            }

			_msgDetail = "***** Prior Message from: " + _sender + " ***** \n\n" + _results[0].MessageDetail;

	        var _dialogBody = "<div id='replyDialogBody'><b>Reply Message</b><br><br>";

       		_dialogBody += ("<table><tr><td><b>Paper Short Name: </b></td><td>" + _paperName + "</td></tr>");
       		_dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + _paperNumber + "</td></tr>");
       		_dialogBody += ("<tr><td><b>Reply To: </b></td><td>" + _sender + "</td></tr>");
       		_dialogBody += ("<tr><td><b>Subject: </b></td><td>" + _subject + "</td></tr>");
       		_dialogBody += ("<tr><td></td><td></td></tr>");

    		_dialogBody += ("<tr><td valign='top'><b>Reply: </b></td>");
    		_dialogBody += ("<td><textarea id='answerMessage' cols='80' rows='5' /></td></tr>");
    		_dialogBody += ("<tr><td valign='top'><b>Previous: </b></td>");
    		_dialogBody += ("<td><textarea readonly cols='80' rows='10'>" + _msgDetail + "</textarea></td></tr>");

	        _dialogBody += "</table></div>";

	        if (document.getElementById('replyDialogBody')) {
	            var elem = document.getElementById('replyDialogBody');
	            elem.parentNode.removeChild(elem);
	        }

	        AEP.$("#dialog-reply").dialog({
	            modal: true,
	            draggable: false,
	            resizable: false,
	            show: 'blind',
	            hide: 'blind',
	            height: 500,
	            width: 650,
	            open: function () {
	                AEP.$("#dialog-reply").append(_dialogBody );
	            },
	            buttons: [
				    {
				        text: "Send with Attachments",
				        click: function () {

							var e = document.getElementById("answerMessage");
							_newMsgDetail =  e.value + "\n\n" + _msgDetail;

			                var _messageData = {};
		        			_endpoint = "Messages(" + pID + ")";

			                _messageData.Sender = userAlias;
			                _messageData.SenderRole = userRole;
			                _messageData.MessageDetail = _newMsgDetail;
			                _messageData.RecipientEdipi = _senderEdipi;
			                _messageData.RecipientRole = _senderRole;
				            _messageData.HasAttachmentsValue = "Yes";

			                if (userAlias === "StyleEditor") {
			                	_messageData.SenderEdipi = "StyleEditor";
							} else {
			                	_messageData.SenderEdipi = userLogin;
							}

					        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _messageData)).success(function () {

						        AEP.$("#dialog-message").dialog("close");
					            AEP.$("#dialog-reply").dialog("close");

							    var options = {
							        url: "../Lists/Messages/MessageAttachments.aspx?ID="+pID,
							        title: "Message Attachments",
							        width: 650,
							        height: 500
							    };

							    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });
				        }
				    },
				    {
				        text: "Send without Attachments",
				        click: function () {

							var e = document.getElementById("answerMessage");
							_newMsgDetail =  e.value + "\n\n" + _msgDetail;

			                var _messageData = {};
		        			_endpoint = "Messages(" + pID + ")";

			                _messageData.Sender = userAlias;
			                _messageData.SenderRole = userRole;
			                _messageData.MessageDetail = _newMsgDetail;
			                _messageData.RecipientEdipi = _senderEdipi;
			                _messageData.RecipientRole = _senderRole;
				            _messageData.HasAttachmentsValue = "No";

			                if (userAlias === "StyleEditor") {
			                	_messageData.SenderEdipi = "StyleEditor";
							} else {
			                	_messageData.SenderEdipi = userLogin;
							}

			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _messageData)).success(function () {

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

					        AEP.$("#dialog-message").dialog("close");
				            AEP.$("#dialog-reply").dialog("close");
				        }
				    },
				    {
				        text: "Cancel",
				        click: function () {
				            AEP.$("#dialog-reply").dialog("close");
				        }
				    }
	            ]
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	 },

	 viewPaper =  function(pID, userRole) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$expand=TagA,TagB,TagC,TagD,TagE&$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _paperName = "",
            	_paperTitle = "",
				_paperNo = "",
				_volumeNo = "",
				_issueNo = "",
            	_absSecNo = "",
            	_absVerNo = "",
            	_paperSecNo = "",
            	_paperVerNo = "",
            	_distCode = "",
	           	_tagA = "",
            	_tagB = "",
            	_tagC = "",
            	_tagD = "",
            	_tagE = "";

            if (_results[0].Title != null) {
                _paperTitle = _results[0].Title;
            }

            if (_results[0].PaperName != null) {
                _paperName = _results[0].PaperName;
            }

            if (_results[0].PaperNumber != null) {
                _paperNo = _results[0].PaperNumber;
            }

            if (_results[0].DistributionCode != null) {
                _distCode = _results[0].DistributionCode;
            }

            if (_results[0].AbstractSecurityNumber != null) {
                _absSecNo = _results[0].AbstractSecurityNumber;
            }

            if (_results[0].PaperSecurityNumber != null) {
                _paperSecNo = _results[0].PaperSecurityNumber;
            }

            if (_results[0].VolumeNumber != null) {
                _volumeNo = _results[0].VolumeNumber;
            }

            if (_results[0].IssueNumber != null) {
                _issueNo = _results[0].IssueNumber;
            }


            if ((_results[0].TagA != null) && (typeof _results[0].TagA.Title!= null)) {
                _tagA = _results[0].TagA.Title;
            }

            if ((_results[0].TagB != null) && (typeof _results[0].TagB.Title!= null)) {
                _tagB = _results[0].TagB.Title;
            }

            if ((_results[0].TagC != null) && (typeof _results[0].TagC.Title!= null)) {
                _tagC = _results[0].TagC.Title;
            }

            if ((_results[0].TagD != null) && (typeof _results[0].TagD.Title!= null)) {
                _tagD = _results[0].TagD.Title;
            }

            if ((_results[0].TagE != null) && (typeof _results[0].TagE.Title!= null)) {
                _tagE = _results[0].TagE.Title;
            }

	        var _dialogBody = "<div id='dialogPaperBody'><b>View Paper</b><br><br>";

	        _dialogBody += "<table>";
	        _dialogBody += ("<tr><td><b>Submission Type: </b></td><td>" + _results[0].SubmissionTypeValue+ "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Title: </b></td><td>" + _paperTitle + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td>" + _paperName + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + _paperNo + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Journal Name: </b></td><td>" + _results[0].JournalNameValue + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Distribution Statement: </b></td><td>" + _distCode + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Current Abstract Security Number: </b></td><td>" + _absSecNo + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Current Paper Security Number: </b></td><td>" + _paperSecNo + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Tag 1: </b></td><td>" + _tagA + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Tag 2: </b></td><td>" + _tagB +"</td></tr>");
	        _dialogBody += ("<tr><td><b>Tag 3: </b></td><td>" + _tagC +"</td></tr>");
	        _dialogBody += ("<tr><td><b>Tag 4: </b></td><td>" + _tagD + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Tag 5: </b></td><td>" + _tagE + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Volume Number: </b></td><td>" + _volumeNo + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Issue Number: </b></td><td>" + _issueNo + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Status: </b></td><td>" + _results[0].Status + "</td></tr>");
	        _dialogBody += "</table>";
	        _dialogBody += "<br>";

		    _query = "JournalPapers()?$orderby=DocumentVersion&$filter=PaperID eq '" + pID + "'";

	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            var _results2 = data.d.results;
				var _paperBody = "",
					_abstractBody = "",
					_asn = "",
					_contentType = "",
					_documentType = "",
					_documentVersion = "",
	            	_paperVersion = "",
	            	_includesAbstract = "",
	            	_includesRebuttal = "",
	            	_fileLocation = "",
	            	_paperCount = 0,
	            	_abstractCount = 0,
	            	_webUrl = AEP.Utility.getWebRelativeUrl;


	        	_paperBody = "<br><fieldset><legend><b>Related Files - Papers</b></legend>";
	        	_paperBody += "<table>";
	       		_paperBody += ("<tr><td><b>Name</b></td><td><b>Document Version</b></td><td><b>Document Type</b></td><td><b>Assigned Security Number</b></td>");
	       		_paperBody += ("<td><b>Includes Abstract In Main Document?</b></td><td><b>Includes Rebuttal?</b></td></tr>");

	        	_abstractBody = "<br><fieldset><legend><b>Related Files - Abstracts</b></legend>";
	        	_abstractBody += "<table>";
	       		_abstractBody += ("<tr><td><b>Name</b></td><td><b>Document Version</b></td><td><b>Document Type</b></td><td><b>Assigned Security Number</b></td></tr>");

			    AEP.$.each(_results2, function (j, item) {

					_fileLocation = (_webUrl + "/JournalPapers/" + pID + "/" + _results2[j].Name);

			        if (_results2[j].AssignedSecurityNumber!= null) {
		                _asn = _results2[j].AssignedSecurityNumber;
		            }
		            else {
		            	_asn = "";
		            }

			        if (_results2[j].DocumentVersion != null) {
		                _documentVersion = _results2[j].DocumentVersion ;
		            }
		            else {
		            	_documentVersion = "";
		            }

			        if (_results2[j].IncludesAbstractInMainDocument != null) {
			        	if (_results2[j].IncludesAbstractInMainDocument === true) {
		                	_includesAbstract = "Yes";
		                } else {
		                	_includesAbstract = "No";
		                }
		            }
		            else {
		            	_includesAbstract = "No";
		            }

			        if (_results2[j].RebuttalIncluded != null) {
			        	if (_results2[j].RebuttalIncluded === true) {
		                	_includesRebuttal = "Yes";
		                } else {
		                	_includesRebuttal = "No";
		                }
		            }
		            else {
		            	_includesRebuttal = "No";
		            }

					_contentType = _results2[j].ContentType;
					_documentType = _results2[j].DocumentTypeValue;

					if (_contentType.substring(0,5) === "Paper") {
						_paperCount++;
						_paperBody += ("<tr><td><u><a target='_blank' href = '" + _fileLocation + "'>" + _results2[j].Name + "</a></u></td><td>");
						_paperBody += (_documentVersion + "</td><td>" + _documentType + "</td><td>" + _asn + "</td><td>" + _includesAbstract + "</td><td>");
						_paperBody += (_includesRebuttal +"</td></tr>");
					} else {
						_abstractCount++;
						_abstractBody += ("<tr><td><u><a target='_blank' href = '" + _fileLocation + "'>" + _results2[j].Name + "</a></u></td><td>");
						_abstractBody += (_documentVersion + "</td><td>" + _documentType + "</td><td>" + _asn + "</td></tr>");
					}
	            });

				if (_paperCount === 0) {
					_paperBody += ("<tr><td>No Documents</td></tr>");
				}
				_paperBody += "</table></fieldset>";

				if (_abstractCount === 0) {
					_abstractBody += ("<tr><td>No Documents</td></tr>");
				}
				_abstractBody += "</table></fieldset>";
				_dialogBody += (_paperBody + _abstractBody + "<br>");

			    _query = "PaperActionLog()?$filter=PaperID eq " + pID + "";

		        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
		            var _results3 = data.d.results;
					var _action = "",
		            	_userEdipi = "",
		            	_userName = "",
		            	_actionDate = "";

					if ( userRole != "REVWR") {
			        	_dialogBody += "<fieldset><legend><b>Workflow Actions</b></legend><table>";
			       		_dialogBody += ("<tr><td><b>Originator</b></td><td><b>Date/Time</b></td><td><b>Status</b></td></tr>");

			            AEP.$.each(_results3, function (i, item) {

					        if (_results3[i].Title != null) {
				                _action = _results3[i].Title;
				            }
				            else {
				            	_action = "";
				            }

					        if (_results3[i].UserEdipi1 != null) {
				                _userEdipi = _results3[i].UserEdipi1;
				            }
				            else {
				            	_userEdipi = "";
				            }

					        if (_results3[i].UserAlias1 != null) {
				                _userName = _results3[i].UserAlias1;
				            }
				            else {
				            	_userName = "";
				            }

					       /* if (_results3[i].PaperVersionNumber != null) {
				                _paperVersion = _results3[i].PaperVersionNumber;
				            }
				            else {
				            	_paperVersion = "1.0";
				            } */

		            		_actionDate = moment.utc(_results3[i].ActionDate).format('MM/DD/YYYY h:mm A');

			        		_dialogBody += ("<tr><td>" + _userName + "</td><td>" + _actionDate + "</td><td>" + _action + "</td></tr>");
			            });

				        _dialogBody += "</table></fieldset>";
					}

			        _dialogBody += "</div>";

			        if (document.getElementById('dialogPaperBody')) {
			            var elem = document.getElementById('dialogPaperBody');
			            elem.parentNode.removeChild(elem);
			        }

			        AEP.$("#dialog-paper").dialog({
			            modal: true,
			            draggable: false,
			            resizable: false,
			            show: 'blind',
			            hide: 'blind',
			            height: 600,
			            width: 900,
			            open: function () {
			                AEP.$("#dialog-paper").append(_dialogBody );
			            },
			            buttons: [
						    {
						        text: "Close",
						        click: function () {
						            AEP.$("#dialog-paper").dialog("close");

						        }
						    }
			            ]
			        });
		        }).fail(function (err) {
		            AEP.$.unblockUI();
		            AEP.Utility.Error.setFailure(err);
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

	assignPaperEditor =  function(pID, rowNumber) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

		var _declinedEditors = [];  // Need to track editors who have previously declined to review this paper
		var _query = "PaperActionLog()?$filter=(Title eq 'Associate Editor Declined Review' and PaperID eq " + pID + ")";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _actionLogResults = data.d.results;

            AEP.$.each(_actionLogResults, function (i, item) {
 			    _declinedEditors.push([_actionLogResults[i].UserEdipi1]);
            });

	        _query = "PaperDetails()?$expand=TagA,TagB,TagC,TagD,TagE&$filter=Id eq " + pID + "";

	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            var _results = data.d.results;
				var _paperName = "",
	            	_paperNo = "",
	            	_paperVersionNo = "",
	            	_assocEditorComments = "",
	            	_modifiedDate = "",
	            	_assocEditorEdipi = "",
	             	_assocEditorId = "",
	            	_reviewer1Edipi = "",
	            	_reviewer2Edipi = "",
	            	_reviewer3Edipi = "",
	            	_reviewer4Edipi = "",
	            	_reviewer5Edipi = "",
		           	_tagA = "",
	            	_tagB = "",
	            	_tagC = "",
	            	_tagD = "",
	            	_tagE = "",
					_tags = "";

	            if (_results[0].PaperName != null) {
	                _paperName = _results[0].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[0].PaperVersionNumber != null) {
	                _paperVersionNo = _results[0].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "";
	            }

	            if (_results[0].PaperNumber != null) {
	                _paperNo = _results[0].PaperNumber;
	            }
	            else {
	            	_paperNo = "";
	            }

	            if (_results[0].AssociateEditorComments != null) {
	                _assocEditorComments = _results[0].AssociateEditorComments;
	            }
	            else {
	            	_assocEditorComments = "";
	            }

	            if (_results[0].AssociateEditor != null) {
	                _assocEditorEdipi = _results[0].AssociateEditor;
	            }
	            else {
	            	_assocEditorEdipi = "";
	            }

	            if (_results[0].Reviewer1 != null) {
	                _reviewer1Edipi = _results[0].Reviewer1;
	            }
	            else {
	            	_reviewer1Edipi = "";
	            }

	            if (_results[0].Reviewer2 != null) {
	                _reviewer2Edipi = _results[0].Reviewer2;
	            }
	            else {
	            	_reviewer2Edipi = "";
	            }

	            if (_results[0].Reviewer3 != null) {
	                _reviewer3Edipi = _results[0].Reviewer3;
	            }
	            else {
	            	_reviewer3Edipi = "";
	            }

	            if (_results[0].Reviewer4 != null) {
	                _reviewer4Edipi = _results[0].Reviewer4;
	            }
	            else {
	            	_reviewer4Edipi = "";
	            }

	            if (_results[0].Reviewer5 != null) {
	                _reviewer5Edipi = _results[0].Reviewer5;
	            }
	            else {
	            	_reviewer5Edipi = "";
	            }

	            if ((_results[0].TagA != null) && (typeof _results[0].TagA.Title!= null)) {
	                _tagA = _results[0].TagA.Title;
	                _tags += _results[0].TagA.Title;
	            }

	            if ((_results[0].TagB != null) && (typeof _results[0].TagB.Title!= null)) {
	                _tagB = _results[0].TagB.Title;
	                _tags += "<br>" + _results[0].TagB.Title;
	            }

	            if ((_results[0].TagC != null) && (typeof _results[0].TagC.Title!= null)) {
	                _tagC = _results[0].TagC.Title;
	                _tags += "<br>" + _results[0].TagC.Title;
	            }

	            if ((_results[0].TagD != null) && (typeof _results[0].TagD.Title!= null)) {
	                _tagD = _results[0].TagD.Title;
	                _tags += "<br>" + _results[0].TagD.Title;
	            }

	            if ((_results[0].TagE != null) && (typeof _results[0].TagE.Title!= null)) {
	                _tagE = _results[0].TagE.Title;
	                _tags += "<br>" + _results[0].TagE.Title;
	            }

	            _modifiedDate = moment.utc(_results[0].Modified).format('MM/DD/YYYY h:mm A');

		        var _dialogBody = "<div id='dialogAssignBody'><b>Assign Paper</b><br><br>";

		        _dialogBody += ("<table cellspacing='2' cellpadding='2'><tr><td><b>Paper Short Name: </b></td><td>" + _paperName + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + _paperNo + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Tags: </b></td><td>" + _tags + "</td></tr>");

		        _dialogBody += ("<tr><td><b>Associate Editor: </b></td><td>");
		        _dialogBody += ("<select id='ddlAssocEditorAssign'>");
		        _dialogBody += ("<option> -- Choose -- </option>");

		        AEP.$.each(assocEditors, function (j, item) {
		            var _fullName = assocEditors[j][0],
		            	_listId = assocEditors[j][1],
		            	_edipi = assocEditors[j][2],
		            	_declinedEditor = false,
		            	_smeEditor = false;

					// Make sure they haven't previously declined to review this paper
			        AEP.$.each(_declinedEditors, function (q, item) {
						if (_declinedEditors[q][0] === _edipi) {
	        				_declinedEditor = true;
						}
					});

					if (!_declinedEditor) {

						if (_tagA != "") {

					        AEP.$.each(tagExperts, function (k, item) {
					        	if (tagExperts[k][0] === _tagA) {
									if (tagExperts[k][2] === _edipi) {
				        				_smeEditor = true;
									}
								}
							});
						}

						if ((!_smeEditor ) && (_tagB != "")) {

					        AEP.$.each(tagExperts, function (l, item) {
					        	if (tagExperts[l][0] === _tagB) {
									if (tagExperts[l][2] === _edipi) {
				        				_smeEditor = true;
									}
								}
							});
						}

						if ((!_smeEditor ) && (_tagC != "")) {

					        AEP.$.each(tagExperts, function (m, item) {
					        	if (tagExperts[m][0] === _tagC) {
									if (tagExperts[m][2] === _edipi) {
				        				_smeEditor = true;
									}
								}
							});
						}

						if ((!_smeEditor ) && (_tagD != "")) {

					        AEP.$.each(tagExperts, function (n, item) {
					        	if (tagExperts[n][0] === _tagD) {
									if (tagExperts[n][2] === _edipi) {
				        				_smeEditor = true;
									}
								}
							});
						}

						if ((!_smeEditor ) && (_tagE != "")) {

					        AEP.$.each(tagExperts, function (p, item) {
					        	if (tagExperts[p][0] === _tagE) {
									if (tagExperts[p][2] === _edipi) {
				        				_smeEditor = true;
									}
								}
							});
						}

				        _dialogBody += "<option ";
						if (_edipi === _assocEditorEdipi) {
				        	_dialogBody += "selected='selected' ";
						}
						if (_smeEditor) {
				        	_dialogBody += ("value=" + _edipi + ">" + _fullName + " * </option>");
						} else {
				        	_dialogBody += ("value=" + _edipi + ">" + _fullName + "</option>");
				        }
					}
				});

	        	_dialogBody += ("</select></td></tr>");

	        	if (_assocEditorComments != "") {
	        		_dialogBody += ("<tr><td></td><td><b>Associate Editor Comments</b></td></tr>");
	        		_dialogBody += ("<tr><td></td><td><textarea readonly cols='60' rows='6'>" + _assocEditorComments + "</textarea></td></tr>");
	        	}

		        _dialogBody += "</table></div>";

		        if (document.getElementById('dialogAssignBody')) {
		            var elem = document.getElementById('dialogAssignBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-assign").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 500,
		            width: 625,
		            open: function () {
		                AEP.$("#dialog-assign").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Assign",
					        click: function () {

								var _paperTable = AEP.$('#paperGrid').DataTable();
								_paperTable.cell(rowNumber,6).data("Awaiting Associate Editor Acceptance");
								_paperTable.cell(rowNumber,8).data("Awaiting Associate Editor Acceptance");

								AEP.journalUtil.writeLog("Associate Editor Assigned", pID, userLogin, userLoginName, _assocEditorEdipi);

			        			var _endpoint = "PaperDetails(" + pID + ")",
				                	_paperData = {};

								var e = document.getElementById("ddlAssocEditorAssign");
								var _ddlIndex = e.options[e.selectedIndex].index;
								var _assocEditorEdipi = e.options[e.selectedIndex].value;

								if (_ddlIndex === 0) {
									alert("Please select an Associate Editor.");
								} else {
				                	_paperData.AssociateEditor = _assocEditorEdipi;

									_paperData.Status = "Awaiting Associate Editor Acceptance"; // In Associated Editor Review

					                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

					                }).fail(function (err) {
					                    AEP.$.unblockUI();
					                    AEP.Utility.Error.setFailure(err);
					                });

						            AEP.$("#dialog-assign").dialog("close");
								}
					        }
					    },
					    {
					        text: "Cancel",
					        click: function () {
					            AEP.$("#dialog-assign").dialog("close");

					        }
					    }
		            ]
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

	approvePaper = function (pID, paperNo, paperVersionNo, rowNumber, userRole) {

        var _dialogBody = "<div id='dialogBody'><b>Approve Paper?</b><br><br>";

        _dialogBody += "Are you sure you want to approve Paper Number " + paperNo + "?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 500,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();

						_paperTable.cell(rowNumber,6).data("Author Providing Document for Style Edit");
						_paperTable.cell(rowNumber,8).data("Author Providing Document for Style Edit");

	        			var _actionTitle = "";

			        	switch (userRole) {
			       	  		case ("SREDT"):
			                	_actionTitle = "Senior Editor Approved Paper";
			                	break;
			       	  		case ("ASSOC"):
			                	_actionTitle = "Associate Editor Approved Paper";
			                	break;
			       	  		case ("ADMIN"):
			                	_actionTitle = "Administrator Approved Paper";
			                	break;
						}

						AEP.journalUtil.writeLog(_actionTitle, pID, userLogin, userLoginName);

	        			var _endpoint = "PaperDetails(" + pID + ")",
		                	_paperData = {};

						_paperData.Status = "Author Providing Document for Style Edit";

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

	rejectPaper = function (pID, paperNo, paperVersionNo, rowNumber, userRole) {

        var _dialogBody = "<div id='dialogBody'><b>Reject Paper?</b><br><br>";

        _dialogBody += "Are you sure you want to reject Paper Number " + paperNo + "?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 500,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();

						_paperTable.cell(rowNumber,6).data("Rejected");
						_paperTable.cell(rowNumber,8).data("Rejected");

	        			var _actionTitle = "";

			        	switch (userRole) {
			       	  		case ("SREDT"):
			                	_actionTitle = "Senior Editor Rejected Paper";
			                	break;
			       	  		case ("ASSOC"):
			                	_actionTitle = "Associate Editor Rejected Paper";
			                	break;
			       	  		case ("ADMIN"):
			                	_actionTitle = "Administrator Rejected Paper";
			                	break;
						}

						AEP.journalUtil.writeLog(_actionTitle, pID, userLogin, userLoginName);

	        			var _endpoint = "PaperDetails(" + pID + ")",
		                	_paperData = {};

						_paperData.Status = "Rejected";

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

	requestChanges = function (pID, paperNo, paperVersionNo, rowNumber, userRole) {

        var _dialogBody = "<div id='dialogBody'><b>Request Changes?</b><br><br>";

        _dialogBody += "Are you sure you want to open paper  " + paperNo + " (including attachments) for editing by the author?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 400,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();

						_paperTable.cell(rowNumber,6).data("Author Edit");
						_paperTable.cell(rowNumber,8).data("Author Edit");

	        			var _actionTitle = "";

			        	switch (userRole) {
			       	  		case ("SREDT"):
			                	_actionTitle = "Senior Editor Opened Paper for Changes";
			                	break;
			       	  		case ("ASSOC"):
			                	_actionTitle = "Associate Editor Opened Paper for Changes";
			                	break;
			       	  		case ("ADMIN"):
			                	_actionTitle = "Administrator Opened Paper for Changes";
			                	break;
						}

						AEP.journalUtil.writeLog(_actionTitle, pID, userLogin, userLoginName);

	        			var _endpoint = "PaperDetails(" + pID + ")",
		                	_paperData = {};

						_paperData.Status = "Author Edit";
						_paperData.SubmissionTypeValue = "Resubmit";

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

	requestRebuttal = function (pID, paperNo, paperVersionNo, rowNumber, userRole) {

        var _query = "PaperDetails()?$select=AuthorEdipi,Id&$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _author = "";

            if ((_results[0].AuthorEdipi != null)) {
                _author = _results[0].AuthorEdipi;
            }
            else {
            	_author = "";
            }

	        var _dialogBody = "<div id='dialogBody'><b>Release for Mandatory Changes?</b><br><br>";

	        _dialogBody += "Are you sure you want to open paper  " + paperNo + " (including attachments) for mandatory changes by the author?";
	        _dialogBody += "<br><br>Instructions for Author";
			_dialogBody += ("<textarea id='rebuttalInstruct' cols='80' rows='15'></textarea>");
	        _dialogBody += "</div>";

	        if (document.getElementById('dialogBody')) {
	            var elem = document.getElementById('dialogBody');
	            elem.parentNode.removeChild(elem);
	        }

	        AEP.$("#dialog-message").dialog({
	            modal: true,
	            draggable: false,
	            resizable: false,
	            show: 'blind',
	            hide: 'blind',
	            height: 400,
	            width: 550,
	            open: function () {
	                AEP.$("#dialog-message").append(_dialogBody );
	            },
	            buttons: [
					{
				        text: "Release with Attachments",
				        click: function () {

							// Update the display
							var _paperTable = AEP.$('#paperGrid').DataTable();

							_paperTable.cell(rowNumber,6).data("Author Rebuttal");
							_paperTable.cell(rowNumber,8).data("Author Rebuttal");

		        			var _actionTitle = "";

				        	switch (userRole) {
				       	  		case ("SREDT"):
				                	_actionTitle = "Senior Editor Opened Paper for Rebuttal";
				                	break;
				       	  		case ("ASSOC"):
				                	_actionTitle = "Associate Editor Opened Paper for Rebuttal";
				                	break;
				       	  		case ("ADMIN"):
				                	_actionTitle = "Administrator Opened Paper for Rebuttal";
				                	break;
							}

							AEP.journalUtil.writeLog(_actionTitle, pID, userLogin, userLoginName);

							var _subject = "Instructions for Author",
				            	_msgDetail = "",
				            	_messageData = {},
		        				_endpoint = "Messages()";

							e = document.getElementById("rebuttalInstruct");
							_msgDetail = e.value;

			                _messageData.Title = _subject;
			                _messageData.Sender = userLoginName;
			                _messageData.MessageDetail = _msgDetail;
			                _messageData.SenderEdipi = userLogin;
			                _messageData.RecipientEdipi = _author ;
			                _messageData.RecipientRole = "AUTHR";
			                _messageData.PaperId = pID;
				            _messageData.HasAttachmentsValue = "Yes";

        					AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

			                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _messageData)).success(function () {

			        			var _endpoint2 = "PaperDetails(" + pID + ")",
				                	_paperData = {};

								_paperData.Status = "Author Rebuttal";
								_paperData.SubmissionTypeValue = "Resubmit";

				                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint2, _paperData)).success(function () {

							        _query = "Messages()?$select=Paper,Id&$expand=Paper&$orderby=Id desc&$filter=PaperId eq " + pID + "";

							        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
							            var _results = data.d.results;

							            var _listId = _results[0].Id;

									    var options = {
									        url: "../Lists/Messages/MessageAttachments.aspx?ID="+_listId,
									        title: "Message Attachments",
									        width: 650,
									        height: 500
										    };

									    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);

							        }).fail(function (err) {
							            AEP.$.unblockUI();
							            AEP.Utility.Error.setFailure(err);
							        });

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

				            AEP.$("#dialog-message").dialog("close");
				        }
				    },
				    {
				        text: "Release without Attachments",
				        click: function () {

							// Update the display
							var _paperTable = AEP.$('#paperGrid').DataTable();

							_paperTable.cell(rowNumber,6).data("Author Rebuttal");
							_paperTable.cell(rowNumber,8).data("Author Rebuttal");

		        			var _actionTitle = "";

				        	switch (userRole) {
				       	  		case ("SREDT"):
				                	_actionTitle = "Senior Editor Opened Paper for Rebuttal";
				                	break;
				       	  		case ("ASSOC"):
				                	_actionTitle = "Associate Editor Opened Paper for Rebuttal";
				                	break;
				       	  		case ("ADMIN"):
				                	_actionTitle = "Administrator Opened Paper for Rebuttal";
				                	break;
							}

							AEP.journalUtil.writeLog(_actionTitle, pID, userLogin, userLoginName);

							var _subject = "Instructions for Author",
								_messageData = {},
		        				_endpoint = "Messages()";

							e = document.getElementById("rebuttalInstruct");
							var _msgDetail = e.value;

			                _messageData.Title = _subject;
			                _messageData.Sender = userLoginName;
			                _messageData.MessageDetail = _msgDetail;
			                _messageData.SenderEdipi = userLogin;
			                _messageData.RecipientEdipi = _author ;
			                _messageData.RecipientRole = "AUTHR";
			                _messageData.PaperId = pID;
				            _messageData.HasAttachmentsValue = "No";

			                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _messageData)).success(function () {

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

		        			var _endpoint2 = "PaperDetails(" + pID + ")",
			                	_paperData = {};

							_paperData.Status = "Author Rebuttal";
							_paperData.SubmissionTypeValue = "Resubmit";

			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint2, _paperData)).success(function () {

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

				            AEP.$("#dialog-message").dialog("close");
				        }
				    },
				    {
				        text: "No",
				        click: function () {

				            AEP.$("#dialog-message").dialog("close");
					    }
				    }
	            ]
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },

	viewReviews =  function(pID, userRole) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _paperName = "",
            	_paperNo = "",
            	_reviewer1Edipi = "",
            	_reviewer2Edipi = "",
            	_reviewer3Edipi = "",
            	_reviewer4Edipi = "",
            	_reviewer5Edipi = "",
            	_reviewer1Name = "Reviewer 1",
            	_reviewer2Name = "Reviewer 2",
            	_reviewer3Name = "Reviewer 3",
            	_reviewer4Name = "Reviewer 4",
            	_reviewer5Name = "Reviewer 5",
            	_reviewer1Status = "",
            	_reviewer2Status = "",
            	_reviewer3Status = "",
            	_reviewer4Status = "",
            	_reviewer5Status = "",
            	_reviewer1Recommend = "",
            	_reviewer2Recommend = "",
            	_reviewer3Recommend = "",
            	_reviewer4Recommend = "",
            	_reviewer5Recommend = "",
				_abstract = "";

			_paperName = _results[0].Title;
			_abstract = _results[0].Abstract;

            if (_results[0].PaperNumber != null) {
                _paperNo = _results[0].PaperNumber ;
            }
            else {
            	_paperNo = "";
            }

            if (_results[0].Reviewer1 != null) {
                _reviewer1Edipi = _results[0].Reviewer1;
            }
            else {
            	_reviewer1Edipi = "";
            }

            if (_results[0].Reviewer2 != null) {
                _reviewer2Edipi = _results[0].Reviewer2;
            }
            else {
            	_reviewer2Edipi = "";
            }

            if (_results[0].Reviewer3 != null) {
                _reviewer3Edipi = _results[0].Reviewer3;
            }
            else {
            	_reviewer3Edipi = "";
            }

            if (_results[0].Reviewer4 != null) {
                _reviewer4Edipi = _results[0].Reviewer4;
            }
            else {
            	_reviewer4Edipi = "";
            }

            if (_results[0].Reviewer5 != null) {
                _reviewer5Edipi = _results[0].Reviewer5;
            }
            else {
            	_reviewer5Edipi = "";
            }

	        var _dialogBody = "<div id='dialogReviewBody'><b>Paper Reviews</b><br><br>";

	        _dialogBody += "<table>";
	        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td span='3'>" + _paperName + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td span='3'>" + _paperNo + "</td></tr>");

			// Get the Reviewer names
	        AEP.$.each(reviewers, function (k, item) {
	            if (_reviewer1Edipi === reviewers[k][2]) {
	            	_reviewer1Name = reviewers[k][0];
	            }
	            if (_reviewer2Edipi === reviewers[k][2]) {
	            	_reviewer2Name = reviewers[k][0];
	            }
	            if (_reviewer3Edipi === reviewers[k][2]) {
	            	_reviewer3Name = reviewers[k][0];
	            }
	            if (_reviewer4Edipi === reviewers[k][2]) {
	            	_reviewer4Name = reviewers[k][0];
	            }
	            if (_reviewer5Edipi === reviewers[k][2]) {
	            	_reviewer5Name = reviewers[k][0];
	            }
   			});

			// Get each Review status
	 		var _query = "ReviewerEvaluation()?$select=Reviewer,Status,Recommendation,Id";
			_query += "&$expand=Recommendation&$filter=PaperId eq " + pID + "";

	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            var _results = data.d.results,
	            	_recommend;

	            AEP.$.each(_results, function (i, item) {

			        if (_results[i].Recommendation != null) {
		                _recommend = _results[i].Recommendation.Value;
		            }
		            else {
		            	_recommend = "";
		            }

		            if (_results[i].Reviewer === _reviewer1Edipi) {
		            	_reviewer1Status = _results[i].Status;
		            	_reviewer1Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer2Edipi) {
		            	_reviewer2Status = _results[i].Status;
		            	_reviewer2Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer3Edipi) {
		            	_reviewer3Status = _results[i].Status;
		            	_reviewer3Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer4Edipi) {
		            	_reviewer4Status = _results[i].Status;
		            	_reviewer4Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer5Edipi) {
		            	_reviewer5Status = _results[i].Status;
		            	_reviewer5Recommend = _recommend;
		            }

	            });

		        _dialogBody += ("<tr><td></td><td><b>Reviewer</b></td><td><b>Review Status</b></td><td><b>Recommendation</b></td><td></td></tr>");

		        if (_reviewer1Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>1: </b></td><td>" + _reviewer1Name + "</td><td>" + _reviewer1Status + "</td><td>" + _reviewer1Recommend + "</td>");
		        	if ( (_reviewer1Status === "Submitted") || (_reviewer1Status === "Declined") || (_reviewer1Status === "Released")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer2btn' title='Review' value='Review' onclick='AEP.journalUtil.viewReviewDetails(\"" + pID + "\",\"" + _reviewer1Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
	      		}
		        if (_reviewer2Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>2: </b></td><td>" + _reviewer2Name + "</td><td>" + _reviewer2Status + "</td><td>" + _reviewer2Recommend + "</td>");
		        	if ( (_reviewer2Status === "Submitted") || (_reviewer2Status === "Declined") || (_reviewer2Status === "Released")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer3btn' title='Review' value='Review' onclick='AEP.journalUtil.viewReviewDetails(\"" + pID + "\",\"" + _reviewer2Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }
		        if (_reviewer3Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>3: </b></td><td>" + _reviewer3Name + "</td><td>" + _reviewer3Status + "</td><td>" + _reviewer3Recommend + "</td>");
		        	if ( (_reviewer3Status === "Submitted") || (_reviewer3Status === "Declined") || (_reviewer3Status === "Released")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer1btn' title='Review' value='Review' onclick='AEP.journalUtil.viewReviewDetails(\"" + pID + "\",\"" + _reviewer3Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }
		        if (_reviewer4Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>4: </b></td><td>" + _reviewer4Name + "</td><td>" + _reviewer4Status + "</td><td>" + _reviewer4Recommend + "</td>");
		        	if ( (_reviewer4Status === "Submitted") || (_reviewer4Status === "Declined") || (_reviewer4Status === "Released")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer4btn' title='Review' value='Review' onclick='AEP.journalUtil.viewReviewDetails(\"" + pID + "\",\"" + _reviewer4Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }
		        if (_reviewer5Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>5: </b></td><td>" + _reviewer5Name + "</td><td>" + _reviewer5Status + "</td><td>" + _reviewer5Recommend + "</td>");
		        	if ( (_reviewer5Status === "Submitted") || (_reviewer5Status === "Declined") || (_reviewer5Status === "Released")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer5btn' title='Review' value='Review' onclick='AEP.journalUtil.viewReviewDetails(\"" + pID + "\",\"" + _reviewer5Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }

		        _dialogBody += "</table>";
		        _dialogBody += "</div>";

		        if (document.getElementById('dialogReviewBody')) {
		            var elem = document.getElementById('dialogReviewBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-review").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 400,
		            width: 600,
		            open: function () {
		                AEP.$("#dialog-review").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-review").dialog("close");
					        }
					    }
		            ]
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

    viewReviewDetails =  function(pID, reviewerEdipi, paperName, paperNo) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

 		var _query = "ReviewerEvaluation()?$expand=Attachments&$filter=PaperId eq " + pID + " and Reviewer eq '" + reviewerEdipi + "' and (Status eq 'Submitted'  or Status eq 'Declined' or Status eq 'Released')";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;

			if (_results.length === 0) {
				alert("Review not avaliable.");
			} else {
				var _id = _results[0].Id,
	                _attachFilename = "",
	                _attachLocation = "",
					_comments1 = "",
					_comments2 = "",
					_comments3 = "",
					_attachCount = 0,
					_editorEndorse = "",
					_webUrl = AEP.Utility.getWebRelativeUrl;

	            if (_results[0].CommentsForAuthor != null) {
	                _comments1 = _results[0].CommentsForAuthor;
	            }

	            if (_results[0].CommentsForEditor != null) {
	                _comments2 = _results[0].CommentsForEditor;
	            }

	            if (_results[0].EditorCommentsForAuthor != null) {
	                _comments3 = _results[0].EditorCommentsForAuthor;
	            }

		        var _dialogBody = "<div id='dialogReviewDetailBody'><b>Review Detail</b><br><br>";

		        _dialogBody += "<fieldset><table>";
		        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td span='3'>" + paperName + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + paperNo + "</td><td></td><td></td></tr>");
		        _dialogBody += "</table></fieldset>";


		        _dialogBody += "<fieldset><table>";
		        _dialogBody += ("<tr><td><b>Originality: </b></td><td>" + _results[0].OriginalityValue + "</td><td><b>Technically Plausible: </b></td><td>" + _results[0].TechnicalPlausibleValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Significance: </b></td><td>" + _results[0].SignificanceValue + "</td><td><b>Checked Equations: </b></td><td>" + _results[0].CheckedEquationsValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Scientific Relevance: </b></td><td>" + _results[0].ScientificRelevanceValue + "</td><td><b>Prior Publication: </b></td><td>" + _results[0].PriorPublicationValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Completeness: </b></td><td>" + _results[0].CompletenessValue + "</td><td><b>Commercialism Free: </b></td><td>" + _results[0].CommercialismFreeValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Acknowledgement: </b></td><td>" + _results[0].AcknowledgementValue + "</td><td><b>Title Brief: </b></td><td>" + _results[0].TitleBriefValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Organization: </b></td><td>" + _results[0].OrganizationValue + "</td><td><b>Abstract Clear: </b></td><td>" + _results[0].AbstractClearValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Clarity Of Writing: </b></td><td>" + _results[0].ClarityOfWritingValue + "</td><td><b>Willing to Review Revision: </b></td><td>" + _results[0].WillingReviewRevisionValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Clarity Of Tables: </b></td><td>" + _results[0].ClarityOfTablesValue + "</td><td></td><td></td></tr>");
		        _dialogBody += "</table></fieldset>";

		        _dialogBody += "<fieldset><table>";
		        _dialogBody += ("<tr><td><b>Endorse Review? </b></td><td>" + _results[0].EditorEndorsedValue + "</td></tr>");

		        _dialogBody += ("<tr><td><b>Recommendation: </b></td><td>" + _results[0].RecommendationValue + "</td></tr>");
		        _dialogBody += "</table></fieldset>";

		        _dialogBody += ("<br><b>Reviewer Comments For Editor</b>");
				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments2 + "</textarea>");

		        _dialogBody += ("<br><br><b>Reviewer Comments/Recommended Changes For Author</b>");
				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments1 + "</textarea>");

		        _dialogBody += ("<br><br><b>Comments For Author </b>");

				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments3 + "</textarea>");

               	_attachCount = _results[0].Attachments.results.length;

				if (_attachCount > 0) {
        			_dialogBody += ("<br><table><tr><td><b>Attachments:<b></td>");

                   	AEP.$.each(_results[0].Attachments.results, function (l, item) {
                        _attachFilename = _results[0].Attachments.results[l].Name;
                        _attachLocation = (_webUrl + "/Lists/Reviewer Evaluation/Attachments/" + _id + "/" + _attachFilename);
                        if (l === 0) {
        					_dialogBody += ("<td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
        				} else {
        					_dialogBody += ("<tr><td></td><td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
        				}
                    });
                    _dialogBody += "</table>";
				}

		        _dialogBody += "</div>";

		        if (document.getElementById('dialogReviewDetailBody')) {
		            var elem = document.getElementById('dialogReviewDetailBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-review-detail").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height:600,
		            width: 550,
		            open: function () {
		                AEP.$("#dialog-review-detail").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-review-detail").dialog("close");
					        }
					    }
		            ]
		        });
			}

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

	writeLog = function (actionTitle, paperId, edipi1, alias1, edipi2, alias2) {

        var _actionData = {},
			_endpoint = "PaperActionLog()";

        _actionData.Title = actionTitle;
        _actionData.PaperID = paperId;
		_actionData.UserEdipi1 = edipi1;
		_actionData.UserAlias1 = alias1;
		_actionData.UserEdipi2 = edipi2;
		_actionData.UserAlias2 = alias2;
		
        AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _actionData)).success(function () {

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	};

    return {
      	displayFiles : displayFiles,
      	getListItemAttachments : getListItemAttachments,
		checkNewUser : checkNewUser,
       	viewMessages : viewMessages,
      	newMessage : newMessage,
      	replyMessage : replyMessage,
      	assignPaperEditor : assignPaperEditor,
      	approvePaper : approvePaper,
      	rejectPaper : rejectPaper,
      	requestChanges : requestChanges,
      	requestRebuttal : requestRebuttal,
      	viewReviews : viewReviews,
      	viewReviewDetails : viewReviewDetails,
      	viewPaper : viewPaper,
      	writeLog : writeLog
    };
}());
