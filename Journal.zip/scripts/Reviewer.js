// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$(".tabs").tabs();
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userName = "",
    userNameId = 0;

AEP.$(function () {

    ExecuteOrDelayUntilScriptLoaded(AEP.reviewer.init, "sp.js");

});

AEP.reviewer = (function () {
    "use strict";

     var init =  function() {
		getUserInformation();
	 },

	 getUserInformation = function () {
        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var currentUser = web.get_currentUser();
        context.load(web, 'EffectiveBasePermissions');
        currentUser.retrieve();
        context.load(web);
        context.executeQueryAsync(
           function () { //On success function
               var userObject = web.get_currentUser();
               var email = userObject.get_email();
               var id = userObject.get_id();

               userLogin = userObject.get_loginName();
               var _loginParts = userObject.get_loginName().split("|");

               if (_loginParts[2] != null && (typeof _loginParts[2] != "undefined")) {
                   userLogin = _loginParts[2];
               }
               else {  // No edipi information
                   userLogin = _loginParts[0];
               }

               userName = userObject.get_title();
               var userEmail = userObject.get_email();

				AEP.init.loadRoleGroups();
				AEP.reviewer.getData.loadReviewList();

                AEP.journalUtil.checkNewUser(userLogin, userName, userEmail);

           },
          function () { //On fail function
              alert('Error: ' + args.get_message() + '\n' + args.get_stackTrace());
          }
       );
    };

     return {
     	init : init
    };
}());

AEP.reviewer.ui = (function () {
    "use strict";

     var acceptReview = function (pID, paperTitle, paperNo, paperID, paperVersionNo, rowNumber, gridRow) {

        var _dialogBody = "<div id='dialogBody'><b>Accept Review?</b><br><br>";

        _dialogBody += "Are you sure you want to accept review of Paper Number " + paperNo + "?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 500,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

	        			var _endpoint = "ReviewerAssignment(" + pID + ")",
		                _reviewData = {};

		                _reviewData.Status = "Open";

       					AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData)).success(function () {

							// Update the display
							var _reviewTable = AEP.$('#reviewGrid').DataTable();
							_reviewTable.cell(rowNumber,5).data("Open");
							_reviewTable.cell(rowNumber,8).data("Open");

					 		var _query = "ReviewerEvaluation()?$select=Id&$filter=PaperId eq " + paperID + " and Reviewer eq '" + userLogin + "'";
			                var _reviewData2 = {};

					        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
					            var _results = data.d.results;

								if (_results.length === 0) { // New review

		        					_endpoint = "ReviewerEvaluation()";
		                 			_reviewData2.Title = paperTitle;
		                 			_reviewData2.PaperNumber = paperNo;
					                _reviewData2.Status = "Open";
					                _reviewData2.Reviewer  = userLogin;
					                _reviewData2.DateAccepted = today;
					                _reviewData2.ReviewBeginDate = today;
					                _reviewData2.PaperId = paperID;

					                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _reviewData2)).success(function () {

										AEP.journalUtil.writeLog("Reviewer Accepts Review", paperID, userLogin, myReviewerAlias);

					                }).fail(function (err) {
					                    AEP.$.unblockUI();
					                    AEP.Utility.Error.setFailure(err);
					                });

								} else {  // Update review status

									var _reviewID = _results[0].Id;
					    			_endpoint = "ReviewerEvaluation(" + _reviewID + ")";

					                _reviewData2.Status = "Open";
					                _reviewData2.DateAccepted = today;
					                _reviewData2.ReviewBeginDate = today;

					                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData2)).success(function () {

										AEP.journalUtil.writeLog("Reviewer Accepts Review", paperID, userLogin, myReviewerAlias);

					                }).fail(function (err) {
					                    AEP.$.unblockUI();
					                    AEP.Utility.Error.setFailure(err);
					                });
								}
			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });
		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

	declineReview = function (pID, paperTitle, paperNo, paperID, paperVersionNo, rowNumber, gridRow) {

        var _dialogBody = "<div id='dialogBody'><b>Decline Review?</b><br><br>";

        _dialogBody += "Are you sure you want to decline review of Paper Number " + paperNo + "?";
        _dialogBody += "<br><br>Comments for Editor";
		_dialogBody += ("<textarea id='editorComments' cols='80' rows='15'></textarea>");
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 400,
            width: 550,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						var e = document.getElementById("editorComments");
						var _comments = e.value;

						if (_comments === "") {
						  alert("A Comment is required.");
						} else {

							// Update the display
							var _reviewTable = AEP.$('#reviewGrid').DataTable();
							_reviewTable.cell(rowNumber,5).data("Declined");
							_reviewTable.cell(rowNumber,8).data("Declined");

		        			var _endpoint = "ReviewerAssignment(" + pID + ")",
			                	_reviewData = {};

			                _reviewData.Status = "Declined";
							_reviewData.CommentsForEditor = _comments;

			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData)).success(function () {

						 		var _query = "ReviewerEvaluation()?$select=Id&$filter=PaperId eq " + paperID + " and Reviewer eq '" + userLogin + "'";
				                var _reviewData2 = {};

						        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
						            var _results = data.d.results;

									if (_results.length === 0) { // New review

			        					_endpoint = "ReviewerEvaluation()";
			                 			_reviewData2.Title = paperTitle;
			                 			_reviewData2.PaperNumber = paperNo;
						                _reviewData2.Status = "Declined";
						                _reviewData2.Reviewer  = userLogin;
						                _reviewData2.PaperId = paperID;

						                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _reviewData2)).success(function () {

											AEP.journalUtil.writeLog("Reviewer Declines Review", paperID, userLogin, myReviewerAlias);

						                }).fail(function (err) {
						                    AEP.$.unblockUI();
						                    AEP.Utility.Error.setFailure(err);
						                });

									} else {  // Update review status

										var _reviewID = _results[0].Id;
						    			_endpoint = "ReviewerEvaluation(" + _reviewID + ")";

						                _reviewData2.Status = "Declined";

						                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData2)).success(function () {

											AEP.journalUtil.writeLog("Reviewer Declines Review", paperID, userLogin, myReviewerAlias);

						                }).fail(function (err) {
						                    AEP.$.unblockUI();
						                    AEP.Utility.Error.setFailure(err);
						                });
									}
				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });
			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

				           	AEP.$("#dialog-message").dialog("close");
				    	}
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

    reviewPaper =  function(paperId) {

        var _query = "ReviewerEvaluation()?$select=Id";
        _query += "&$filter= (Reviewer eq '" + userLogin + "')  and (PaperId eq " + paperId + ")";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;

            var	_reviewId = _results[0].Id;

		    var options = {
		        url: "../Lists/Reviewer Evaluation/EditEvaluation.aspx?ID="+_reviewId,
		        title: "Review Evaluation",
		        width: 800,
		        height: 1100
		    };

		    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });

	},

	submitReview = function (pID, paperNo, paperID, paperVersionNo, rowNumber, gridRow) {

        var _dialogBody = "<div id='dialogBody'><b>Submit Review?</b><br><br>";

        _dialogBody += "Are you sure you want to submit review of Paper Number " + paperNo + "?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 400,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _reviewTable = AEP.$('#reviewGrid').DataTable();
						_reviewTable.cell(rowNumber,5).data("Submitted");
						_reviewTable.cell(rowNumber,8).data("Submitted");

						// Insert the action log record
						AEP.journalUtil.writeLog("Reviewer Submits Review", paperID, userLogin, myReviewerAlias);

						// Update the Review status
						var _endpoint = "ReviewerAssignment(" + pID + ")",
		                	_reviewData = {};

		                _reviewData.Status = "Submitted";

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData)).success(function () {

					        // Update Status on Review Evaluation record
					        var _query = "ReviewerEvaluation()?$select=Id";
					        _query += "&$filter= (Reviewer eq '" + userLogin + "')  and (PaperId eq " + paperID + ")";

					        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
					            var _results = data.d.results;

					            var	_reviewId = _results[0].Id;

								_endpoint = "ReviewerEvaluation(" + _reviewId + ")",
				                _reviewData = {};
				                _reviewData.Status = "Submitted";

				                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData)).success(function () {

									// Update the Paper status if necessary
							        _query = "PaperDetails()?$select=Status&$filter=Id eq " + paperID + "";

							        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
							            var _results2 = data.d.results;

							            if (_results2[0].Status === "SME Review") {

							                var _paperData = {};

											_endpoint = "PaperDetails(" + paperID + ")";

							                _paperData.Status = "Associate Editor Review of SME Feedback";

							                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

							                }).fail(function (err) {
							                    AEP.$.unblockUI();
							                    AEP.Utility.Error.setFailure(err);
							                });
							            }
					                }).fail(function (err) {
					                    AEP.$.unblockUI();
					                    AEP.Utility.Error.setFailure(err);
					                });
				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });
			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });
		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    };

     return {
     	acceptReview : acceptReview,
     	declineReview : declineReview,
      	reviewPaper : reviewPaper,
     	submitReview : submitReview
    };
}());


AEP.reviewer.getData = (function () {
    "use strict";

    var loadReviewList = function () {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "ReviewerAssignment()?$select=Title,Paper,Status,Id&$expand=Paper";
        _query += "&$filter= (Reviewer eq '" + userLogin + "') ";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_asn = "",
            	_psn = "",
            	_pn = "",
            	_paperName = "",
            	_paperId = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            _asn = "";
	           	_psn = "";
            	_paperId = "";

	            if ((_results[i].Paper != null) && (typeof _results[i].Paper != "undefined")) {
            		_paperId =  _results[i].Paper.Id;

		            if ((_results[i].Paper.PaperName != null) && (typeof _results[i].Paper.PaperName != "undefined")) {
		                _paperName = _results[i].Paper.PaperName;
		            }
		            else {
		            	_paperName = "";
		            }

	            	if ((_results[i].Paper.AbstractSecurityNumber != null) && (typeof _results[i].Paper.AbstractSecurityNumber != "undefined")) {
	                	_asn = _results[i].Paper.AbstractSecurityNumber;
	            	}
		            else {
		            	_asn = "";
		            }

	            	if ((_results[i].Paper.PaperSecurityNumber != null) && (typeof _results[i].Paper.PaperSecurityNumber != "undefined")) {
	                	_psn = _results[i].Paper.PaperSecurityNumber ;
	            	}
		            else {
		            	_psn = "";
		            }

		            if ((_results[i].Paper.PaperNumber != null) && (typeof _results[i].Paper.PaperNumber != "undefined")) {
		                _pn = _results[i].Paper.PaperNumber;
		            }
		            else {
		            	_pn = "";
		            }

		            if ((_results[i].Paper.PaperVersionNumber != null) && (typeof _results[i].Paper.PaperVersionNumber != "undefined")) {
		                _paperVersionNo = _results[i].Paper.PaperVersionNumber;
		            }
		            else {
		            	_paperVersionNo = "";
		            }

		            if ((_results[i].Paper.SubmittedDate != null) && (typeof _results[i].Paper.SubmittedDate != "undefined")) {
		                _submittedDate = moment.utc(_results[i].Paper.SubmittedDate).format('L');
	                	_submittedDateSort = moment.utc(_results[i].Paper.SubmittedDate).format('YYYYMMDDHHmmss');
		            }
		            else {
		            	_submittedDate = "";
	            		_submittedDateSort = "";
		            }
	            }

                _receivedData.push([_paperName, _pn, _asn, _psn, _submittedDate, _results[i].Status, _results[i].Id, _paperId, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

            var _reviewTable = AEP.$('#reviewGrid').DataTable({
                "dom": '<"paperToolbar">lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
                "order": [[9, "desc"]],
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,8] },
		        	{ "width": "220px", "targets": 8 },
		        	{ "targets": [6,7,9,10],
	        		  "visible": false
	        		},
		        	{ "targets": 8,
		        	  "render": function(data, type, row) {
			        	var _rowButtons = "";

			        	switch (data) {
			       	  		case ("Assigned"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 		+ '<div style="float: left; width: 48px;"><button aria-label="Accept Review" class="btn-accept" title="Accept Review"></button>Accept</div>'
    	  					 		+ '<div style="float: left; width: 48px;"><button aria-label="Decline Review" class="btn-reject" title="Decline Review"></button>Decline</div>'
    	  					 	break;
			       	  		case ("Open"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		    	  					+ '<div style="float: left; width: 48px;"><button aria-label="Review Paper" class="btn-review" title="Review Paper"></button>Review</div>'
		    	  					+ '<div style="float: left; width: 48px;"><button aria-label="Submit Review" class="btn-submit-review" title="Submit Review"></button>Submit</div>'
  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
   	  					 	break;
			       	  		case ("Submitted"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
  					 				 + '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
	   	  					 	break;

							default:
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
  					 				 + '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'

							}
				        return _rowButtons;
		        	  	}
			      	}
		        ]
            });

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-view', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.viewPaper(data[7], "REVWR");
        	});

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-review', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.reviewer.ui.reviewPaper(data[7]);
        	});

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-accept', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _reviewTable.row( AEP.$(this).parents('tr') ).index();
		        var row = _reviewTable.row( AEP.$(this).parents('tr'));
		        AEP.reviewer.ui.acceptReview(data[6], data[0], data[1], data[7], data[10], rowNumber, row);
        	});

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-reject', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _reviewTable.row( AEP.$(this).parents('tr') ).index();
		        var row = _reviewTable.row( AEP.$(this).parents('tr'));
		        AEP.reviewer.ui.declineReview(data[6], data[0], data[1], data[7], data[10], rowNumber, row);
        	});

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-submit-review', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _reviewTable.row( AEP.$(this).parents('tr') ).index();
		        var row = _reviewTable.row( AEP.$(this).parents('tr'));
		        AEP.reviewer.ui.submitReview(data[6], data[1], data[7], data[10], rowNumber, row);
        	});

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-files', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.displayFiles(data[7], data[1], "REVWR");
        	});

		    AEP.$('#reviewGrid tbody').on( 'click', '.btn-message', function (e) {
		        e.preventDefault();
		        var data = _reviewTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.viewMessages(data[7], "REVWR", myReviewerAlias);
        	});

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    };

    return {
        loadReviewList : loadReviewList
    };
}());
