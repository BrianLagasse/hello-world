﻿// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$(".tabs").tabs();
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userName = "",
    userNameId = 0;
    
AEP.$(function () {

    ExecuteOrDelayUntilScriptLoaded(AEP.author.init, "sp.js");

});

AEP.author = (function () {
    "use strict";
    
     var init =  function() {
		getUserInformation();
	 },
	 
	 getUserInformation = function () {
        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var currentUser = web.get_currentUser();
        context.load(web, 'EffectiveBasePermissions');
        currentUser.retrieve();
        context.load(web);
        context.executeQueryAsync(
           function () { //On success function
               var userObject = web.get_currentUser();
               var email = userObject.get_email();
               var id = userObject.get_id();

               userLogin = userObject.get_loginName();
               var _loginParts = userObject.get_loginName().split("|");

               if (_loginParts[2] != null && (typeof _loginParts[2] != "undefined")) {
                   userLogin = _loginParts[2];
               }
               else {  // No edipi information
                   userLogin = _loginParts[0];
               }

               userName = userObject.get_title();
               var userEmail = userObject.get_email();
               
			   AEP.init.loadRoleGroups();
			   AEP.author.getData.loadPaperList();

               AEP.journalUtil.checkNewUser(userLogin, userName, userEmail);

           },
          function () { //On fail function
              alert('Error: ' + args.get_message() + '\n' + args.get_stackTrace());
          }
       ); 
    };
    	 
     return {
     	init : init
    };
}());

AEP.author.ui = (function () {
    "use strict";

     var editPaper =  function(pID) {
 
	    var options = {
	        url: "../Lists/Paper Details/EditPaper.aspx?ID="+pID,
	        title: "Paper Details",
	        width: 640,
	        height: 800
	    };

	    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);
          
	 },

	 newPaper =  function() {
	
		var _edipi = userLogin,
			_webUrl = AEP.Utility.getWebRelativeUrl;
			//_guidelineLocation = (_webUrl + "/Shared Documents/2014 Build/Author Guidelines v1.docx");
			_guidelineLocation = (_webUrl + "/User_Resources/Author%20Submission%20Guide%20v%201-0.pdf");

        var _dialogBody = "<div id='dialogBody'><b>Create Paper</b><br><br>";

        _dialogBody += ("<table><tr>");
        _dialogBody += ("<td nowrap align='right'><label><b>Paper Short Name: </b></label></td><td><input type='text' id='aName' style='width: 300px;'/></td></tr><br><br>");
        _dialogBody += ("<td align='right'><label><b>Journal: </b></label></td>");
        _dialogBody += ("<td><select id='ddlJournal'>");

        _dialogBody += ("<option value='Journal of Army Science'>Journal of Army Science</option>");
		
        _dialogBody += ("</select></td></tr>");
        
		_dialogBody += ("<tr><td></td><td>Before beginning the paper submission process, please ensure you have read and complied with the author guidelines, ");
		_dialogBody += ("which will help you meet all qualifications for publishing.  Bear in mind that this is an UNCLASSIFIED information system.  ");
		_dialogBody += ("Your submission and all associated files must have a maximum classification of UNCLASSIFIED//FOUO.</td></tr>");
		_dialogBody += ("<tr><td></td><td><u><a target='_blank' href = '" + _guidelineLocation + "'>Author Guidelines</a></u></td></tr>");
        
        _dialogBody += "</table></div>";
  
        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }
      
        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 300,
            width: 500,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Save",
			        click: function () {

	        			var _endpoint = "PaperDetails()",
		                	_paperData = {};
		
						var e = document.getElementById("aName");
						var _paperName = e.value;

						e = document.getElementById("ddlJournal");
						_journalName = e.options[e.selectedIndex].value;
					
						if (_paperName === "") {
							alert("Please enter a Paper Short Name.");
						} else {
				            var _query = "PaperDetails()?$select=Id&$filter=PaperName eq '" + _paperName + "'";
				
        					AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

				            AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
				                var _results = data.d.results;
				                
					            if (_results.length > 0) {
					            	var _msg = "Paper Short Name '" +  _paperName + "' already exists. Please enter a new Paper Short Name."
									alert(_msg);
					            } else { 

					                _paperData.AuthorEdipi = _edipi;
					                _paperData.PaperName = _paperName;
					                _paperData.JournalNameValue = _journalName;
					                _paperData.Title = _paperName;
					
					                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _paperData)).success(function () {
		
							            _query = "PaperDetails()?$select=Id,JournalName&$expand=JournalName&$filter=PaperName eq '" + _paperName + "'";
							
							            AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
							                _results = data.d.results;
							
							                var _listId = _results[0].Id,
							                	_journalName = "",
							                	_last2Year = "",
							                	_paperNo = "",
							                	_zeroPad = "0000";
							                	
											// get the last 2 digits of the year
											_last2Year = parseInt(new Date().getFullYear().toString().substr(2,2));

								            if (_results[0].JournalName != null) {
								                _journalName = _results[0].JournalName.Value;
								            }
								            else {
								            	_journalName = "";
								            }
						                
						                	// set the paper number prefix
						                	switch (_journalName) {
						                		case "Journal of Army Science" :
						                			_paperNo = "JAS";
						                			break;
						                		default :
						                			_paperNo = "XXX";
						                			break;						                			
						                	}
						                	
						                	// zero pad the ID
						                	
											_paperNo += ("-" + _last2Year + (_zeroPad +_listId).slice(-4));
												
											_paperData.PaperNumber = _paperNo;

		        							_endpoint = "PaperDetails(" + _listId + ")";
											
							                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData )).success(function () {
		
												// Update the display
												var _paperTable = AEP.$('#paperGrid').DataTable();
												_paperTable.row.add( [ 
													_paperName,
													_paperNo,
													"",
													"",
													"",
													"",
													"Initiating Paper Process",
													_listId, 
													"Initiating Paper Process",
													"99999999999999",
													"1.0"													 
												]).draw(false);


								                AEP.journalUtil.writeLog("Paper Created", _listId, userLogin, myAuthorAlias);

											    var options = {
											        url: "../Lists/Paper Details/EditPaper.aspx?ID="+_listId,
											        title: "Paper Details",
											        width: 830,
											        height: 900
											    };
										
											    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);
											    
							                }).fail(function (err) {
							                    AEP.$.unblockUI();
							                    AEP.Utility.Error.setFailure(err);
							                });							       		
						                }).fail(function (err) {
						                    AEP.$.unblockUI();
						                    AEP.Utility.Error.setFailure(err);
						                });
					                }).fail(function (err) {
					                    AEP.$.unblockUI();
					                    AEP.Utility.Error.setFailure(err);
					                });						        
								}
			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                }); 
				           	AEP.$("#dialog-message").dialog("close"); 
						}	
			        }
			    },
			    {
			        text: "Cancel",
			        click: function () {
			            AEP.$("#dialog-message").dialog("close");

			        }
			    }
            ]
        });      
	 },
	 
	deletePaper = function (paperId, gridRow, rowNumber) {

        if (document.getElementById('submitDialogBody')) {
            var elem = document.getElementById('submitDialogBody');
            elem.parentNode.removeChild(elem);
        }
      		
        var _dialogBody = "<div id='submitDialogBody'><b>Delete Paper</b><br><br>";

	    _dialogBody += "Are you sure you want to delete this paper? </div>";
  
        AEP.$("#dialog-submit").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 300,
            open: function () {
                AEP.$("#dialog-submit").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						gridRow.remove().draw();
			                
	        			var _endpoint = "PaperDetails(" + paperId + ")",
		                	_paperData = {};
		                		
		                AEP.$.ajax(AEP.Utility.deleteItemRequest(_endpoint, _paperData )).success(function () {
	
			                AEP.journalUtil.writeLog("Paper Deleted", paperId, userLogin, myAuthorAlias);
								
		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });
			                		
			           	AEP.$("#dialog-submit").dialog("close"); 
			        }
			    },
			    {
			        text: "No",
			        click: function () {
			            AEP.$("#dialog-submit").dialog("close");

			        }
			    }
            ]
        });
    },

	submitPaper = function (paperId, paperVersionNo, gridRow, rowNumber) {

        if (document.getElementById('submitDialogBody')) {
            var elem = document.getElementById('submitDialogBody');
            elem.parentNode.removeChild(elem);
        }
      		
        var _dialogBody = "<div id='submitDialogBody'><b>Submit Paper</b><br><br>";

	    _dialogBody += "Are you sure you want to submit this paper?  By doing so, you are certifying that you have obtained the proper 3002F documentation for any edits you have made.</div>";
  
        AEP.$("#dialog-submit").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 300,
            open: function () {
                AEP.$("#dialog-submit").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();
						
						_paperTable.cell(rowNumber,4).data(moment.utc(today).format('L'));  
						_paperTable.cell(rowNumber,6).data("Associate Editor Assignment");  
						_paperTable.cell(rowNumber,8).data("Associate Editor Assignment");									

						var _query = "UserInfo()?$select=Edipi,SrEditor,Id&$expand=SrEditor&$filter=SrEditorValue eq 'Yes'";
						
			            AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
			                var _results = data.d.results;

							// Should only be 1 Senior Editor, so assign it to them
			                var _seniorEditor = _results[0].Edipi;
			                
	                		AEP.journalUtil.writeLog("Paper Submitted", paperId, userLogin, myAuthorAlias, _seniorEditor, "Senior Editor");

		        			var _endpoint = "PaperDetails(" + paperId + ")",
			                	_paperData = {};
			                
			                _paperData.Status = "Associate Editor Assignment";
			                _paperData.SeniorEditor = _seniorEditor;
			                _paperData.SubmittedDate = today;
			
			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData )).success(function () {
	
			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });
			
		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });
			                		
			           	AEP.$("#dialog-submit").dialog("close"); 
			        }
			    },
			    {
			        text: "No",
			        click: function () {
			            AEP.$("#dialog-submit").dialog("close");

			        }
			    }
            ]
        });
    },

	resubmitPaper = function (paperId, paperVersionNo, gridRow, rowNumber) {

        if (document.getElementById('submitDialogBody')) {
            var elem = document.getElementById('submitDialogBody');
            elem.parentNode.removeChild(elem);
        }
      		
        var _dialogBody = "<div id='submitDialogBody'><b>Resubmit Paper</b><br><br>";

	    _dialogBody += "Are you sure you want to resubmit this paper?  By doing so, you are certifying that you have obtained the proper 3002F documentation for any edits you have made.</div>";
  
        AEP.$("#dialog-submit").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 300,
            open: function () {
                AEP.$("#dialog-submit").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {
			                
						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();
						
						_paperTable.cell(rowNumber,6).data("Associate Editor Review");  
						_paperTable.cell(rowNumber,8).data("Associate Editor Review");									

		                AEP.journalUtil.writeLog("Paper Resubmitted", paperId, userLogin, myAuthorAlias);

	        			var _endpoint = "PaperDetails(" + paperId + ")",
		                	_paperData = {};
		                
		                _paperData.Status = "Associate Editor Review";
		
		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData )).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });
			                		
			           	AEP.$("#dialog-submit").dialog("close"); 
			        }
			    },
			    {
			        text: "No",
			        click: function () {
			            AEP.$("#dialog-submit").dialog("close");

			        }
			    }
            ]
        });
    },

	submitRebuttal = function (paperId, paperVersionNo, gridRow, rowNumber) {

        if (document.getElementById('submitDialogBody')) {
            var elem = document.getElementById('submitDialogBody');
            elem.parentNode.removeChild(elem);
        }
      		
        var _dialogBody = "<div id='submitDialogBody'><b>Submit Rebuttal</b><br><br>";

	    _dialogBody += "Are you sure you want to submit this rebuttal?  By doing so, you are certifying that you have obtained the proper 3002F documentation for any edits you have made.</div>";
  
        AEP.$("#dialog-submit").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 300,
            open: function () {
                AEP.$("#dialog-submit").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {
			                
						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();
						
						_paperTable.cell(rowNumber,6).data("Rebuttal Under Associate Editor Review");  
						_paperTable.cell(rowNumber,8).data("Rebuttal Under Associate Editor Review");									

	                	AEP.journalUtil.writeLog("Rebuttal Submitted", paperId, userLogin, myAuthorAlias);

	        			var _endpoint = "PaperDetails(" + paperId + ")",
		                	_paperData = {};
		                
		                _paperData.Status = "Rebuttal Under Associate Editor Review";
		
		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData )).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });
			                		
			           	AEP.$("#dialog-submit").dialog("close"); 
			        }
			    },
			    {
			        text: "No",
			        click: function () {
			            AEP.$("#dialog-submit").dialog("close");

			        }
			    }
            ]
        });
    },

	submitStyle = function (paperId, paperVersionNo, gridRow, rowNumber) {

        if (document.getElementById('submitDialogBody')) {
            var elem = document.getElementById('submitDialogBody');
            elem.parentNode.removeChild(elem);
        }
      		
        var _dialogBody = "<div id='submitDialogBody'><b>Submit to Style Editor</b><br><br>";

	    _dialogBody += "Are you sure you want to submit this paper to the Style Editor?  By doing so, you are certifying that you have obtained the proper 3002F documentation for any edits you have made.</div>";
  
        AEP.$("#dialog-submit").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 300,
            open: function () {
                AEP.$("#dialog-submit").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {
			                
						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();
						
						_paperTable.cell(rowNumber,6).data("Style Editor Review (Preliminary Approval)");  
						_paperTable.cell(rowNumber,8).data("Style Editor Review (Preliminary Approval)");									

		                AEP.journalUtil.writeLog("Author Submitted to Style Editor", paperId, userLogin, myAuthorAlias);
	
	        			var _endpoint = "PaperDetails(" + paperId + ")",
	        				_volumeNo = 1,
	        				_issueNo = 1,
	        				_currentMonth = 1,
		                	_paperData = {};
	
						_currentMonth = parseInt(new Date().getMonth().toString()) + 1;

						// Calculate the Volume and Issue Numbers
						_volumeNo = parseInt(new Date().getFullYear().toString()) - 2016;
						
			        	switch (_currentMonth) {
			       	  		case (1):
			       	  		case (2):
			       	  		case (3):
								_issueNo = 2;
								break;
			       	  		case (4):
			       	  		case (5):
			       	  		case (6):
								_issueNo = 3;
								break;
			       	  		case (7):
			       	  		case (8):
			       	  		case (9):
								_issueNo = 4;
								break;
			       	  		case (10):
			       	  		case (11):
			       	  		case (12):
								_volumeNo += 1;  // New Volumne
								_issueNo = 1;
								break;
							default:
								_issueNo = 1;
			        	  		
							}

						if (_volumeNo === 0 ) // Handle pre-October 2016 submissions 
						{
							_volumeNo = 1;
							_issueNo = 1;
						}
						
						_paperData.VolumeNumber = _volumeNo;
						_paperData.IssueNumber = _issueNo ;
		                
		                _paperData.Status = "Style Editor Review (Preliminary Approval)";
		
		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData )).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });
			                		
			           	AEP.$("#dialog-submit").dialog("close"); 
			        }
			    },
			    {
			        text: "No",
			        click: function () {
			            AEP.$("#dialog-submit").dialog("close");

			        }
			    }
            ]
        });
    },

	viewReviews =  function(pID) {
           
        var _query = "PaperDetails()?$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _paperName = "",
            	_paperNo = "",
            	_reviewer1Edipi = "",
            	_reviewer2Edipi = "",
            	_reviewer3Edipi = "",
            	_reviewer4Edipi = "",
            	_reviewer5Edipi = "",
            	_reviewer1Name = "Reviewer 1",
            	_reviewer2Name = "Reviewer 2",
            	_reviewer3Name = "Reviewer 3",
            	_reviewer4Name = "Reviewer 4",
            	_reviewer5Name = "Reviewer 5",
            	_reviewer1Status = "",
            	_reviewer2Status = "",
            	_reviewer3Status = "",
            	_reviewer4Status = "",
            	_reviewer5Status = "",
            	_reviewer1Recommend = "",
            	_reviewer2Recommend = "",
            	_reviewer3Recommend = "",
            	_reviewer4Recommend = "",
            	_reviewer5Recommend = "",
				_abstract = "";

			_paperName = _results[0].Title;
			_abstract = _results[0].Abstract;

            if (_results[0].PaperNumber != null) {
                _paperNo = _results[0].PaperNumber ;
            }
            else {
            	_paperNo = "";
            }

            if (_results[0].Reviewer1 != null) {
                _reviewer1Edipi = _results[0].Reviewer1;
            }
            else {
            	_reviewer1Edipi = "";
            }

            if (_results[0].Reviewer2 != null) {
                _reviewer2Edipi = _results[0].Reviewer2;
            }
            else {
            	_reviewer2Edipi = "";
            }

            if (_results[0].Reviewer3 != null) {
                _reviewer3Edipi = _results[0].Reviewer3;
            }
            else {
            	_reviewer3Edipi = "";
            }

            if (_results[0].Reviewer4 != null) {
                _reviewer4Edipi = _results[0].Reviewer4;
            }
            else {
            	_reviewer4Edipi = "";
            }

            if (_results[0].Reviewer5 != null) {
                _reviewer5Edipi = _results[0].Reviewer5;
            }
            else {
            	_reviewer5Edipi = "";
            }

	        var _dialogBody = "<div id='dialogReviewBody'><b>Paper Reviews</b><br><br>";
	
	        _dialogBody += "<table>";
	        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td span='3'>" + _paperName + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td span='3'>" + _paperNo + "</td></tr>");

			// Get each Review status
	 		var _query = "ReviewerEvaluation()?$select=Reviewer,Status,Recommendation,Id";
				_query += "&$expand=Recommendation&$filter=PaperId eq " + pID + "";
	
	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            var _results = data.d.results,
	            	_recommend;
	
	            AEP.$.each(_results, function (i, item) {
	
			        if (_results[i].Recommendation!= null) {
		                _recommend = _results[0].Recommendation.Value;
		            }
		            else {
		            	_recommend = "";
		            }

		            if (_results[i].Reviewer === _reviewer1Edipi) {
		            	_reviewer1Status = _results[i].Status;
		            	_reviewer1Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer2Edipi) {
		            	_reviewer2Status = _results[i].Status;
		            	_reviewer2Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer3Edipi) {
		            	_reviewer3Status = _results[i].Status;
		            	_reviewer3Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer4Edipi) {
		            	_reviewer4Status = _results[i].Status;
		            	_reviewer4Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer5Edipi) {
		            	_reviewer5Status = _results[i].Status;
		            	_reviewer5Recommend = _recommend;
		            }
		            
	            });       
		        _dialogBody += ("<tr><td></td><td><b>Reviewer</b></td><td><b>Review Status</b></td><td><b>Recommendation</b></td><td></td></tr>");

		        if (_reviewer1Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>1: </b></td><td>" + _reviewer1Name + "</td><td>" + _reviewer1Status + "</td><td>" + _reviewer1Recommend + "</td>");
		        	if (_reviewer1Status === "Released") {	        
		        		_dialogBody += ("<td><input type='button' name='reviewer1btn' title='Review' value='Review' onclick='AEP.author.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer1Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}  
	      		}	        
		        if (_reviewer2Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>2: </b></td><td>" + _reviewer2Name + "</td><td>" + _reviewer2Status + "</td><td>" + _reviewer2Recommend + "</td>");
		        	if (_reviewer2Status === "Released") {	        
		        		_dialogBody += ("<td><input type='button' name='reviewer2btn' title='Review' value='Review' onclick='AEP.author.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer2Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}  
		        }
		        if (_reviewer3Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>3: </b></td><td>" + _reviewer3Name + "</td><td>" + _reviewer3Status + "</td><td>" + _reviewer3Recommend + "</td>");
		        	if (_reviewer3Status === "Released") {	        
		        		_dialogBody += ("<td><input type='button' name='reviewer3btn' title='Review' value='Review' onclick='AEP.author.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer3Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}  
		        }
		        if (_reviewer4Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>4: </b></td><td>" + _reviewer4Name + "</td><td>" + _reviewer4Status + "</td><td>" + _reviewer4Recommend + "</td>");
		        	if (_reviewer4Status === "Released") {	        
		        		_dialogBody += ("<td><input type='button' name='reviewer4btn' title='Review' value='Review' onclick='AEP.author.ui.viewReviewDetails(\"" + pID + "\",\"" + reviewer4Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}  
		        }
		        if (_reviewer5Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>5: </b></td><td>" + _reviewer5Name + "</td><td>" + _reviewer5Status + "</td><td>" + _reviewer5Recommend + "</td>");
		        	if (_reviewer5Status === "Released") {	        
		        		_dialogBody += ("<td><input type='button' name='reviewer5btn' title='Review' value='Review' onclick='AEP.author.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer5Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}  
		        }
		        _dialogBody += "</table>";
		        _dialogBody += "</div>";
		  
		        if (document.getElementById('dialogReviewBody')) {
		            var elem = document.getElementById('dialogReviewBody');
		            elem.parentNode.removeChild(elem);
		        }
		      
		        AEP.$("#dialog-review").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 400,
		            width: 525,
		            open: function () {
		                AEP.$("#dialog-review").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-review").dialog("close");
		
					        }
					    }
		            ]
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        }); 
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        }); 
	},

    viewReviewDetails =  function(pID, reviewerEdipi, paperName, paperNo) {
 		var _query = "ReviewerEvaluation()?$expand=Attachments&$filter=PaperId eq " + pID + " and Reviewer eq '" + reviewerEdipi + "' and Status eq 'Released'";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;

			if (_results.length === 0) {
				alert("Review not avaliable.");			
			} else {
				var _id = _results[0].Id,
	                _attachFilename = "",
	                _attachLocation = "",
					_comments1 = "",
					_comments2 = "",
					_comments3 = "",
					_attachCount = 0,
					_webUrl = AEP.Utility.getWebRelativeUrl;
				
	            if (_results[0].CommentsForAuthor != null) {
	                _comments1 = _results[0].CommentsForAuthor;
	            }

	            if (_results[0].CommentsForEditor != null) {
	                _comments2 = _results[0].CommentsForEditor;
	            }

	            if (_results[0].EditorCommentsForAuthor != null) {
	                _comments3 = _results[0].EditorCommentsForAuthor;
	            }

		        var _dialogBody = "<div id='dialogReviewDetailBody'><b>Review Detail</b><br><br>";
		
		        _dialogBody += "<table>";
		        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td>" + paperName + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + paperNo + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Originality: </b></td><td>" + _results[0].OriginalityValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Significance: </b></td><td>" + _results[0].SignificanceValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Scientific Relevance: </b></td><td>" + _results[0].ScientificRelevanceValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Completeness: </b></td><td>" + _results[0].CompletenessValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Acknowledgement: </b></td><td>" + _results[0].AcknowledgementValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Organization: </b></td><td>" + _results[0].OrganizationValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Clarity Of Writing: </b></td><td>" + _results[0].ClarityOfWritingValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Clarity Of Tables: </b></td><td>" + _results[0].ClarityOfTablesValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Technically Plausible: </b></td><td>" + _results[0].TechnicalPlausibleValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Checked Equations: </b></td><td>" + _results[0].CheckedEquationsValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Prior Publication: </b></td><td>" + _results[0].PriorPublicationValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Commercialism Free: </b></td><td>" + _results[0].CommercialismFreeValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Title Brief: </b></td><td>" + _results[0].TitleBriefValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Abstract Clear: </b></td><td>" + _results[0].AbstractClearValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Recommendation: </b></td><td>" + _results[0].RecommendationValue + "</td></tr>");

		        _dialogBody += "</table>";

		        //_dialogBody += ("<br><b>Comments For Editor</b>");		 
				//_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments1 + "</textarea>");

		        _dialogBody += ("<br><br><b>Comments/Recommended Changes For Author</b>");		 
				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments2 + "</textarea>");
		        //_dialogBody += ("<br><b>Recommendation: </b>" + _results[0].RecommendationValue + "");

		        //_dialogBody += ("<br><br><b>Editor Endorsed? </b>" + _results[0].EditorEndorsedValue + "");
		        _dialogBody += ("<br><br><b>Editor Comments For Author</b>");		 
				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments3 + "</textarea>");

               	_attachCount = _results[0].Attachments.results.length;

				if (_attachCount > 0) {
        			_dialogBody += ("<br><table><tr><td><b>Attachments:<b></td>");
		        
                   	AEP.$.each(_results[0].Attachments.results, function (l, item) {
                        _attachFilename = _results[0].Attachments.results[l].Name;
                        _attachLocation = (_webUrl + "/Lists/Reviewer Evaluation/Attachments/" + _id + "/" + _attachFilename);
                        if (l === 0) {
        					_dialogBody += ("<td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
        				} else {
        					_dialogBody += ("<tr><td></td><td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
        				}                              	
                    });	
                    _dialogBody += "</table>";					
				}		

		        _dialogBody += "</div>";
		  
		        if (document.getElementById('dialogReviewDetailBody')) {
		            var elem = document.getElementById('dialogReviewDetailBody');
		            elem.parentNode.removeChild(elem);
		        }
			      
		        AEP.$("#dialog-review-detail").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 800,
		            width: 550,
		            open: function () {
		                AEP.$("#dialog-review-detail").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-review-detail").dialog("close");
		
					        }
					    }
		            ]
		        });         
			}
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });          
	 };
	  
     return {
      	editPaper : editPaper,
       	newPaper : newPaper,
       	deletePaper : deletePaper,
       	submitPaper : submitPaper,
       	resubmitPaper : resubmitPaper,
       	submitRebuttal : submitRebuttal,
       	submitStyle : submitStyle,
        viewReviews : viewReviews,
        viewReviewDetails : viewReviewDetails
    };
}());

   
AEP.author.getData = (function () {
    "use strict";

    var loadPaperList = function () {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$select=Title,PaperName,AbstractSecurityNumber,PaperNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,Id&$filter=AuthorEdipi eq '" + userLogin + "'";

		var _receivedData = [];

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_asn = "",
            	_psn = "",
            	_pn = "",
            	_paperName = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
            	_finalApprovedDate = "";
                
            AEP.$.each(_results, function (i, item) {

	            if ((_results[i].AbstractSecurityNumber != null) && (typeof _results[i].AbstractSecurityNumber != "undefined")) {
	                _asn = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_asn = "";
	            }

	            if ((_results[i].PaperSecurityNumber != null) && (typeof _results[i].PaperSecurityNumber != "undefined")) {
	                _psn = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_psn = "";
	            }

	            if ((_results[i].PaperNumber != null) && (typeof _results[i].PaperNumber != "undefined")) {
	                _pn = _results[i].PaperNumber;
	            }
	            else {
	            	_pn = "";
	            }

	            if ((_results[i].PaperName != null) && (typeof _results[i].PaperName != "undefined")) {
	                _paperName = _results[i].PaperName ;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "99999999999999";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _pn, _asn, _psn, _submittedDate, _finalApprovedDate, _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

            var _paperTable = AEP.$('#paperGrid').DataTable({
                "dom": '<"paperToolbar">lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
                "order": [[9, "desc"], [7, "desc"]],
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [ 
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,6,8] },
		        	{ "width": "290px", "targets": 8 },
		        	{ "targets": [7,9,10],
	        		  "visible": false
	        		},
		        	{ "targets": 8,
		        	  "render": function(data, type, row) {
			        	  	var _rowButtons = "";
			        	  	
			        	switch (data) {
			       	  		case ("Initiating Paper Process"):
			        	  		_rowButtons = '<div style="float: left; width: 48px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Edit Paper" class="btn-edit" title="Edit Paper"></button>Edit</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Submit Paper" class="btn-submit" title="Submit Paper"></button>Submit</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Delete Paper" class="btn-delete" title="Delete Paper"></button>Delete</div>'
    	  					 	break;
			       	  		case ("Author Edit"):
			        	  		_rowButtons = '<div style="float: left; width: 48px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Edit Paper" class="btn-edit" title="Edit Paper"></button>Edit</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Resubmit" class="btn-resubmit" title="Resubmit"></button>Resubmit</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("SME Review"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Author Rebuttal"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Edit Paper" class="btn-edit" title="Edit Paper"></button>Edit</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Submit Rebuttal" class="btn-submit-rebuttal" title="Submit Rebuttal"></button>Submit</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Author Providing Document for Style Edit"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Submit to Style Editor" class="btn-submit-style" title="Submit to Style Editor"></button>Submit</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Style Editor Review (Preliminary Approval)"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Edit Paper" class="btn-edit" title="Edit Paper"></button>Edit</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
    	  					 	
							default:
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
			        	  		
							}

				        return _rowButtons;
		        	  	}	 
			      	}
		        ]
            });

			AEP.$("div.paperToolbar").html('<table><tr><td><button aria-label="Create Paper" class="btn-new" type="button" title="Create Paper" onclick="AEP.author.ui.newPaper()"></button></td><td>Create Paper</td></tr></table>');
			     
		    AEP.$('#paperGrid tbody').on( 'click', '.btn-edit', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        AEP.author.ui.editPaper(data[7]);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-message', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        AEP.journalUtil.viewMessages(data[7], "AUTHR", myAuthorAlias);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-view', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        AEP.journalUtil.viewPaper(data[7], "AUTHR");
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-delete', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.author.ui.deletePaper(data[7], row, rowNumber);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-submit', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.author.ui.submitPaper(data[7], data[10], row, rowNumber);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-resubmit', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.author.ui.resubmitPaper(data[7], data[10], row, rowNumber);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-submit-rebuttal', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.author.ui.submitRebuttal(data[7], data[10], row, rowNumber);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-submit-style', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.author.ui.submitStyle(data[7], data[10], row, rowNumber);
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-files', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        AEP.journalUtil.displayFiles(data[7], data[0], "AUTHR");
        	}); 

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-review', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();		        
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.author.ui.viewReviews(data[7]);
        	}); 
        	
        	setInterval( function () {
        		reloadPaperList(_paperTable);
			}, 30000 );

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },
    
    reloadPaperList = function (paperTable) {

        var _query = "PaperDetails()?$select=Title,PaperName,AbstractSecurityNumber,PaperNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,Id&$filter=AuthorEdipi eq '" + userLogin + "'";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_asn = "",
            	_psn = "",
            	_pn = "",
            	_paperName = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
            	_finalApprovedDate = "",
                _receivedData = [];
                
            AEP.$.each(_results, function (i, item) {

	            if ((_results[i].AbstractSecurityNumber != null) && (typeof _results[i].AbstractSecurityNumber != "undefined")) {
	                _asn = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_asn = "";
	            }

	            if ((_results[i].PaperSecurityNumber != null) && (typeof _results[i].PaperSecurityNumber != "undefined")) {
	                _psn = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_psn = "";
	            }

	            if ((_results[i].PaperNumber != null) && (typeof _results[i].PaperNumber != "undefined")) {
	                _pn = _results[i].PaperNumber;
	            }
	            else {
	            	_pn = "";
	            }

	            if ((_results[i].PaperName != null) && (typeof _results[i].PaperName != "undefined")) {
	                _paperName = _results[i].PaperName ;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "99999999999999";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _pn, _asn, _psn, _submittedDate, _finalApprovedDate, _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

			paperTable.clear();
			paperTable.rows.add(_receivedData);
			paperTable.rows().invalidate().draw();

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    };
    
    return {
        loadPaperList : loadPaperList
    };
}());
