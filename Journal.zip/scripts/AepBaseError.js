﻿// IMPORTANT! ALL COMMENTS BELOW SHOULD BE REMOVED BEFORE MOVING CODE INTO PRODUCTION.

/*************************************************************************************
 *
 * File: AepBaseError-1.0.0.0-Dev.js
 *
 * Description: This file will be used as an addition to the AEPBase.js file while 
 *				creating code to be used in a development environment.
 *
 * Author: Eric Hudson
 *
 * Created: 4/9/2015
 *
 * Version: 1.0.0.0
 *
 * Version History
 *
 *		Version 1.0.0.0: 
 *
 *			Initial release
 *
 *************************************************************************************/
 /*************************************************************************************
 *
 * USAGE 
 *
 *
 * setFailure
 *
   		var AEP = AEP || {};
 		AEP.Utility = AEP.Utility || {};
 		AEP.$ = jQuery.noConflict();
 
 		AEP.GetData = (function() {
    	"use strict";
    		var load = function() {
        		var query = "TestList()?$select=Id,Title";
        		AEP.$.ajax(AEP.Utility.getRequest(query))
 					.success(function(data) {
           				var results = data.d.results;
            		})
 					.fail(function(err) {
            			AEP.Utility.Error.setFailure(err);
        			});
    			};
    		return {
        		load: load
    		};
  		}());
 * 		
 *************************************************************************************/

var AEP = AEP || {};
AEP.Utility.Error = AEP.Utility.Error || {};

AEP.Utility.Error = (function() {
    "use strict";
    var setFailure = function(err) {
     	console.log(err);
        alert(JSON.stringify(err));
        return setFailure;
    };
    return {
        setFailure: setFailure
    };
}());