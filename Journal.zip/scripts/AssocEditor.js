// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$(".tabs").tabs();
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userLoginName = "",
    userNameId = 0;

AEP.$(function () {

    ExecuteOrDelayUntilScriptLoaded(AEP.editorA.init, "sp.js");

});

AEP.editorA = (function () {
    "use strict";

     var init =  function() {
		getUserInformation();

	 },

	 getUserInformation = function () {
        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var currentUser = web.get_currentUser();
        context.load(web, 'EffectiveBasePermissions');
        currentUser.retrieve();
        context.load(web);
        context.executeQueryAsync(
           function () { //On success function
               var userObject = web.get_currentUser();
               var email = userObject.get_email();
               var id = userObject.get_id();

               userLogin = userObject.get_loginName();
               var _loginParts = userObject.get_loginName().split("|");

               if (_loginParts[2] != null && (typeof _loginParts[2] != "undefined")) {
                   userLogin = _loginParts[2];
               }
               else {  // No edipi information
                   userLogin = _loginParts[0];
               }

               var userName = userObject.get_title();
               var userEmail = userObject.get_email();

				AEP.init.loadRoleGroups();
				AEP.init.loadTagExperts();
				AEP.editorA.getData.loadAssocPaperList();
				AEP.editorA.getData.loadReviewerList();

                AEP.journalUtil.checkNewUser(userLogin, userName, userEmail);

           },
          function () { //On fail function
              alert('Error: ' + args.get_message() + '\n' + args.get_stackTrace());
          }
       );
    };

     return {
     	init : init
    };
}());

AEP.editorA.ui = (function () {
    "use strict";

     var assignPaperReviewers =  function(pID, rowNumber) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

		var _declinedReviewers = [];  // Need to track reviewers who have previously declined to review this paper
        var _query = "ReviewerAssignment()?$select=Reviewer,Id,PaperId&$filter=PaperId eq " + pID + " and Status eq 'Declined'";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _reviewResults = data.d.results;

            AEP.$.each(_reviewResults, function (i, item) {
 			    _declinedReviewers.push([_reviewResults[i].Reviewer]);
            });

	    	_query = "PaperDetails()?$select=PaperName,PaperNumber,PaperVersionNumber,TagA,TagB,TagC,TagD,TagE,Reviewer1,Reviewer2,Reviewer3,Reviewer4,Reviewer5&$expand=TagA,TagB,TagC,TagD,TagE&$filter=Id eq " + pID + "";

	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            var _results = data.d.results;
				var _paperName = "",
	            	_paperNo = "",
	            	_paperVersionNo = "",
	            	_reviewer1Edipi = "",
	            	_reviewer2Edipi = "",
	            	_reviewer3Edipi = "",
	            	_reviewer4Edipi = "",
	            	_reviewer5Edipi = "",
		           	_tagA = "",
	            	_tagB = "",
	            	_tagC = "",
	            	_tagD = "",
	            	_tagE = "",
					_tags = "";

	            if (_results[0].PaperName != null) {
	                _paperName = _results[0].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[0].PaperNumber != null) {
	                _paperNo = _results[0].PaperNumber ;
	            }
	            else {
	            	_paperNo = "";
	            }

	            if (_results[0].PaperVersionNumber != null) {
	                _paperVersionNo = _results[0].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "";
	            }

	            if (_results[0].Reviewer1 != null) {
	                _reviewer1Edipi = _results[0].Reviewer1;
	            }
	            else {
	            	_reviewer1Edipi = "";
	            }

	            if (_results[0].Reviewer2 != null) {
	                _reviewer2Edipi = _results[0].Reviewer2;
	            }
	            else {
	            	_reviewer2Edipi = "";
	            }

	            if (_results[0].Reviewer3 != null) {
	                _reviewer3Edipi = _results[0].Reviewer3;
	            }
	            else {
	            	_reviewer3Edipi = "";
	            }

	            if (_results[0].Reviewer4 != null) {
	                _reviewer4Edipi = _results[0].Reviewer4;
	            }
	            else {
	            	_reviewer4Edipi = "";
	            }

	            if (_results[0].Reviewer5 != null) {
	                _reviewer5Edipi = _results[0].Reviewer5;
	            }
	            else {
	            	_reviewer5Edipi = "";
	            }

	            if ((_results[0].TagA != null) && (typeof _results[0].TagA.Title!= null)) {
	                _tagA = _results[0].TagA.Title;
	                _tags += _results[0].TagA.Title;
	            }

	            if ((_results[0].TagB != null) && (typeof _results[0].TagB.Title!= null)) {
	                _tagB = _results[0].TagB.Title;
	                _tags += "<br>" + _results[0].TagB.Title;
	            }

	            if ((_results[0].TagC != null) && (typeof _results[0].TagC.Title!= null)) {
	                _tagC = _results[0].TagC.Title;
	                _tags += "<br>" + _results[0].TagC.Title;
	            }

	            if ((_results[0].TagD != null) && (typeof _results[0].TagD.Title!= null)) {
	                _tagD = _results[0].TagD.Title;
	                _tags += "<br>" + _results[0].TagD.Title;
	            }

	            if ((_results[0].TagE != null) && (typeof _results[0].TagE.Title!= null)) {
	                _tagE = _results[0].TagE.Title;
	                _tags += "<br>" + _results[0].TagE.Title;
	            }


		        var _dialogBody = "<div id='dialogAssignBody'><b>Assign Paper</b><br><br>";

		        _dialogBody += ("<table cellspacing='2' cellpadding='2'><tr><td><b>Paper Short Name: </b></td><td>" + _paperName + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + _paperNo + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Tags: </b></td><td>" + _tags + "</td><td><b>Re-Assign</b></td></tr>");

		     /*   _dialogBody += ("<tr><td><label><b>Senior Editor: </b></label></td><td>");
		        _dialogBody += ("<select id='ddlSrEditor'>");

		        AEP.$.each(srEditors, function (i, item) {
		            var _fullName = srEditors[i][0],
		            	_listId = srEditors[i][1];

			        _dialogBody += ("<option value=" + _listId + ">" + _fullName + "</option>");
				});

	        	_dialogBody += ("</select></td></tr>"); */

				var _reviewerList = [];

		        AEP.$.each(reviewers, function (k, item) {
		            var _fullName = reviewers[k][0],
		            	_listId = reviewers[k][1],
		            	_edipi = reviewers[k][2],
		            	_declinedReviewer = false,
		            	_smeReviewer = false;

					// Make sure they haven't previously declined to review this paper
			        AEP.$.each(_declinedReviewers, function (j, item) {
						if (_declinedReviewers[j][0] === _edipi) {
	        				_declinedReviewer = true;
						}
					});

					if (!_declinedReviewer) {
						if (_tagA != "") {

					        AEP.$.each(tagExperts, function (l, item) {
					        	if (tagExperts[l][0] === _tagA) {
									if (tagExperts[l][2] === _edipi) {
				        				_smeReviewer = true;
									}
								}
							});
						}

						if ((!_smeReviewer) && (_tagB != "")) {

					        AEP.$.each(tagExperts, function (m, item) {
					        	if (tagExperts[m][0] === _tagB) {
									if (tagExperts[m][2] === _edipi) {
				        				_smeReviewer = true;
									}
								}
							});
						}

						if ((!_smeReviewer) && (_tagC != "")) {

					        AEP.$.each(tagExperts, function (n, item) {
					        	if (tagExperts[n][0] === _tagC) {
									if (tagExperts[n][2] === _edipi) {
				        				_smeReviewer = true;
									}
								}
							});
						}

						if ((!_smeReviewer) && (_tagD != "")) {

					        AEP.$.each(tagExperts, function (p, item) {
					        	if (tagExperts[p][0] === _tagD) {
									if (tagExperts[p][2] === _edipi) {
				        				_smeReviewer = true;
									}
								}
							});
						}

						if ((!_smeReviewer) && (_tagE != "")) {

					        AEP.$.each(tagExperts, function (q, item) {
					        	if (tagExperts[q][0] === _tagE) {
									if (tagExperts[q][2] === _edipi) {
				        				_smeReviewer = true;
									}
								}
							});
						}

						if (_smeReviewer) {
							_fullName += " *";
						}

			    		_reviewerList.push([_edipi, _fullName]);
					}
				});

		        _dialogBody += ("<tr><td><b>Reviewer 1: </b></td><td>");
		        _dialogBody += ("<select id='ddlReviewer1'>");
		        _dialogBody += ("<option value=''> -- Choose -- </option>");
		        //_dialogBody += ("<select id='ddlReviewers' size='10' multiple>");

		        AEP.$.each(_reviewerList, function (k, item) {
			        _dialogBody += "<option ";
					if (_reviewerList[k][0] === _reviewer1Edipi) {
			        	_dialogBody += "selected='selected' ";
					}
			        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
				});

	        	_dialogBody += ("</select></td>");
	        	_dialogBody += ("<td align='center'><input id='cbxReassignment1' type='checkbox'></td></tr>");

		        _dialogBody += ("<tr><td><label><b>Reviewer 2: </b></label></td><td>");
		        _dialogBody += ("<select id='ddlReviewer2'>");
		        _dialogBody += ("<option value=''> -- Choose -- </option>");

		        AEP.$.each(_reviewerList, function (k, item) {
			        _dialogBody += "<option ";
					if (_reviewerList[k][0] === _reviewer2Edipi) {
			        	_dialogBody += "selected='selected' ";
					}
			        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
				});

	        	_dialogBody += ("</select></td>");
	        	_dialogBody += ("<td align='center'><input id='cbxReassignment2' type='checkbox'></td></tr>");

		        _dialogBody += ("<tr><td><label><b>Reviewer 3: </b></label></td><td>");
		        _dialogBody += ("<select id='ddlReviewer3'>");
		        _dialogBody += ("<option value=''> -- Choose -- </option>");

		        AEP.$.each(_reviewerList, function (k, item) {
			        _dialogBody += "<option ";
					if (_reviewerList[k][0] === _reviewer3Edipi) {
			        	_dialogBody += "selected='selected' ";
					}
			        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
				});

	        	_dialogBody += ("</select></td>");
	        	_dialogBody += ("<td align='center'><input id='cbxReassignment3' type='checkbox'></td></tr>");

		        _dialogBody += ("<tr><td><label><b>Reviewer 4: </b></label></td><td>");
		        _dialogBody += ("<select id='ddlReviewer4'>");
		        _dialogBody += ("<option value=''> -- Choose -- </option>");

		        AEP.$.each(_reviewerList, function (k, item) {
			        _dialogBody += "<option ";
					if (_reviewerList[k][0] === _reviewer4Edipi) {
			        	_dialogBody += "selected='selected' ";
					}
			        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
				});

	        	_dialogBody += ("</select></td>");
	        	_dialogBody += ("<td align='center'><input id='cbxReassignment4' type='checkbox'></td></tr>");

		        _dialogBody += ("<tr><td><label><b>Reviewer 5: </b></label></td><td>");
		        _dialogBody += ("<select id='ddlReviewer5'>");
		        _dialogBody += ("<option value=''> -- Choose -- </option>");

		        AEP.$.each(_reviewerList, function (k, item) {
			        _dialogBody += "<option ";
					if (_reviewerList[k][0] === _reviewer5Edipi) {
			        	_dialogBody += "selected='selected' ";
					}
			        _dialogBody += ("value=" + _reviewerList[k][0] + ">" + _reviewerList[k][1] + "</option>");
				});

	        	_dialogBody += ("</select></td>");
	        	_dialogBody += ("<td align='center'><input id='cbxReassignment5' type='checkbox'></td></tr>");

		        _dialogBody += "</table></div>";

		        if (document.getElementById('dialogAssignBody')) {
		            var elem = document.getElementById('dialogAssignBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-assign").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 500,
		            width: 600,
		            open: function () {
		                AEP.$("#dialog-assign").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Assign",
					        click: function () {

			        			var _endpoint = "PaperDetails(" + pID + ")",
			        				_reviewersEdipi = [],
				                	_paperData = {};

								var _reviewerNotSelected = true,
									_duplicateReviewer = false;

								var e = document.getElementById("ddlReviewer1");
								var _reviewer1Edipi = e.options[e.selectedIndex].value;

								if (e.options[e.selectedIndex].index != 0) {
									_reviewerNotSelected = false;
									_reviewersEdipi.push(_reviewer1Edipi);
								}

								var _reassignment1 = "";
								var e = document.getElementById("cbxReassignment1");

								if (e.checked == true)
								{
									_reassignment1 = "Reassign";
								}


								e = document.getElementById("ddlReviewer2");
								var _reviewer2Edipi = e.options[e.selectedIndex].value;

								if (e.options[e.selectedIndex].index != 0) {
									_reviewerNotSelected = false;
									if(jQuery.inArray(_reviewer2Edipi,_reviewersEdipi) === -1)
									{
										_reviewersEdipi.push(_reviewer2Edipi);
									}
									else
									{
										_duplicateReviewer = true;
									}
								}

								var _reassignment2 = "";
								var e = document.getElementById("cbxReassignment2");

								if (e.checked == true)
								{
									_reassignment2 = "Reassign";
								}


								e = document.getElementById("ddlReviewer3");
								var _reviewer3Edipi = e.options[e.selectedIndex].value;

								if (e.options[e.selectedIndex].index != 0) {
									_reviewerNotSelected = false;
									if(jQuery.inArray(_reviewer3Edipi,_reviewersEdipi) === -1)
									{
										_reviewersEdipi.push(_reviewer3Edipi);
									}
									else
									{
										_duplicateReviewer = true;
									}
								}

								var _reassignment3 = "";
								var e = document.getElementById("cbxReassignment3");

								if (e.checked == true)
								{
									_reassignment3 = "Reassign";
								}


								e = document.getElementById("ddlReviewer4");
								var _reviewer4Edipi = e.options[e.selectedIndex].value;

								if (e.options[e.selectedIndex].index != 0) {
									_reviewerNotSelected = false;
									if(jQuery.inArray(_reviewer4Edipi,_reviewersEdipi) === -1)
									{
										_reviewersEdipi.push(_reviewer4Edipi);
									}
									else
									{
										_duplicateReviewer = true;
									}
								}

								var _reassignment4 = "";
								var e = document.getElementById("cbxReassignment4");

								if (e.checked == true)
								{
									_reassignment4 = "Reassign";
								}


								e = document.getElementById("ddlReviewer5");
								var _reviewer5Edipi = e.options[e.selectedIndex].value;

								if (e.options[e.selectedIndex].index != 0) {
									_reviewerNotSelected = false;
									if(jQuery.inArray(_reviewer5Edipi,_reviewersEdipi) === -1)
									{
										_reviewersEdipi.push(_reviewer5Edipi);
									}
									else
									{
										_duplicateReviewer = true;
									}
								}

								var _reassignment5 = "";
								var e = document.getElementById("cbxReassignment5");

								if (e.checked == true)
								{
									_reassignment5 = "Reassign";
								}


								if (_reviewerNotSelected) {
									alert("Please select a Reviewer.");
								} else {
									if (_duplicateReviewer) {
										alert("Please do not select a Reviewer more than once.");
									} else {

										if (_reviewer1Edipi != "") {
						                	_paperData.Reviewer1 = _reviewer1Edipi;
						                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer1Edipi, _reassignment1);
						                }
										if (_reviewer2Edipi != "") {
						                	_paperData.Reviewer2 = _reviewer2Edipi;
						                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer2Edipi, _reassignment2);
						                }
										if (_reviewer3Edipi != "") {
						                	_paperData.Reviewer3 = _reviewer3Edipi;
						                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer3Edipi, _reassignment3);
						                }
										if (_reviewer4Edipi != "") {
						                	_paperData.Reviewer4 = _reviewer4Edipi;
						                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer4Edipi, _reassignment4);
						                }
										if (_reviewer5Edipi != "") {
						                	_paperData.Reviewer5 = _reviewer5Edipi;
						                	createReview(pID, _paperNo, _paperName, _paperVersionNo, _reviewer5Edipi, _reassignment5);
						                }

										var _paperTable = AEP.$('#paperGrid').DataTable();
										_paperTable.cell(rowNumber,6).data("SME Review");
										_paperTable.cell(rowNumber,8).data("SME Review");

										var _reviewerList = _reviewer1Edipi + " " + _reviewer2Edipi + " " + _reviewer3Edipi + " " + _reviewer4Edipi + " " + _reviewer5Edipi;

			            				AEP.journalUtil.writeLog("Associate Editor Assigns Reviewers", pID, userLogin, userLoginName, _reviewerList);

										_paperData.Status = "SME Review";

						                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

						                }).fail(function (err) {
						                    AEP.$.unblockUI();
						                    AEP.Utility.Error.setFailure(err);
						                });

							            AEP.$("#dialog-assign").dialog("close");
							    	}
								}
					        }
					    },
					    {
					        text: "Cancel",
					        click: function () {
					            AEP.$("#dialog-assign").dialog("close");

					        }
					    }
		            ]
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	 },

	acceptReview = function (pID, paperNo, paperVersionNo, rowNumber, gridRow) {

        var _dialogBody = "<div id='dialogBody'><b>Accept Review?</b><br><br>";

        _dialogBody += "Are you sure you want to accept Associate Editor Responsibilities for Paper Number " + paperNo + "?";
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 200,
            width: 400,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();
						_paperTable.cell(rowNumber,6).data("Associate Editor Review");
						_paperTable.cell(rowNumber,8).data("Associate Editor Review");

	                	AEP.journalUtil.writeLog("Associate Editor Accepted Review", pID, userLogin, userLoginName);

	        			var _endpoint = "PaperDetails(" + pID + ")",
		                	_paperData = {};

						_paperData.Status = "Associate Editor Review";

		                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-message").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

	declineReview = function (pID, paperNo, paperVersionNo, rowNumber, gridRow) {

        var _dialogBody = "<div id='dialogBody'><b>Decline Review?</b><br><br>";

        _dialogBody += "Are you sure you want to decline Associate Editor Responsibilities for Paper Number " + paperNo + "?";
        _dialogBody += "<br><br>Comments/Suggestions for Alternative Editor";
		_dialogBody += ("<textarea id='editorComments' cols='80' rows='15'></textarea>");
        _dialogBody += "</div>";

        if (document.getElementById('dialogBody')) {
            var elem = document.getElementById('dialogBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-message").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 400,
            width: 550,
            open: function () {
                AEP.$("#dialog-message").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						var e = document.getElementById("editorComments");
						var _comments = e.value;

						if (_comments === "") {
						  alert("A Comment is required.");
						} else {

							// Update the display
							gridRow.remove().draw();

	                		AEP.journalUtil.writeLog("Associate Editor Declined Review", pID, userLogin, userLoginName);

		        			var _endpoint = "PaperDetails(" + pID + ")",
			                	_paperData = {};

		                	_paperData.AssociateEditor = "";

							_paperData.Status = "Associate Editor Assignment";
							_paperData.AssociateEditorComments = userLoginName + ":" + _comments;

				            AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData)).success(function () {

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

				           	AEP.$("#dialog-message").dialog("close");
						}
			        }
			    },
			    {
			        text: "No",
			        click: function () {

			            AEP.$("#dialog-message").dialog("close");
				    }
			    }
            ]
        });
    },

	createReview = function (pID, paperNo, paperName, paperVersionNo, reviewer, reassignment) {

		AEP.journalUtil.writeLog("Reviewer Assigned", pID, userLogin, userLoginName, reviewer);

 		var _query = "ReviewerAssignment()?$select=Id,Status&$filter=PaperId eq " + pID + " and Reviewer eq '" + reviewer + "'";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;

			if (_results.length === 0) {

    			var _endpoint = "ReviewerAssignment()",
                 _reviewData= {};

                 _reviewData.Title = paperName;
                // _reviewData.PaperNumber = paperNo;
                 _reviewData.Reviewer = reviewer;
                 _reviewData.Status = "Assigned";
                 _reviewData.PaperId = pID;

                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _reviewData)).success(function () {

                }).fail(function (err) {
                    AEP.$.unblockUI();
                    AEP.Utility.Error.setFailure(err);
                });

			} else {

				var _reviewID = _results[0].Id,
					_status = _results[0].Status;

				if (reassignment === "Reassign") { // Only change status to Assigned if this is a reassignment

	    			var _endpoint = "ReviewerAssignment(" + _reviewID + ")",
	                _reviewData = {};

	                _reviewData.Status = "Assigned";

	                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData)).success(function () {

				 		_query = "ReviewerEvaluation()?$select=Id&$filter=PaperId eq " + pID + " and Reviewer eq '" + reviewer + "'";
		                var _reviewData2 = {};

				        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
				            var _results2 = data.d.results;

							if (_results2.length === 0) { // New review, don't do anything

							} else {

								var _reviewID2 = _results2[0].Id;
				    			_endpoint = "ReviewerEvaluation(" + _reviewID2 + ")";

				                _reviewData2.Status = "Assigned";

				                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData2)).success(function () {

						           // AEP.journalUtil.writeLog("Reviewer Re-Assigned", pID, userLogin, userLoginName, reviewer);

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });
							}
		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });
	                }).fail(function (err) {
	                    AEP.$.unblockUI();
	                    AEP.Utility.Error.setFailure(err);
	                });
				}
			}
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

	viewReviews =  function(pID, userRole) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _paperName = "",
            	_paperNo = "",
            	_reviewer1Edipi = "",
            	_reviewer2Edipi = "",
            	_reviewer3Edipi = "",
            	_reviewer4Edipi = "",
            	_reviewer5Edipi = "",
            	_reviewer1Name = "Reviewer 1",
            	_reviewer2Name = "Reviewer 2",
            	_reviewer3Name = "Reviewer 3",
            	_reviewer4Name = "Reviewer 4",
            	_reviewer5Name = "Reviewer 5",
            	_reviewer1Status = "Assigned",
            	_reviewer2Status = "Assigned",
            	_reviewer3Status = "Assigned",
            	_reviewer4Status = "Assigned",
            	_reviewer5Status = "Assigned",
            	_reviewer1Recommend = "",
            	_reviewer2Recommend = "",
            	_reviewer3Recommend = "",
            	_reviewer4Recommend = "",
            	_reviewer5Recommend = "",
				_abstract = "";

			_paperName = _results[0].PaperName;
			_abstract = _results[0].Abstract;

            if (_results[0].PaperNumber != null) {
                _paperNo = _results[0].PaperNumber ;
            }
            else {
            	_paperNo = "";
            }

            if (_results[0].Reviewer1 != null) {
                _reviewer1Edipi = _results[0].Reviewer1;
            }
            else {
            	_reviewer1Edipi = "";
            }

            if (_results[0].Reviewer2 != null) {
                _reviewer2Edipi = _results[0].Reviewer2;
            }
            else {
            	_reviewer2Edipi = "";
            }

            if (_results[0].Reviewer3 != null) {
                _reviewer3Edipi = _results[0].Reviewer3;
            }
            else {
            	_reviewer3Edipi = "";
            }

            if (_results[0].Reviewer4 != null) {
                _reviewer4Edipi = _results[0].Reviewer4;
            }
            else {
            	_reviewer4Edipi = "";
            }

            if (_results[0].Reviewer5 != null) {
                _reviewer5Edipi = _results[0].Reviewer5;
            }
            else {
            	_reviewer5Edipi = "";
            }

	        var _dialogBody = "<div id='dialogReviewBody'><b>Paper Reviews</b><br><br>";

	        _dialogBody += "<table>";
	        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td span='3'>" + _paperName + "</td></tr>");
	        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td span='3'>" + _paperNo + "</td></tr>");

			// Get the Reviewer names
	        AEP.$.each(reviewers, function (k, item) {
	            if (_reviewer1Edipi === reviewers[k][2]) {
	            	_reviewer1Name = reviewers[k][0];
	            }
	            if (_reviewer2Edipi === reviewers[k][2]) {
	            	_reviewer2Name = reviewers[k][0];
	            }
	            if (_reviewer3Edipi === reviewers[k][2]) {
	            	_reviewer3Name = reviewers[k][0];
	            }
	            if (_reviewer4Edipi === reviewers[k][2]) {
	            	_reviewer4Name = reviewers[k][0];
	            }
	            if (_reviewer5Edipi === reviewers[k][2]) {
	            	_reviewer5Name = reviewers[k][0];
	            }
   			});

			// Get each Review status
	 		var _query = "ReviewerEvaluation()?$select=Reviewer,Status,Recommendation,Id";
				_query += "&$expand=Recommendation&$filter=PaperId eq " + pID + "";

	        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
	            var _results = data.d.results,
	            	_recommend;

	            AEP.$.each(_results, function (i, item) {

			        if (_results[i].Recommendation != null) {
		                _recommend = _results[i].Recommendation.Value;
		            }
		            else {
		            	_recommend = "";
		            }

		            if (_results[i].Reviewer === _reviewer1Edipi) {
		            	_reviewer1Status = _results[i].Status;
		            	_reviewer1Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer2Edipi) {
		            	_reviewer2Status = _results[i].Status;
		            	_reviewer2Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer3Edipi) {
		            	_reviewer3Status = _results[i].Status;
		            	_reviewer3Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer4Edipi) {
		            	_reviewer4Status = _results[i].Status;
		            	_reviewer4Recommend = _recommend;
		            }
		            if (_results[i].Reviewer === _reviewer5Edipi) {
		            	_reviewer5Status = _results[i].Status;
		            	_reviewer5Recommend = _recommend;
		            }

	            });
		        _dialogBody += ("<tr><td></td><td><b>Reviewer</b></td><td><b>Review Status</b></td><td><b>Recommendation</b></td><td></td></tr>");

		        if (_reviewer1Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>1: </b></td><td>" + _reviewer1Name + "</td><td>" + _reviewer1Status + "</td><td>" + _reviewer1Recommend + "</td>");
		        	if ( (_reviewer1Status === "Submitted")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer2btn' title='Review' value='Review' onclick='AEP.editorA.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer1Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
	      		}
		        if (_reviewer2Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>2: </b></td><td>" + _reviewer2Name + "</td><td>" + _reviewer2Status + "</td><td>" + _reviewer2Recommend + "</td>");
		        	if ( (_reviewer2Status === "Submitted")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer3btn' title='Review' value='Review' onclick='AEP.editorA.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer2Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }
		        if (_reviewer3Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>3: </b></td><td>" + _reviewer3Name + "</td><td>" + _reviewer3Status + "</td><td>" + _reviewer3Recommend + "</td>");
		        	if ( (_reviewer3Status === "Submitted")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer1btn' title='Review' value='Review' onclick='AEP.editorA.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer3Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }
		        if (_reviewer4Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>4: </b></td><td>" + _reviewer4Name + "</td><td>" + _reviewer4Status + "</td><td>" + _reviewer4Recommend + "</td>");
		        	if ( (_reviewer4Status === "Submitted")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer4btn' title='Review' value='Review' onclick='AEP.editorA.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer4Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }
		        if (_reviewer5Edipi != "") {
		        	_dialogBody += ("<tr><td align='center'><b>5: </b></td><td>" + _reviewer5Name + "</td><td>" + _reviewer5Status + "</td><td>" + _reviewer5Recommend + "</td>");
		        	if ( (_reviewer5Status === "Submitted")) {
		        		_dialogBody += ("<td><input type='button' name='reviewer5btn' title='Review' value='Review' onclick='AEP.editorA.ui.viewReviewDetails(\"" + pID + "\",\"" + _reviewer5Edipi + "\",\"" + _paperName + "\",\"" + _paperNo +  "\")'/></td></tr>");
					} else {
						_dialogBody += "<td></td></tr>";
					}
		        }

		        _dialogBody += "</table>";
		        _dialogBody += "</div>";

		        if (document.getElementById('dialogReviewBody')) {
		            var elem = document.getElementById('dialogReviewBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-review").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height: 400,
		            width: 600,
		            open: function () {
		                AEP.$("#dialog-review").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-review").dialog("close");

					        }
					    }
		            ]
		        });
	        }).fail(function (err) {
	            AEP.$.unblockUI();
	            AEP.Utility.Error.setFailure(err);
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	},

    viewReviewDetails =  function(pID, reviewerEdipi, paperName, paperNo) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

 		var _query = "ReviewerEvaluation()?$expand=Attachments&$filter=PaperId eq " + pID + " and Reviewer eq '" + reviewerEdipi + "' and (Status eq 'Submitted'  or Status eq 'Declined' or Status eq 'Released')";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;

			if (_results.length === 0) {
				alert("Review not avaliable.");
			} else {
				var _id = _results[0].Id,
	                _attachFilename = "",
	                _attachLocation = "",
					_comments1 = "",
					_comments2 = "",
					_comments3 = "",
					_attachCount = 0,
					_editorEndorse = "",
					_webUrl = AEP.Utility.getWebRelativeUrl;

	            if (_results[0].CommentsForAuthor != null) {
	                _comments1 = _results[0].CommentsForAuthor;
	            }

	            if (_results[0].CommentsForEditor != null) {
	                _comments2 = _results[0].CommentsForEditor;
	            }

	            if (_results[0].EditorCommentsForAuthor != null) {
	                _comments3 = _results[0].EditorCommentsForAuthor;
	            }

		        var _dialogBody = "<div id='dialogReviewDetailBody'><b>Review Detail</b><br><br>";

		        _dialogBody += "<fieldset><table>";
		        _dialogBody += ("<tr><td><b>Paper Short Name: </b></td><td span='3'>" + paperName + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Paper Number: </b></td><td>" + paperNo + "</td><td></td><td></td></tr>");
		        _dialogBody += "</table></fieldset>";


		        _dialogBody += "<fieldset><table>";
		        _dialogBody += ("<tr><td><b>Originality: </b></td><td>" + _results[0].OriginalityValue + "</td><td><b>Technically Plausible: </b></td><td>" + _results[0].TechnicalPlausibleValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Significance: </b></td><td>" + _results[0].SignificanceValue + "</td><td><b>Checked Equations: </b></td><td>" + _results[0].CheckedEquationsValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Scientific Relevance: </b></td><td>" + _results[0].ScientificRelevanceValue + "</td><td><b>Prior Publication: </b></td><td>" + _results[0].PriorPublicationValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Completeness: </b></td><td>" + _results[0].CompletenessValue + "</td><td><b>Commercialism Free: </b></td><td>" + _results[0].CommercialismFreeValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Acknowledgement: </b></td><td>" + _results[0].AcknowledgementValue + "</td><td><b>Title Brief: </b></td><td>" + _results[0].TitleBriefValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Organization: </b></td><td>" + _results[0].OrganizationValue + "</td><td><b>Abstract Clear: </b></td><td>" + _results[0].AbstractClearValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Clarity Of Writing: </b></td><td>" + _results[0].ClarityOfWritingValue + "</td><td><b>Willing to Review Revision: </b></td><td>" + _results[0].WillingReviewRevisionValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Clarity Of Tables: </b></td><td>" + _results[0].ClarityOfTablesValue + "</td><td></td><td></td></tr>");
		        _dialogBody += "</table></fieldset>";

		       /* _dialogBody += ("<tr><td><b>Technically Plausible: </b></td><td>" + _results[0].TechnicalPlausibleValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Checked Equations: </b></td><td>" + _results[0].CheckedEquationsValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Prior Publication: </b></td><td>" + _results[0].PriorPublicationValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Commercialism Free: </b></td><td>" + _results[0].CommercialismFreeValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Title Brief: </b></td><td>" + _results[0].TitleBriefValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Abstract Clear: </b></td><td>" + _results[0].AbstractClearValue + "</td></tr>");
		        _dialogBody += ("<tr><td><b>Willing to Review Revision: </b></td><td>" + _results[0].WillingReviewRevisionValue + "</td></tr>");*/

		        _dialogBody += "<fieldset><table>";
		        _dialogBody += ("<tr><td><b>Recommendation: </b></td><td span='3'>" + _results[0].RecommendationValue + "</td></tr>");
		        _dialogBody += ("<tr><td><label><b>Endorse Review? </b></label></td><td>");
		        _dialogBody += ("<select id='ddlEndorse'>");

		        if (_results[0].EditorEndorsedValue === "Yes") {  // Set current value as selected
			        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
			        _dialogBody += ("<option value='No'>No</option>");
			    } else {
			        _dialogBody += ("<option value='Yes'>Yes</option>");
			        _dialogBody += ("<option selected='selected' value='No'>No</option>");
			    }
		        _dialogBody += ("</select></td><td></td><td></td></tr>");

		        _dialogBody += "</table></fieldset>";

		        _dialogBody += ("<br><b>Reviewer Comments For Editor</b>");
				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments2 + "</textarea>");

		        _dialogBody += ("<br><br><b>Reviewer Comments/Recommended Changes For Author</b>");
				_dialogBody += ("<textarea readonly cols='80' rows='6'>" + _comments1 + "</textarea>");


		        // _dialogBody += ("<br><br><b>Comments For Author </b>");

				//_dialogBody += ("<textarea id='editorComments' cols='80' rows='6'>" + _comments3 + "</textarea>");

               	_attachCount = _results[0].Attachments.results.length;

				if (_attachCount > 0) {
        			_dialogBody += ("<br><table><tr><td><b>Attachments:<b></td>");

                   	AEP.$.each(_results[0].Attachments.results, function (l, item) {
                        _attachFilename = _results[0].Attachments.results[l].Name;
                        _attachLocation = (_webUrl + "/Lists/Reviewer Evaluation/Attachments/" + _id + "/" + _attachFilename);
                        if (l === 0) {
        					_dialogBody += ("<td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
        				} else {
        					_dialogBody += ("<tr><td></td><td><a target='_blank' href = '" + _attachLocation + "'>" + _attachFilename + "</a></td></tr>");
        				}
                    });
                    _dialogBody += "</table>";
				}

		        _dialogBody += "</div>";

		        if (document.getElementById('dialogReviewDetailBody')) {
		            var elem = document.getElementById('dialogReviewDetailBody');
		            elem.parentNode.removeChild(elem);
		        }

		        AEP.$("#dialog-review-detail").dialog({
		            modal: true,
		            draggable: false,
		            resizable: false,
		            show: 'blind',
		            hide: 'blind',
		            height:600,
		            width: 550,
		            open: function () {
		                AEP.$("#dialog-review-detail").append(_dialogBody );
		            },
		            buttons: [
					    {
					        text: "Save",
					        click: function () {

		        			var _endpoint = "ReviewerEvaluation(" + _id + ")",
			                _reviewData = {};

							e = document.getElementById("ddlEndorse");
							_editorEndorse = e.options[e.selectedIndex].value;

			                _reviewData.EditorEndorsedValue = _editorEndorse;

			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _reviewData)).success(function () {

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

					        AEP.$("#dialog-review-detail").dialog("close");

					        }
					    },
					    {
					        text: "Close",
					        click: function () {
					            AEP.$("#dialog-review-detail").dialog("close");

					        }
					    }

		            ]
		        });
			}
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	 };

     return {
      	assignPaperReviewers : assignPaperReviewers,
		declineReview : declineReview,
		acceptReview : acceptReview,
      	viewReviews : viewReviews,
      	viewReviewDetails : viewReviewDetails
     };
}());


AEP.editorA.getData = (function () {
    "use strict";

    var loadAssocPaperList = function () {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$select=PaperName,PaperNumber,AbstractSecurityNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,Id";
        _query += "&$filter=( (AssociateEditor eq '" + userLogin + "'))";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_absSecNo = "",
            	_paperSecNo = "",
            	_paperName = "",
            	_paperNumber = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
            	_finalApprovedDate = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            if ((_results[i].AbstractSecurityNumber != null) && (typeof _results[i].AbstractSecurityNumber != "undefined")) {
	                _absSecNo = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_absSecNo = "";
	            }

	            if ((_results[i].PaperSecurityNumber != null) && (typeof _results[i].PaperSecurityNumber != "undefined")) {
	                _paperSecNo = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_paperSecNo = "";
	            }

	            if ((_results[i].PaperNumber != null) && (typeof _results[i].PaperNumber != "undefined")) {
	                _paperNumber = _results[i].PaperNumber;
	            }
	            else {
	            	_paperNumber = "";
	            }

	            if ((_results[i].PaperName != null) && (typeof _results[i].PaperName != "undefined")) {
	                _paperName = _results[i].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _paperNumber, _absSecNo, _paperSecNo, _submittedDate, _finalApprovedDate, _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

            var _paperTable = AEP.$('#paperGrid').DataTable({
                "dom": 'lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
                "order": [[9, "desc"]],
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,6,8] },
		        	{ "width": "340px", "targets": 8 },
		        	{ "targets": [7,9,10],
	        		  "visible": false
	        		},
		        	{ "targets": 8,
		        	  "render": function(data, type, row) {
			        	var _rowButtons = "";

			        	switch (data) {
			       	  		case ("Awaiting Associate Editor Acceptance"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		    	  					 		+ '<div style="float: left; width: 48px;"><button aria-label="Accept Review" class="btn-accept title="Accept Review"></button>Accept</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Decline Review" class="btn-decline" title="Decline Review"></button>Decline</div>'
    	  					 	break;
			       	  		case ("In Editor Review"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Request Changes" class="btn-changes" title="Request Changes"></button>Changes</div>'
    	  					 	break;
			       	  		case ("Associate Editor Review of SME Feedback"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Reviews" class="btn-review" title="Reviews"></button>Reviews</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Approve Paper" class="btn-approve" title="Approve Paper"></button>Approve</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 64px;"><button aria-label="Comments" class="btn-rebuttal" title="Release for Mandatory Changes"></button>Comments</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Rebuttal Under Associate Editor Review"):
			       	  		case ("Associate Editor Review"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Reviews" class="btn-review" title="Reviews"></button>Reviews</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Approve Paper" class="btn-approve" title="Approve Paper"></button>Approve</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Request Changes" class="btn-changes" title="Request Changes"></button>Changes</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("SME Review"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Reviews" class="btn-review" title="Reviews"></button>Reviews</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Approve Paper" class="btn-approve" title="Approve Paper"></button>Approve</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
			       	  		case ("Approved"):
			       	  		case ("Rejected"):
			       	  		case ("Author Edit"):
			       	  		case ("Author Rebuttal"):
			       	  		case ("Author Review"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
	   	  					 	break;

							default:
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'

							}
				        return _rowButtons;
		        	  	}
			      	}
		        ]
            });

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-view', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewPaper(data[7], "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-assign', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.editorA.ui.assignPaperReviewers(data[7], rowNumber);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-accept', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        AEP.editorA.ui.acceptReview(data[7], data[1], data[10], rowNumber, row);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-decline', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        AEP.editorA.ui.declineReview(data[7], data[1], data[10], rowNumber, row);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-changes', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.requestChanges(data[7],data[1], data[10], rowNumber, "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-rebuttal', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.requestRebuttal(data[7], data[1], data[10], rowNumber, "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-review', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.editorA.ui.viewReviews(data[7], "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-approve', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.approvePaper(data[7], data[1], data[10], rowNumber, "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-reject', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.rejectPaper(data[7], data[1], data[10], rowNumber, "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-files', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.displayFiles(data[7], data[1], "ASSOC");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-message', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewMessages(data[7], "ASSOC", userLoginName);
        	});

        	setInterval( function () {
        		reloadAssocPaperList(_paperTable);
			}, 30000 );

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },

	reloadAssocPaperList = function (paperTable) {

        var _query = "PaperDetails()?$select=PaperName,PaperNumber,AbstractSecurityNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,Id";
        _query += "&$filter=( (AssociateEditor eq '" + userLogin + "'))";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_absSecNo = "",
            	_paperSecNo = "",
            	_paperName = "",
            	_paperNumber = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
             	_finalApprovedDate = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            if ((_results[i].AbstractSecurityNumber != null) && (typeof _results[i].AbstractSecurityNumber != "undefined")) {
	                _absSecNo = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_absSecNo = "";
	            }

	            if ((_results[i].PaperSecurityNumber != null) && (typeof _results[i].PaperSecurityNumber != "undefined")) {
	                _paperSecNo = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_paperSecNo = "";
	            }

	            if ((_results[i].PaperNumber != null) && (typeof _results[i].PaperNumber != "undefined")) {
	                _paperNumber = _results[i].PaperNumber;
	            }
	            else {
	            	_paperNumber = "";
	            }

	            if ((_results[i].PaperName != null) && (typeof _results[i].PaperName != "undefined")) {
	                _paperName = _results[i].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _paperNumber, _absSecNo, _paperSecNo, _submittedDate, _finalApprovedDate, _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

			paperTable.clear();
			paperTable.rows.add(_receivedData);
			paperTable.rows().invalidate().draw();

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },

	loadReviewerList = function () {

        var _query = "UserInfo()?$select=FullName,Edipi,Email,ReviewerAlias,Id&$expand=Reviewer&$filter=Reviewer/Value eq 'Yes'";
		var _reviewerList = [];

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_edipi = "",
            	_alias = "",
            	_email = "";

            AEP.$.each(_results, function (i, item) {

	            if (_results[i].Edipi != null) {
	                _edipi = _results[i].Edipi;
	            }
	            else {
	            	_edipi = "";
	            }

	            if (_results[i].Email != null) {
	                _email = _results[i].Email;
	            }
	            else {
	            	_email = "";
	            }

	            if (_results[i].ReviewerAlias!= null) {
	                _alias = _results[i].ReviewerAlias;
	            }
	            else {
	            	_alias = "";
	            }

			    _reviewerList.push([_results[i].FullName, _alias, _email]);

            });

            var _reviewerTable = AEP.$('#reviewerGrid').DataTable({
                "dom": 'lfrTCRtip',
                "bDestroy": true,
                "aaData": _reviewerList ,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
                "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2] }
				]
            });

        }).fail(function (err) {
            AEP.Utility.Error.setFailure(err);
        });
	};

    return {
        loadAssocPaperList : loadAssocPaperList,
        loadReviewerList : loadReviewerList
    };
}());
