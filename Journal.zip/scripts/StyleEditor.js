// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$(".tabs").tabs();
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userLoginName = "",
    userNameId = 0;

AEP.$(function () {

    ExecuteOrDelayUntilScriptLoaded(AEP.styleEditor.init, "sp.js");

});

AEP.styleEditor = (function () {
    "use strict";

     var init =  function() {
		getUserInformation();
	 },

	 getUserInformation = function () {
        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var currentUser = web.get_currentUser();
        context.load(web, 'EffectiveBasePermissions');
        currentUser.retrieve();
        context.load(web);
        context.executeQueryAsync(
           function () { //On success function
               var userObject = web.get_currentUser();
               var email = userObject.get_email();
               var id = userObject.get_id();

               userLogin = userObject.get_loginName();
               var _loginParts = userObject.get_loginName().split("|");

               if (_loginParts[2] != null && (typeof _loginParts[2] != "undefined")) {
                   userLogin = _loginParts[2];
               }
               else {  // No edipi information
                   userLogin = _loginParts[0];
               }

               var userName = userObject.get_title();
               var userEmail = userObject.get_email();

				AEP.init.loadRoleGroups();
				AEP.init.loadTagExperts();
				AEP.styleEditor.getData.loadPaperList();

                AEP.journalUtil.checkNewUser(userLogin, userName, userEmail);

           },
          function () { //On fail function
              alert('Error: ' + args.get_message() + '\n' + args.get_stackTrace());
          }
       );
    };

     return {
     	init : init
    };
}());

AEP.styleEditor.ui = (function () {
    "use strict";

     var editPaper =  function(pID) {

	    var options = {
	        url: "../Lists/Paper Details/StyleEditorEditForm.aspx?ID="+pID,
	        title: "Paper Details",
	        width: 680,
	        height: 900
	    };

	    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);

	 },

	submitPaper = function (paperId, paperVersionNo, gridRow, rowNumber) {

        if (document.getElementById('submitDialogBody')) {
            var elem = document.getElementById('submitDialogBody');
            elem.parentNode.removeChild(elem);
        }

        var _dialogBody = "<div id='submitDialogBody'><b>Submit Final Paper</b><br><br>";

	    _dialogBody += "Are you sure you want to submit this paper?  Please note: the approved content of ";
	    _dialogBody += "the paper should not have changed.  If it has, new 3002F documentation is required.</div>";

        AEP.$("#dialog-submit").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 250,
            width: 400,
            open: function () {
                AEP.$("#dialog-submit").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Yes",
			        click: function () {

						// Update the display
						var _paperTable = AEP.$('#paperGrid').DataTable();

						_paperTable.cell(rowNumber,6).data("Senior Editor Final Review");
						_paperTable.cell(rowNumber,8).data("Senior Editor Final Review");

						var _query = "UserInfo()?$select=Edipi,SrEditor,Id&$expand=SrEditor&$filter=SrEditorValue eq 'Yes'";

			            AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
			                var _results = data.d.results;

							// Should only be 1 Senior Editor, so assign it to them
			                var _seniorEditor = _results[0].Edipi;

							AEP.journalUtil.writeLog("Style Editor Submit", paperId, userLogin, userLoginName, _seniorEditor, "Senior Editor");

		        			var _endpoint = "PaperDetails(" + paperId + ")",
			                	_paperData = {};

			                _paperData.Status = "Senior Editor Final Review";
			                _paperData.SeniorEditor = _seniorEditor;

			                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _paperData )).success(function () {

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

		                }).fail(function (err) {
		                    AEP.$.unblockUI();
		                    AEP.Utility.Error.setFailure(err);
		                });

			           	AEP.$("#dialog-submit").dialog("close");
			        }
			    },
			    {
			        text: "No",
			        click: function () {
			            AEP.$("#dialog-submit").dialog("close");

			        }
			    }
            ]
        });
    };

     return {
		editPaper : editPaper,
      	submitPaper : submitPaper
     };
}());


AEP.styleEditor.getData = (function () {
    "use strict";

    var loadPaperList = function () {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$select=PaperName,PaperNumber,AbstractSecurityNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,VolumeNumber,IssueNumber,Id";
        _query += "&$filter=( (Status eq 'Style Editor Review (Preliminary Approval)') or (Status eq 'Senior Editor Final Review') or (Status eq 'Final Approved'))";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_absSecNo = "",
            	_paperSecNo = "",
            	_paperName = "",
            	_paperNumber = "",
            	_paperVersionNo = "",
            	_volumeNumber = "",
            	_issueNumber = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            if (_results[i].AbstractSecurityNumber != null) {
	                _absSecNo = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_absSecNo = "";
	            }

	            if (_results[i].PaperSecurityNumber != null) {
	                _paperSecNo = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_paperSecNo = "";
	            }

	            if (_results[i].PaperNumber != null) {
	                _paperNumber = _results[i].PaperNumber;
	            }
	            else {
	            	_paperNumber = "";
	            }

	            if (_results[i].PaperName != null) {
	                _paperName = _results[i].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if (_results[i].VolumeNumber != null) {
	                _volumeNumber = _results[i].VolumeNumber;
	            }
	            else {
	            	_volumeNumber = "";
	            }

	            if (_results[i].IssueNumber != null) {
	                _issueNumber = _results[i].IssueNumber;
	            }
	            else {
	            	_issueNumber = "";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _paperNumber, _absSecNo, _paperSecNo, _submittedDate, _finalApprovedDate, _volumeNumber, _issueNumber,  _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

            var _paperTable = AEP.$('#paperGrid').DataTable({
                "dom": '<"paperToolbar">lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
                "order": [[11, "desc"]],
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,6,7,8,10] },
		        	{ "width": "216px", "targets": 10 },
		        	{ "targets": [9,11,12],
	        		  "visible": false
	        		},
		        	{ "targets": 10,
		        	  "render": function(data, type, row) {
			        	var _rowButtons = "";

			        	switch (data) {
			       	  		case ("Style Editor Review (Preliminary Approval)"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Edit Paper" class="btn-edit" title="Edit Paper"></button>Edit</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Final Submit" class="btn-submit" title="Final Submit"></button>Submit</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
    	  					 	break;
							default:
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'

							}
				        return _rowButtons;
		        	  	}
			      	}
		        ]
            });

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-view', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewPaper(data[9], "STYLE");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-edit', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.styleEditor.ui.editPaper(data[9]);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-submit', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var row = _paperTable.row( AEP.$(this).parents('tr'));
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.styleEditor.ui.submitPaper(data[9], data[12], row, rowNumber);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-files', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.displayFiles(data[9], data[0], "STYLE");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-message', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewMessages(data[9], "STYLE", 'StyleEditor');
        	});

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    };

    return {
        loadPaperList : loadPaperList
    };
}());
