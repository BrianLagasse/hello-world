﻿// JavaScript source code
var AEP = AEP || {};
AEP.Utility = AEP.Utility || {};
AEP.$(".tabs").tabs();
AEP.$ = jQuery.noConflict();

var userLogin = "",
    userName = "",
    userNameId = 0;

AEP.$(function () {

    ExecuteOrDelayUntilScriptLoaded(AEP.admin.init, "sp.js");

});

AEP.admin = (function () {
    "use strict";

     var init =  function() {

		getUserInformation();

	 },

	 getUserInformation = function () {
        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var currentUser = web.get_currentUser();
        context.load(web, 'EffectiveBasePermissions');
        currentUser.retrieve();
        context.load(web);
        context.executeQueryAsync(
           function () { //On success function
               var userObject = web.get_currentUser();
               var email = userObject.get_email();
               var id = userObject.get_id();

               userLogin = userObject.get_loginName();
               var _loginParts = userObject.get_loginName().split("|");

               if (_loginParts[2] != null && (typeof _loginParts[2] != "undefined")) {
                   userLogin = _loginParts[2];
               }
               else {  // No edipi information
                   userLogin = _loginParts[0];
               }

               userName = userObject.get_title();
               var userEmail = userObject.get_email();

			   AEP.init.loadRoleGroups();
			   AEP.init.loadTagExperts();
			   AEP.admin.getData.loadTagList();
			   AEP.admin.getData.loadPaperList();
			   AEP.admin.getData.loadUsers();

               AEP.journalUtil.checkNewUser(userLogin, userName, userEmail);

           },
          function () { //On fail function
              alert('Error: ' + args.get_message() + '\n' + args.get_stackTrace());
          }
       );
    };

     return {
     	init : init
    };
}());

AEP.admin.ui = (function () {
    "use strict";

     var newTag =  function() {

        var _dialogBody = "<div id='lookupBody'><b>Create Paper Tag</b><br><br>";

        _dialogBody += ("<label><b>Tag Name: </b><input type='text' id='tagName' style='width: 300px;'/></label>");
        _dialogBody += "</div>";

        if (document.getElementById('lookupBody')) {
            var elem = document.getElementById('lookupBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-lookup").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 300,
            width: 450,
            open: function () {
                AEP.$("#dialog-lookup").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Save",
			        click: function () {

	        			var _endpoint = "PaperTags()",
		                _tagData = {};

						var e = document.getElementById("tagName");
						var _tagTitle = e.value;

						if (_tagTitle === "") {
							alert("Please enter a Tag Name.");
						} else {

			                _tagData.Title = _tagTitle;

			                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _tagData)).success(function () {

					            _query = "PaperTags()?$select=Id&$filter=Title eq '" + _tagTitle + "'";

					            AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
					                _results = data.d.results;

					                var _listId = _results[0].Id;

									// Update the display
									var _tagTable = AEP.$('#tagsGrid').DataTable();
									_tagTable.row.add( [
										_tagTitle,
										_listId,
										'<button class="btn-edit" type="button" title="Edit"></button>',
									]).draw(false);

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

				           	AEP.$("#dialog-lookup").dialog("close");
				    	}
			        }
			    },
			    {
			        text: "Cancel",
			        click: function () {
			            AEP.$("#dialog-lookup").dialog("close");

			        }
			    }
            ]
        });
	},

	editTag =  function(pID, tagTitle, rowNumber) {

        var _dialogBody = "<div id='lookupBody'><b>Edit Paper Tag</b><br><br>";

        _dialogBody += ("<label><b>Tag Name: </b><input type='text' id='tagDesc' value='" + tagTitle + "' style='width: 300px;'/></label>");
        _dialogBody += "</div>";

        if (document.getElementById('lookupBody')) {
            var elem = document.getElementById('lookupBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-lookup").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 300,
            width: 450,
            open: function () {
                AEP.$("#dialog-lookup").append(_dialogBody);
            },
            buttons: [
			      {
			        text: "Save",
			        click: function () {

	        			var _endpoint = "PaperTags(" + pID + ")",
		                _tagData = {};

						var e = document.getElementById("tagDesc");
						tagTitle = e.value;

						if (tagTitle === "") {
							alert("Please enter a Tag Name.");
						} else {

						   // Update the display
							var _tagTable = AEP.$('#tagsGrid').DataTable();
							_tagTable.cell(rowNumber,0).data(tagTitle);
							_tagTable.draw(false);

                     _tagData.Title = tagTitle;

                    AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _tagData)).success(function () {

      	            }).fail(function (err) {
                        AEP.$.unblockUI();
                        AEP.Utility.Error.setFailure(err);
                    });

      				           	AEP.$("#dialog-lookup").dialog("close");
      				    }
			        }
			    },
			    {
			        text: "Cancel",
			        click: function () {
			            AEP.$("#dialog-lookup").dialog("close");

			        }
			    }
            ]
        });
	 },

	editTagSMEs =  function(pID) {

	    var options = {
	        url: "../Lists/Paper Tags/EditSMEs.aspx?ID="+pID,
	        title: "Tag Subject Matter Experts",
	        width: 800,
	        height: 400
	    };

	    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);

	 },

	newUser =  function() {

        var _dialogBody = "<div id='lookupBody'><b>Create User</b><br><br>";

        _dialogBody += ("<table><tr>");
        _dialogBody += ("<td align='right'><label><b>User Name: </b></label></td><td colspan='3'><input type='text' id='answerFullName' style='width: 300px'/></td></tr>");
        _dialogBody += ("<tr><td align='right'><label><b>EDIPI: </b></label></td><td colspan='3'><input type='text' id='answerEdipi' style='width: 300px;'/></td></tr>");
        _dialogBody += ("<tr><td align='right'><label><b>Email: </b></label></td><td colspan='3'><input type='text' id='answerEmail' style='width: 300px;'/></td></tr>");
        _dialogBody += ("<tr><td align='right'><label><b>Active: </b></label></td><td colspan='3'>");
        _dialogBody += ("<select id='ddlActive'>");
        _dialogBody += ("<option value='Yes'>Yes</option>");
        _dialogBody += ("<option value='No'>No</option>");
        _dialogBody += ("</select></td></tr>");

        _dialogBody += ("<tr><td align='right'><label><b>Author: </b></label></td><td>");
        _dialogBody += ("<select id='ddlAuthor'>");
        _dialogBody += ("<option value='Yes'>Yes</option>");
		  _dialogBody += ("<option selected='selected' value='No'>No</option>");
        _dialogBody += ("</select>");

        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerAuthorAlias' style='width: 210px;'/></td></tr>");

        _dialogBody += ("<tr><td align='right'><label><b>Sr Editor: </b></label></td><td>");
        _dialogBody += ("<select id='ddlSrEditor'>");
        _dialogBody += ("<option value='Yes'>Yes</option>");
		  _dialogBody += ("<option selected='selected' value='No'>No</option>");
        _dialogBody += ("</select>");

        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerSrEditorAlias' style='width: 210px;'/></td></tr>");

        _dialogBody += ("<tr><td align='right'><label><b>Assoc Editor: </b></label></td><td>");
        _dialogBody += ("<select id='ddlAssocEditor'>");
        _dialogBody += ("<option value='Yes'>Yes</option>");
		  _dialogBody += ("<option selected='selected' value='No'>No</option>");
        _dialogBody += ("</select>");

        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerAssocEditorAlias' style='width: 210px;'/></td></tr>");

        _dialogBody += ("<tr><td align='right'><label><b>Reviewer: </b></label></td><td>");
        _dialogBody += ("<select id='ddlReviewer'>");
        _dialogBody += ("<option value='Yes'>Yes</option>");
		  _dialogBody += ("<option selected='selected' value='No'>No</option>");
        _dialogBody += ("</select>");

        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerReviewerAlias' style='width: 210px;'/></td></tr>");

        _dialogBody += ("<tr><td align='right'><label><b>Style Editor: </b></label></td><td>");
        _dialogBody += ("<select id='ddlStyleEditor'>");
        _dialogBody += ("<option value='Yes'>Yes</option>");
		  _dialogBody += ("<option selected='selected' value='No'>No</option>");
        _dialogBody += ("</select>");

        _dialogBody += "</table></div>";

        if (document.getElementById('lookupBody')) {
            var elem = document.getElementById('lookupBody');
            elem.parentNode.removeChild(elem);
        }

        AEP.$("#dialog-lookup").dialog({
            modal: true,
            draggable: false,
            resizable: false,
            show: 'blind',
            hide: 'blind',
            height: 350,
            width: 500,
            open: function () {
                AEP.$("#dialog-lookup").append(_dialogBody );
            },
            buttons: [
			    {
			        text: "Save",
			        click: function () {

	        			var _endpoint = "UserInfo()",
		                _userData = {};

						var e = document.getElementById("answerFullName");
						var _userFullName = e.value;

						e = document.getElementById("answerEmail");
						var _userEmail = e.value;

						e = document.getElementById("answerEdipi");
						var _userEdipi = e.value;

						e = document.getElementById("ddlActive");
						var _userActive = e.options[e.selectedIndex].value;

						e = document.getElementById("ddlAuthor");
						var _authorFlg = e.options[e.selectedIndex].value;

						e = document.getElementById("answerAuthorAlias");
						var _authorAlias = e.value;
						var _authorDisplay = _authorFlg + "/" + _authorAlias;

						e = document.getElementById("ddlSrEditor");
						var _srEditorFlg = e.options[e.selectedIndex].value;

						e = document.getElementById("answerSrEditorAlias");
						var _srEditorAlias = e.value;
						var _srEditorDisplay = _srEditorFlg + "/" + _srEditorAlias;

						e = document.getElementById("ddlAssocEditor");
						var _assocEditorFlg = e.options[e.selectedIndex].value;

						e = document.getElementById("answerAssocEditorAlias");
						var _assocEditorAlias = e.value;
						var _assocEditorDisplay = _assocEditorFlg + "/" + _assocEditorAlias;

						e = document.getElementById("ddlReviewer");
						var _reviewerFlg = e.options[e.selectedIndex].value;

						e = document.getElementById("answerReviewerAlias");
						var _reviewerAlias = e.value;
						var _reviewerDisplay = _reviewerFlg + "/" + _reviewerAlias;

						e = document.getElementById("ddlStyleEditor");
						var _styleEditorFlg = e.options[e.selectedIndex].value;

						if (_userFullName === "") {
							alert("Please enter a User Name.");
						} else {

			                _userData.FullName = _userFullName;
			                _userData.Email = _userEmail;
			                _userData.Edipi = _userEdipi;
			                _userData.ActiveValue = _userActive;
			                _userData.AuthorValue = _authorFlg;
			                _userData.AuthorAlias = _authorAlias;
			                _userData.SrEditorValue = _srEditorFlg;
			                _userData.SrEditorAlias = _srEditorAlias;
			                _userData.AssocEditorValue = _assocEditorFlg;
			                _userData.AssocEditorAlias = _assocEditorAlias;
			                _userData.ReviewerValue = _reviewerFlg;
			                _userData.ReviewerAlias = _reviewerAlias;
			                _userData.StyleEditorValue = _styleEditorFlg;

			                AEP.$.ajax(AEP.Utility.newItemRequest(_endpoint, _userData)).success(function () {

					            _query = "UserInfo()?$select=Id&$filter=FullName eq '" + _userFullName + "'";

					            AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
					                _results = data.d.results;

					                var _listId = _results[0].Id;

									// Update the display
									var _userTable = AEP.$('#userGrid').DataTable();
									_userTable.row.add( [
										_userFullName,
										_userActive,
										_authorDisplay,
										_srEditorDisplay,
										_assocEditorDisplay,
										_reviewerDisplay,
										_styleEditorDisplay,
										_listId,
										'<button class="btn-edit" type="button" title="Edit"></button>',
									]).draw(false);

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });

			                }).fail(function (err) {
			                    AEP.$.unblockUI();
			                    AEP.Utility.Error.setFailure(err);
			                });

				           	AEP.$("#dialog-lookup").dialog("close");
				    	}
			        }
			    },
			    {
			        text: "Cancel",
			        click: function () {
			            AEP.$("#dialog-lookup").dialog("close");

			        }
			    }
            ]
        });
	},

	editUser =  function(pID, userActive, rowNumber) {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "UserInfo()?$filter=Id eq " + pID + "";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results;
			var _userEmail = "",
				_userFullName = "",
				_userEdipi = "",
				_authorFlg = "",
				_authorAlias = "",
				_srEditorFlg = "",
				_srEditorAlias = "",
				_styleEditorFlg = "",
				_assocEditorFlg = "",
				_assocEditorAlias = "",
				_reviewerFlg = "",
				_reviewerAlias = "";

            if ((_results[0].FullName != null) && (typeof _results[0].FullName != "undefined")) {
                _userFullName = _results[0].FullName;
            }
            else {
            	_userFullName = "";
            }
            if ((_results[0].Edipi != null) && (typeof _results[0].Edipi != "undefined")) {
                _userEdipi = _results[0].Edipi;
            }
            else {
            	_userEdipi = "";
            }
            if ((_results[0].Email != null) && (typeof _results[0].Email != "undefined")) {
                _userEmail = _results[0].Email;
            }
            else {
            	_userEmail = "";
            }

            // Author Info
            if ((_results[0].AuthorValue != null) && (typeof _results[0].AuthorValue != "undefined")) {
                _authorFlg = _results[0].AuthorValue;
            }
            else {
            	_authorFlg = "No";
            }

            if ((_results[0].AuthorAlias != null) && (typeof _results[0].AuthorAlias != "undefined")) {
                _authorAlias = _results[0].AuthorAlias;
            }

            // Sr Editor Info
            if ((_results[0].SrEditorValue != null) && (typeof _results[0].SrEditorValue != "undefined")) {
                _srEditorFlg = _results[0].SrEditorValue;
            }
            else {
            	_srEditorFlg = "No";
            }

            if ((_results[0].SrEditorAlias != null) && (typeof _results[0].SrEditorAlias != "undefined")) {
                _srEditorAlias = _results[0].SrEditorAlias;
            }

            // Assoc Editor Info
            if ((_results[0].AssocEditorValue != null) && (typeof _results[0].AssocEditorValue != "undefined")) {
                _assocEditorFlg = _results[0].AssocEditorValue;
            }
            else {
            	_assocEditorFlg = "No";
            }

            if ((_results[0].AssocEditorAlias != null) && (typeof _results[0].AssocEditorAlias != "undefined")) {
                _assocEditorAlias = _results[0].AssocEditorAlias;
            }

            // Reviewer Info
            if ((_results[0].ReviewerValue != null) && (typeof _results[0].ReviewerValue != "undefined")) {
                _reviewerFlg = _results[0].ReviewerValue;
            }
            else {
            	_reviewerFlg = "No";
            }

            if ((_results[0].ReviewerAlias != null) && (typeof _results[0].ReviewerAlias != "undefined")) {
                _reviewerAlias = _results[0].ReviewerAlias;
            }

            // Style Editor Info
            if ((_results[0].StyleEditorValue != null) && (typeof _results[0].StyleEditorValue != "undefined")) {
                _styleEditorFlg = _results[0].StyleEditorValue;
            }
            else {
            	_styleEditorFlg = "No";
            }

	        var _dialogBody = "<div id='lookupBody'><b>Edit User</b><br><br>";

	        _dialogBody += ("<table><tr>");
	        _dialogBody += ("<td align='right'><label><b>User Name: </b></label></td><td colspan='3'><input type='text' id='answerFullName' value='" + _userFullName + "' style='width: 300px'/></td></tr>");
	        _dialogBody += ("<tr><td align='right'><label><b>EDIPI: </b></label></td><td colspan='3'><input type='text' id='answerEdipi' value='" + _userEdipi + "' style='width: 300px;'/></td></tr>");
	        _dialogBody += ("<tr><td align='right'><label><b>Email: </b></label></td><td colspan='3'><input type='text' id='answerEmail' value='" + _userEmail + "' style='width: 300px;'/></td></tr>");
	        _dialogBody += ("<tr><td align='right'><label><b>Active: </b></label></td><td colspan='3'>");
	        _dialogBody += ("<select id='ddlActive'>");

	        if (userActive === "Yes") {  // Set current value as selected
		        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
		        _dialogBody += ("<option value='No'>No</option>");
		    } else {
		        _dialogBody += ("<option value='Yes'>Yes</option>");
		        _dialogBody += ("<option selected='selected' value='No'>No</option>");
		    }
	        _dialogBody += ("</select></td></tr>");

	        _dialogBody += ("<tr><td align='right'><label><b>Author: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlAuthor'>");
	        if (_authorFlg === "Yes") {  // Set current value as selected
		        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
		        _dialogBody += ("<option value='No'>No</option>");
		    } else {
		        _dialogBody += ("<option value='Yes'>Yes</option>");
		        _dialogBody += ("<option selected='selected' value='No'>No</option>");
		    }
	        _dialogBody += ("</select>");

	        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerAuthorAlias' value='" + _authorAlias + "' style='width: 210px;'/></td></tr>");

	        _dialogBody += ("<tr><td align='right'><label><b>Sr Editor: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlSrEditor'>");
	        if (_srEditorFlg === "Yes") {  // Set current value as selected
		        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
		        _dialogBody += ("<option value='No'>No</option>");
		    } else {
		        _dialogBody += ("<option value='Yes'>Yes</option>");
		        _dialogBody += ("<option selected='selected' value='No'>No</option>");
		    }
	        _dialogBody += ("</select>");

	        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerSrEditorAlias' value='" + _srEditorAlias + "' style='width: 210px;'/></td></tr>");

	        _dialogBody += ("<tr><td align='right'><label><b>Assoc Editor: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlAssocEditor'>");
	        if (_assocEditorFlg === "Yes") {  // Set current value as selected
		        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
		        _dialogBody += ("<option value='No'>No</option>");
		    } else {
		        _dialogBody += ("<option value='Yes'>Yes</option>");
		        _dialogBody += ("<option selected='selected' value='No'>No</option>");
		    }
	        _dialogBody += ("</select>");

	        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerAssocEditorAlias' value='" + _assocEditorAlias + "' style='width: 210px;'/></td></tr>");

	        _dialogBody += ("<tr><td align='right'><label><b>Reviewer: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlReviewer'>");
	        if (_reviewerFlg === "Yes") {  // Set current value as selected
		        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
		        _dialogBody += ("<option value='No'>No</option>");
		    } else {
		        _dialogBody += ("<option value='Yes'>Yes</option>");
		        _dialogBody += ("<option selected='selected' value='No'>No</option>");
		    }
	        _dialogBody += ("</select>");

	        _dialogBody += ("<label><b>  Alias: </b></label></td><td><input type='text' id='answerReviewerAlias' value='" + _reviewerAlias + "' style='width: 210px;'/></td></tr>");

	        _dialogBody += ("<tr><td align='right'><label><b>Style Editor: </b></label></td><td>");
	        _dialogBody += ("<select id='ddlStyleEditor'>");
	        if (_styleEditorFlg === "Yes") {  // Set current value as selected
		        _dialogBody += ("<option selected='selected' value='Yes'>Yes</option>");
		        _dialogBody += ("<option value='No'>No</option>");
		    } else {
		        _dialogBody += ("<option value='Yes'>Yes</option>");
		        _dialogBody += ("<option selected='selected' value='No'>No</option>");
		    }
	        _dialogBody += ("</select>");

	        _dialogBody += "</table></div>";

	        if (document.getElementById('lookupBody')) {
	            var elem = document.getElementById('lookupBody');
	            elem.parentNode.removeChild(elem);
	        }

	        AEP.$("#dialog-lookup").dialog({
	            modal: true,
	            draggable: false,
	            resizable: false,
	            show: 'blind',
	            hide: 'blind',
	            height: 350,
	            width: 450,
	            open: function () {
	                AEP.$("#dialog-lookup").append(_dialogBody );
	            },
	            buttons: [
				    {
				        text: "Save",
				        click: function () {

		        			var _endpoint = "UserInfo(" + pID + ")",
			                _userData = {};

							var e = document.getElementById("answerFullName");
							_userFullName = e.value;

							e = document.getElementById("answerEmail");
							_userEmail = e.value;

							e = document.getElementById("answerEdipi");
							_userEdipi = e.value;

							e = document.getElementById("ddlActive");
							userActive = e.options[e.selectedIndex].value;

							e = document.getElementById("ddlAuthor");
							_authorFlg = e.options[e.selectedIndex].value;

							e = document.getElementById("answerAuthorAlias");
							_authorAlias = e.value;

							e = document.getElementById("ddlSrEditor");
							_srEditorFlg = e.options[e.selectedIndex].value;

							e = document.getElementById("answerSrEditorAlias");
							_srEditorAlias = e.value;

							e = document.getElementById("ddlAssocEditor");
							_assocEditorFlg = e.options[e.selectedIndex].value;

							e = document.getElementById("answerAssocEditorAlias");
							_assocEditorAlias = e.value;

							e = document.getElementById("ddlReviewer");
							_reviewerFlg = e.options[e.selectedIndex].value;

							e = document.getElementById("answerReviewerAlias");
							_reviewerAlias = e.value;

							e = document.getElementById("ddlStyleEditor");
							var _styleEditorFlg = e.options[e.selectedIndex].value;

							if (_userFullName === "") {
								alert("Please enter a User Name.");
							} else {

								// Update the display
								var _userTable = AEP.$('#userGrid').DataTable();
								_userTable.cell(rowNumber,0).data(_userFullName);
								_userTable.cell(rowNumber,1).data(userActive);
								_userTable.cell(rowNumber,2).data(_authorFlg + "/" + _authorAlias);
								_userTable.cell(rowNumber,3).data(_srEditorFlg + "/" + _srEditorAlias);
								_userTable.cell(rowNumber,4).data(_assocEditorFlg + "/" + _assocEditorAlias);
								_userTable.cell(rowNumber,5).data(_reviewerFlg + "/" + _reviewerAlias);
								_userTable.cell(rowNumber,6).data(_styleEditorFlg);
								_userTable.draw(false);

				                _userData.FullName = _userFullName;
				                _userData.Email = _userEmail;
				                _userData.Edipi = _userEdipi;
				                _userData.ActiveValue = userActive;
				                _userData.AuthorValue = _authorFlg;
				                _userData.AuthorAlias = _authorAlias;
				                _userData.SrEditorValue = _srEditorFlg;
				                _userData.SrEditorAlias = _srEditorAlias;
				                _userData.AssocEditorValue = _assocEditorFlg;
				                _userData.AssocEditorAlias = _assocEditorAlias;
				                _userData.ReviewerValue = _reviewerFlg;
				                _userData.ReviewerAlias = _reviewerAlias;
				                _userData.StyleEditorValue = _styleEditorFlg;

				                AEP.$.ajax(AEP.Utility.updateItemRequest(_endpoint, _userData)).success(function () {

							        //alert("record saved");

				                }).fail(function (err) {
				                    AEP.$.unblockUI();
				                    AEP.Utility.Error.setFailure(err);
				                });

					           	AEP.$("#dialog-lookup").dialog("close");
					    	}
				        }
				    },
				    {
				        text: "Cancel",
				        click: function () {
				            AEP.$("#dialog-lookup").dialog("close");

				        }
				    }
	            ]
	        });
        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
	 };

     return {
      	editTag : editTag,
       	newTag : newTag,
      	editTagSMEs : editTagSMEs,
     	editUser : editUser,
     	newUser : newUser
    };
}());


AEP.admin.getData = (function () {
    "use strict";

    var loadTagList = function () {

        var _query = "PaperTags()?$select=Title,Id";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

                _receivedData.push([_results[i].Title, _results[i].Id, _results[i].Id]);

            });

            var _tagsTable = AEP.$('#tagsGrid').DataTable({
                "dom": '<"tagsToolbar">lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
		        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,2] },
		        	{ "width": "70px", "targets": 2 },
		        	{ "targets": [1],
	        		  "visible": false
	        		},
		        	{ "targets": -1,
		               "data": null,
		               "defaultContent":
    	  					'<div style="float: left; width: 32px;"><button aria-label="Edit Tag" class="btn-edit" title="Edit Tag"></button>Edit</div>'
    	  					+ '<div style="float: left; width: 32px;"><button aria-label="SMEs" class="btn-people" type="button" title="Subject Matter Experts"></button>SMEs</div>'
		        	}
		        ]
            });

			AEP.$("div.tagsToolbar").html('<table><tr><td><button aria-label="Create Tag" class="btn-new" type="button" title="Create Tag" onclick="AEP.admin.ui.newTag()"></button></td><td>Create Tag</td></tr></table>');

		    AEP.$('#tagsGrid tbody').on( 'click', '.btn-edit', function (e) {
		        e.preventDefault();
		        var data = _tagsTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _tagsTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.admin.ui.editTag(data[1], data[0], rowNumber);
        	});

		    AEP.$('#tagsGrid tbody').on( 'click', '.btn-people', function (e) {
		        e.preventDefault();
		        var data = _tagsTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.admin.ui.editTagSMEs(data[1]);
        	});

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },

    loadUsers = function () {

        var _query = "UserInfo()?$select=FullName,Edipi,Email,ActiveValue,AuthorValue,AuthorAlias,SrEditorValue,SrEditorAlias,AssocEditorValue,AssocEditorAlias,ReviewerValue,ReviewerAlias,StyleEditorValue,Id";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_authorDisplay = "",
            	_srEditorDisplay = "",
            	_assocEditorDisplay = "",
            	_reviewerDisplay = "",
            	_styleEditorDisplay = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            // Set grid display for Author info
	            if ((_results[i].AuthorValue != null) && (typeof _results[i].AuthorValue != "undefined")) {
	                _authorDisplay = _results[i].AuthorValue + "/";
	            }
	            else {
	            	_authorDisplay = "No/";
	            }

	            if ((_results[i].AuthorAlias != null) && (typeof _results[i].AuthorAlias != "undefined")) {
	                _authorDisplay += _results[i].AuthorAlias;
	            }

	            // Set grid display for Sr Editor info
	            if ((_results[i].SrEditorValue != null) && (typeof _results[i].SrEditorValue != "undefined")) {
	                _srEditorDisplay = _results[i].SrEditorValue + "/";
	            }
	            else {
	            	_srEditorDisplay = "No/";
	            }

	            if ((_results[i].SrEditorAlias != null) && (typeof _results[i].SrEditorAlias != "undefined")) {
	                _srEditorDisplay += _results[i].SrEditorAlias;
	            }

	            // Set grid display for Assoc Editor info
	            if ((_results[i].AssocEditorValue != null) && (typeof _results[i].AssocEditorValue != "undefined")) {
	                _assocEditorDisplay = _results[i].AssocEditorValue + "/";
	            }
	            else {
	            	_assocEditorDisplay = "No/";
	            }

	            if ((_results[i].AssocEditorAlias != null) && (typeof _results[i].AssocEditorAlias != "undefined")) {
	                _assocEditorDisplay += _results[i].AssocEditorAlias;
	            }

	            // Set grid display for Reviewer info
	            if ((_results[i].ReviewerValue != null) && (typeof _results[i].ReviewerValue != "undefined")) {
	                _reviewerDisplay = _results[i].ReviewerValue + "/";
	            }
	            else {
	            	_reviewerDisplay = "No/";
	            }

	            if ((_results[i].ReviewerAlias != null) && (typeof _results[i].ReviewerAlias != "undefined")) {
	                _reviewerDisplay += _results[i].ReviewerAlias;
	            }

	            // Set grid display for Sr Editor info
	            if ((_results[i].StyleEditorValue != null) && (typeof _results[i].StyleEditorValue != "undefined")) {
	                _styleEditorDisplay = _results[i].StyleEditorValue;
	            }
	            else {
	            	_styleEditorDisplay = "No";
	            }

                _receivedData.push([ _results[i].FullName, _results[i].ActiveValue, _authorDisplay, _srEditorDisplay, _assocEditorDisplay, _reviewerDisplay, _styleEditorDisplay, _results[i].Id, _results[i].Id]);

            });

            var _userTable = AEP.$('#userGrid').DataTable({
                "dom": '<"userToolbar">lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
		        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,6] },
		        	{ "width": "35px", "targets": 8 },
		        	{ "targets": [7],
	        		  "visible": false
	        		},
		        	{ "targets": -1,
		               "data": null,
		               "defaultContent":
    	  					'<div style="width: 32px;"><button aria-label="Edit User" class="btn-edit" title="Edit User"></button>Edit</div>'
		        	}
		        ]
            });

			AEP.$("div.userToolbar").html('<table><tr><td><button aria-label="Create User" class="btn-new" type="button" title="Create User" onclick="AEP.admin.ui.newUser()"></button></td><td>Create User</td></tr></table>');

		    AEP.$('#userGrid tbody').on( 'click', '.btn-edit', function (e) {
		        e.preventDefault();
		        var data = _userTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _userTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.admin.ui.editUser(data[7], data[1], rowNumber);
        	});

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    },

	loadPaperList = function () {

        AEP.$(document).ajaxStart(AEP.$.blockUI({ css: { backgroundColor: '#003366', border: '5px solid #F4712', color: 'white' } })).ajaxStop(AEP.$.unblockUI);  // Waiting message for ajax calls

        var _query = "PaperDetails()?$select=PaperName,PaperNumber,AbstractSecurityNumber,PaperSecurityNumber,PaperVersionNumber,Status,SubmittedDate,FinalApprovedDate,Id";

        AEP.$.ajax(AEP.Utility.getItemRequest(_query)).success(function (data) {
            var _results = data.d.results,
            	_absSecNo = "",
            	_paperSecNo = "",
            	_paperName = "",
            	_paperNumber = "",
            	_paperVersionNo = "",
            	_submittedDate = "",
            	_submittedDateSort = "",
            	_finalApprovedDate = "",
                _receivedData = [];

            AEP.$.each(_results, function (i, item) {

	            if ((_results[i].AbstractSecurityNumber != null) && (typeof _results[i].AbstractSecurityNumber != "undefined")) {
	                _absSecNo = _results[i].AbstractSecurityNumber;
	            }
	            else {
	            	_absSecNo = "";
	            }

	            if ((_results[i].PaperSecurityNumber != null) && (typeof _results[i].PaperSecurityNumber != "undefined")) {
	                _paperSecNo = _results[i].PaperSecurityNumber;
	            }
	            else {
	            	_paperSecNo = "";
	            }

	            if ((_results[i].PaperNumber != null) && (typeof _results[i].PaperNumber != "undefined")) {
	                _paperNumber = _results[i].PaperNumber;
	            }
	            else {
	            	_paperNumber = "";
	            }

	            if ((_results[i].PaperName != null) && (typeof _results[i].PaperName != "undefined")) {
	                _paperName = _results[i].PaperName;
	            }
	            else {
	            	_paperName = "";
	            }

	            if (_results[i].PaperVersionNumber != null) {
	                _paperVersionNo = _results[i].PaperVersionNumber;
	            }
	            else {
	            	_paperVersionNo = "1.0";
	            }

	            if ((_results[i].SubmittedDate != null) && (typeof _results[i].SubmittedDate != "undefined")) {
	                _submittedDate = moment.utc(_results[i].SubmittedDate).format('L');
	                _submittedDateSort = moment.utc(_results[i].SubmittedDate).format('YYYYMMDDHHmmss');
	            }
	            else {
	            	_submittedDate = "";
	            	_submittedDateSort = "99999999999999";
	            }

	            if ((_results[i].FinalApprovedDate != null) && (typeof _results[i].FinalApprovedDate != "undefined")) {
	                _finalApprovedDate = moment.utc(_results[i].FinalApprovedDate).format('L');
	            }
	            else {
	            	_finalApprovedDate = "";
	            }

                _receivedData.push([_paperName, _paperNumber, _absSecNo, _paperSecNo, _submittedDate, _finalApprovedDate, _results[i].Status, _results[i].Id, _results[i].Status, _submittedDateSort, _paperVersionNo]);
            });

            var _paperTable = AEP.$('#paperGrid').DataTable({
                "dom": 'lfrTCRtip',
                "bDestroy": true,
                "aaData": _receivedData,
                "oColVis": {
                    "bRestore": true
                },
                "bSort": true,
                "order": [[9, "desc"], [7, "desc"]],
    	        "scrollCollapse": true,
                "orderClasses": false,
                "oLanguage": {
                    "sSearch": "Filter:"
                },
		        "columnDefs": [
		        	{ "className": "dt-body-center", "targets": [0,1,2,3,4,5,6,8] },
		        	{ "width": "300px", "targets": 8 },
		        	{ "targets": [7,9,10],
	        		  "visible": false
	        		},
		        	{ "targets": 8,
		        	  "render": function(data, type, row) {
			        	var _rowButtons = "";

			        	switch (data) {
			       	  		case ("Initiating Paper Process"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
 		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
	   	  					 	break;
			       	  		case ("Final Approved"):
			       	  		case ("Rejected"):
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
 		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
   	  					 					+ '<div style="float: left; width: 48px;"><button aria-label="Reviews" class="btn-review" title="Reviews"></button>Reviews</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'
	   	  					 	break;
							default:
			        	  		_rowButtons = '<div style="float: left; width: 32px;"><button aria-label="View Paper" class="btn-view" title="View Paper"></button>View</div>'
		        	  						+ '<div style="float: left; width: 32px;"><button aria-label="Files" class="btn-files" type="button" title="Files"></button>Files</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Assign Paper" class="btn-assign" title="Assign Paper"></button>Assign</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Reviews" class="btn-review" title="Reviews"></button>Reviews</div>'
    	  					 				+ '<div style="float: left; width: 48px;"><button aria-label="Approve Paper" class="btn-approve" title="Approve Paper"></button>Approve</div>'
    	  					 				+ '<div style="float: left; width: 40px;"><button aria-label="Reject Paper" class="btn-reject" title="Reject Paper"></button>Reject</div>'
    	  					 				+ '<div style="float: left; width: 56px;"><button aria-label="Messages" class="btn-message" title="Messages"></button>Messages</div>'

							}
				        return _rowButtons;
		        	  	}
			      	}
		        ]
            });

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-view', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewPaper(data[7], "ADMIN");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-files', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        AEP.journalUtil.displayFiles(data[7], data[1], "ADMIN");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-assign', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.assignPaperEditor(data[7], rowNumber);
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-approve', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.approvePaper(data[7], data[1], data[10], rowNumber, "ADMIN");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-reject', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.rejectPaper(data[7], data[1], data[10], rowNumber, "ADMIN");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-message', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewMessages(data[7], "ADMIN", "Administrator");
        	});

		    AEP.$('#paperGrid tbody').on( 'click', '.btn-review', function (e) {
		        e.preventDefault();
		        var data = _paperTable.row( AEP.$(this).parents('tr') ).data();
		        var rowNumber = _paperTable.row( AEP.$(this).parents('tr') ).index();
		        AEP.journalUtil.viewReviews(data[7],"ADMIN");
        	});

        }).fail(function (err) {
            AEP.$.unblockUI();
            AEP.Utility.Error.setFailure(err);
        });
    };

    return {
        loadTagList : loadTagList,
        loadUsers : loadUsers,
        loadPaperList : loadPaperList
    };
}());
